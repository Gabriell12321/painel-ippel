import sqlite3
from datetime import datetime, timedelta

def get_db_connection():
    conn = sqlite3.connect('ippel.db')
    conn.row_factory = sqlite3.Row
    return conn

def format_data_for_ai(dados):
    """Formata os dados do banco de dados para a IA de forma mais detalhada e estruturada"""
    
    # Estatísticas gerais
    total_clientes = len(dados['clientes'])
    total_produtos = len(dados['produtos'])
    total_vendas = len(dados['vendas'])
    total_manutencoes = len(dados['manutencoes'])
    valor_total_vendas = sum(venda['valor_total'] for venda in dados['vendas'])
    
    # Formatar dados por seção
    formatted_data = f"""
DADOS ATUALIZADOS DO SISTEMA IPPEL EQUIPAMENTOS:

RESUMO GERAL:
- Total de Clientes: {total_clientes}
- Total de Produtos: {total_produtos}
- Total de Vendas: {total_vendas}
- Total de Manutenções: {total_manutencoes}
- Valor Total em Vendas: R$ {valor_total_vendas:,.2f}

CLIENTES CADASTRADOS:
"""
    
    # Adicionar dados dos clientes
    for cliente in dados['clientes']:
        formatted_data += f"""
• Cliente: {cliente['nome']}
  - ID: {cliente['id']}
  - Segmento: {cliente['segmento']}
  - Região: {cliente['regiao']}
  - Email: {cliente['email']}
  - Telefone: {cliente['telefone']}
  - Última Compra: {cliente['ultima_compra'] or 'Sem compras registradas'}
"""
    
    formatted_data += "\nPRODUTOS DISPONÍVEIS:\n"
    
    # Adicionar dados dos produtos
    for produto in dados['produtos']:
        formatted_data += f"""
• Produto: {produto['modelo']}
  - ID: {produto['id']}
  - Categoria: {produto['categoria']}
  - Preço: R$ {produto['preco']:,.2f}
  - Estoque Atual: {produto['estoque']} unidades
  - Descrição: {produto['descricao'] or 'Sem descrição'}
"""
    
    formatted_data += "\nHISTÓRICO DE VENDAS:\n"
    
    # Adicionar dados das vendas (últimas 50 vendas)
    vendas_ordenadas = sorted(dados['vendas'], key=lambda x: x['data_venda'], reverse=True)[:50]
    for venda in vendas_ordenadas:
        formatted_data += f"""
• Venda ID {venda['id']} - {venda['data_venda']}
  - Cliente: {venda['cliente_nome']}
  - Produto: {venda['produto_nome']} ({venda['categoria']})
  - Quantidade: {venda['quantidade']} unidades
  - Valor Total: R$ {venda['valor_total']:,.2f}
"""
    
    formatted_data += "\nREGISTRO DE MANUTENÇÕES:\n"
    
    # Adicionar dados das manutenções (últimas 50 manutenções)
    manutencoes_ordenadas = sorted(dados['manutencoes'], key=lambda x: x['data_manutencao'], reverse=True)[:50]
    for manutencao in manutencoes_ordenadas:
        formatted_data += f"""
• Manutenção ID {manutencao['id']} - {manutencao['data_manutencao']}
  - Cliente: {manutencao['cliente_nome']}
  - Produto: {manutencao['produto_nome']}
  - Tipo: {manutencao['tipo']}
  - Status: {manutencao['status']}
  - Custo: R$ {manutencao['custo']:,.2f}
"""
    
    return formatted_data

def get_all_data():
    """Retorna todos os dados do banco de dados"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    dados = {
        "clientes": [],
        "produtos": [],
        "vendas": [],
        "manutencoes": []
    }
    
    # Buscar todos os clientes
    cursor.execute('''
        SELECT * FROM clientes
    ''')
    dados["clientes"] = [dict(row) for row in cursor.fetchall()]
    
    # Buscar todos os produtos
    cursor.execute('''
        SELECT * FROM produtos
    ''')
    dados["produtos"] = [dict(row) for row in cursor.fetchall()]
    
    # Buscar todas as vendas com informações detalhadas
    cursor.execute('''
        SELECT 
            v.*,
            c.nome as cliente_nome,
            p.modelo as produto_nome,
            p.categoria as categoria,
            c.segmento as cliente_segmento,
            c.regiao as cliente_regiao
        FROM vendas v
        JOIN clientes c ON v.cliente_id = c.id
        JOIN produtos p ON v.produto_id = p.id
        ORDER BY v.data_venda DESC
    ''')
    dados["vendas"] = [dict(row) for row in cursor.fetchall()]
    
    # Buscar todas as manutenções com informações detalhadas
    cursor.execute('''
        SELECT 
            m.*,
            c.nome as cliente_nome,
            p.modelo as produto_nome,
            p.categoria as produto_categoria,
            c.segmento as cliente_segmento,
            c.regiao as cliente_regiao
        FROM manutencoes m
        JOIN clientes c ON m.cliente_id = c.id
        JOIN produtos p ON m.produto_id = p.id
        ORDER BY m.data_manutencao DESC
    ''')
    dados["manutencoes"] = [dict(row) for row in cursor.fetchall()]
    
    conn.close()
    
    # Formatar os dados para a IA
    return format_data_for_ai(dados)

def check_current_data():
    """Verifica e exibe os dados atuais do sistema"""
    print(get_all_data())

if __name__ == '__main__':
    check_current_data() 