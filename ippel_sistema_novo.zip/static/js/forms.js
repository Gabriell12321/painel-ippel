// Aguardar o carregamento do DOM
document.addEventListener('DOMContentLoaded', function() {
    // Formulário de Vendas
    const vendaForm = document.getElementById('vendaForm');
    if (vendaForm) {
        vendaForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            try {
                const formData = {
                    produto_id: document.getElementById('venda_produto_id').value,
                    cliente_id: document.getElementById('venda_cliente_id').value,
                    quantidade: document.getElementById('venda_quantidade').value,
                    desconto: document.getElementById('venda_desconto').value || 0
                };
                
                const response = await fetch('/api/dados/vendas', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
                
                if (!response.ok) {
                    throw new Error('Erro ao registrar venda');
                }
                
                const data = await response.json();
                alert('Venda registrada com sucesso!');
                vendaForm.reset();
                
                // Atualizar dados do dashboard
                if (typeof updateDashboard === 'function') {
                    updateDashboard();
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao registrar venda. Por favor, tente novamente.');
            }
        });
    }
    
    // Formulário de Produtos
    const produtoForm = document.getElementById('produtoForm');
    if (produtoForm) {
        produtoForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            try {
                const formData = {
                    categoria: document.getElementById('produto_categoria').value,
                    modelo: document.getElementById('produto_modelo').value,
                    preco: document.getElementById('produto_preco').value,
                    estoque: document.getElementById('produto_estoque').value,
                    descricao: document.getElementById('produto_descricao').value
                };
                
                const response = await fetch('/api/dados/produtos', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
                
                if (!response.ok) {
                    throw new Error('Erro ao salvar produto');
                }
                
                const data = await response.json();
                alert('Produto salvo com sucesso!');
                produtoForm.reset();
                
                // Atualizar dados do dashboard
                if (typeof updateDashboard === 'function') {
                    updateDashboard();
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao salvar produto. Por favor, tente novamente.');
            }
        });
    }
    
    // Formulário de Clientes
    const clienteForm = document.getElementById('clienteForm');
    if (clienteForm) {
        clienteForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            try {
                const formData = {
                    nome: document.getElementById('cliente_nome').value,
                    email: document.getElementById('cliente_email').value,
                    telefone: document.getElementById('cliente_telefone').value,
                    endereco: document.getElementById('cliente_endereco').value
                };
                
                const response = await fetch('/api/dados/clientes', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
                
                if (!response.ok) {
                    throw new Error('Erro ao salvar cliente');
                }
                
                const data = await response.json();
                alert('Cliente salvo com sucesso!');
                clienteForm.reset();
                
                // Atualizar dados do dashboard
                if (typeof updateDashboard === 'function') {
                    updateDashboard();
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao salvar cliente. Por favor, tente novamente.');
            }
        });
    }
    
    // Carregar dados iniciais para os selects
    carregarDadosIniciais();
});

// Função para carregar dados iniciais
async function carregarDadosIniciais() {
    try {
        // Carregar produtos para o select de vendas
        const produtosResponse = await fetch('/api/dados/produtos');
        if (produtosResponse.ok) {
            const produtos = await produtosResponse.json();
            const produtoSelect = document.getElementById('venda_produto_id');
            if (produtoSelect) {
                produtos.forEach(produto => {
                    const option = document.createElement('option');
                    option.value = produto.id;
                    option.textContent = `${produto.modelo} - R$ ${produto.preco}`;
                    produtoSelect.appendChild(option);
                });
            }
        }
        
        // Carregar clientes para o select de vendas
        const clientesResponse = await fetch('/api/dados/clientes');
        if (clientesResponse.ok) {
            const clientes = await clientesResponse.json();
            const clienteSelect = document.getElementById('venda_cliente_id');
            if (clienteSelect) {
                clientes.forEach(cliente => {
                    const option = document.createElement('option');
                    option.value = cliente.id;
                    option.textContent = cliente.nome;
                    clienteSelect.appendChild(option);
                });
            }
        }
    } catch (error) {
        console.error('Erro ao carregar dados iniciais:', error);
    }
}

// Função para atualizar tabelas
async function atualizarTabelas() {
    try {
        // Atualizar tabela de produtos
        const produtosResponse = await fetch('/api/dados/produtos');
        if (produtosResponse.ok) {
            const produtos = await produtosResponse.json();
            const tabelaProdutos = document.querySelector('#tabela-produtos tbody');
            if (tabelaProdutos) {
                tabelaProdutos.innerHTML = '';
                produtos.forEach(produto => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${produto.categoria}</td>
                        <td>${produto.modelo}</td>
                        <td>R$ ${produto.preco}</td>
                        <td>${produto.estoque}</td>
                        <td>
                            <button class="btn-danger btn-sm" onclick="deletarProduto(${produto.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tabelaProdutos.appendChild(tr);
                });
            }
        }
        
        // Atualizar tabela de vendas
        const vendasResponse = await fetch('/api/dados/vendas');
        if (vendasResponse.ok) {
            const vendas = await vendasResponse.json();
            const tabelaVendas = document.querySelector('#tabela-vendas tbody');
            if (tabelaVendas) {
                tabelaVendas.innerHTML = '';
                vendas.forEach(venda => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${new Date(venda.data_venda).toLocaleDateString()}</td>
                        <td>${venda.cliente_nome}</td>
                        <td>${venda.produto_modelo}</td>
                        <td>R$ ${venda.valor_total}</td>
                        <td>
                            <button class="btn-danger btn-sm" onclick="deletarVenda(${venda.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tabelaVendas.appendChild(tr);
                });
            }
        }
    } catch (error) {
        console.error('Erro ao atualizar tabelas:', error);
    }
}

// Funções para deletar registros
async function deletarProduto(id) {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
        try {
            const response = await fetch(`/api/dados/produtos/${id}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) {
                throw new Error('Erro ao excluir produto');
            }
            
            alert('Produto excluído com sucesso!');
            atualizarTabelas();
            
            // Atualizar dados do dashboard
            if (typeof updateDashboard === 'function') {
                updateDashboard();
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao excluir produto. Por favor, tente novamente.');
        }
    }
}

async function deletarVenda(id) {
    if (confirm('Tem certeza que deseja excluir esta venda?')) {
        try {
            const response = await fetch(`/api/dados/vendas/${id}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) {
                throw new Error('Erro ao excluir venda');
            }
            
            alert('Venda excluída com sucesso!');
            atualizarTabelas();
            
            // Atualizar dados do dashboard
            if (typeof updateDashboard === 'function') {
                updateDashboard();
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao excluir venda. Por favor, tente novamente.');
        }
    }
}

// Atualizar tabelas quando a página carregar
document.addEventListener('DOMContentLoaded', atualizarTabelas); 