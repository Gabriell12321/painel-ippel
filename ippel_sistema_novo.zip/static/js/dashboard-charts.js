// Namespace para gráficos do dashboard
window.DashboardCharts = {
    charts: {},
    colors: {
        primary: '#dc2626',
        secondary: '#991b1b',
        success: '#10b981',
        info: '#3b82f6',
        warning: '#f59e0b'
    }
};

// Função para destruir todos os gráficos
DashboardCharts.destroyAllCharts = function() {
    console.log('🗑️ Destruindo todos os gráficos...');
    Object.values(this.charts).forEach(chart => {
        if (chart && typeof chart.destroy === 'function') {
            chart.destroy();
        }
    });
    this.charts = {};
};

// Função para inicializar todos os gráficos
DashboardCharts.initializeAll = async function() {
    console.log('📊 Iniciando inicialização dos gráficos...');
    try {
        // Primeiro, destruir todos os gráficos existentes
        this.destroyAllCharts();

        const response = await fetch('/api/dados/dashboard');
        if (!response.ok) throw new Error('Erro ao carregar dados');
        const data = await response.json();
        console.log('✅ Dados recebidos:', data);

        // Inicializa gráfico de clientes por região
        await this.initializeClientesRegiao(data);
        
        // Inicializa gráfico de produtos mais vendidos
        await this.initializeProdutosMaisVendidos(data);

        console.log('✅ Gráficos inicializados com sucesso');
    } catch (error) {
        console.error('❌ Erro ao inicializar gráficos:', error);
        this.showError('clientes-regiao-chart');
        this.showError('produtos-vendidos-chart');
    }
};

// Gráfico de Clientes por Região
DashboardCharts.initializeClientesRegiao = async function(data) {
    console.log('📊 Iniciando gráfico de clientes por região...');
    const canvas = document.getElementById('clientes-regiao-chart');
    if (!canvas) {
        console.warn('⚠️ Canvas do gráfico de clientes por região não encontrado');
        return;
    }

    try {
        // Limpar o canvas
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const gradient = ctx.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, 'rgba(220, 38, 38, 0.8)');
        gradient.addColorStop(1, 'rgba(220, 38, 38, 0.1)');

        if (!data.clientes_regiao || !Array.isArray(data.clientes_regiao)) {
            throw new Error('Dados de clientes por região inválidos');
        }

        console.log('📊 Dados do gráfico de clientes por região:', data.clientes_regiao);

        this.charts.clientesRegiao = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.clientes_regiao.map(r => r.regiao),
                datasets: [{
                    label: 'Clientes',
                    data: data.clientes_regiao.map(r => r.quantidade),
                    backgroundColor: gradient,
                    borderColor: this.colors.primary,
                    borderWidth: 2,
                    borderRadius: 8,
                    barThickness: 30
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Distribuição de Clientes por Região',
                        font: {
                            size: 16,
                            weight: 'bold',
                            family: 'Inter'
                        },
                        padding: 20,
                        color: '#1f2937'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            drawBorder: false,
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            font: {
                                family: 'Inter'
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                family: 'Inter'
                            }
                        }
                    }
                }
            }
        });

        console.log('✅ Gráfico de clientes por região inicializado com sucesso');
    } catch (error) {
        console.error('❌ Erro ao inicializar gráfico de clientes por região:', error);
        this.showError('clientes-regiao-chart');
    }
};

// Gráfico de Produtos Mais Vendidos
DashboardCharts.initializeProdutosMaisVendidos = async function(data) {
    console.log('📊 Iniciando gráfico de produtos mais vendidos...');
    const canvas = document.getElementById('produtos-vendidos-chart');
    if (!canvas) {
        console.warn('⚠️ Canvas do gráfico de produtos mais vendidos não encontrado');
        return;
    }

    try {
        // Limpar o canvas
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        if (!data.produtos_mais_vendidos || !Array.isArray(data.produtos_mais_vendidos)) {
            throw new Error('Dados de produtos mais vendidos inválidos');
        }

        console.log('📊 Dados do gráfico de produtos mais vendidos:', data.produtos_mais_vendidos);

        const colors = data.produtos_mais_vendidos.map((_, index) => {
            const hue = (index * 360) / data.produtos_mais_vendidos.length;
            return `hsl(${hue}, 70%, 50%)`;
        });

        this.charts.produtosMaisVendidos = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.produtos_mais_vendidos.map(p => p.modelo),
                datasets: [{
                    label: 'Quantidade Vendida',
                    data: data.produtos_mais_vendidos.map(p => p.quantidade),
                    backgroundColor: colors,
                    borderColor: colors.map(color => color.replace('0.8', '1')),
                    borderWidth: 2,
                    borderRadius: 8,
                    barThickness: 30
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Produtos Mais Vendidos',
                        font: {
                            size: 16,
                            weight: 'bold',
                            family: 'Inter'
                        },
                        padding: 20,
                        color: '#1f2937'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            drawBorder: false,
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            font: {
                                family: 'Inter'
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                family: 'Inter'
                            }
                        }
                    }
                }
            }
        });

        console.log('✅ Gráfico de produtos mais vendidos inicializado com sucesso');
    } catch (error) {
        console.error('❌ Erro ao inicializar gráfico de produtos mais vendidos:', error);
        this.showError('produtos-vendidos-chart');
    }
};

// Função para exibir erro no gráfico
DashboardCharts.showError = function(canvasId) {
    console.log(`⚠️ Exibindo erro no gráfico ${canvasId}...`);
    const canvas = document.getElementById(canvasId);
    if (canvas) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#ef4444';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '14px Inter';
        ctx.fillText('Erro ao carregar gráfico', canvas.width/2, canvas.height/2);
        console.log(`✅ Erro exibido no gráfico ${canvasId}`);
    } else {
        console.warn(`⚠️ Canvas ${canvasId} não encontrado para exibir erro`);
    }
};

// Atualizar gráficos
DashboardCharts.updateAll = async function() {
    console.log('🔄 Iniciando atualização dos gráficos...');
    try {
        // Primeiro, destruir todos os gráficos existentes
        this.destroyAllCharts();

        const response = await fetch('/api/dados/dashboard');
        if (!response.ok) throw new Error('Erro ao carregar dados');
        const data = await response.json();
        console.log('✅ Dados recebidos:', data);

        // Atualiza cada gráfico
        await this.initializeClientesRegiao(data);
        await this.initializeProdutosMaisVendidos(data);

        console.log('✅ Gráficos atualizados com sucesso');
    } catch (error) {
        console.error('❌ Erro ao atualizar gráficos:', error);
        this.showError('clientes-regiao-chart');
        this.showError('produtos-vendidos-chart');
    }
};

// Inicializar quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM carregado - iniciando gráficos...');
    DashboardCharts.initializeAll();
});

// Atualizar gráficos quando o dashboard for atualizado
document.addEventListener('dashboardUpdated', () => {
    console.log('🔄 Evento dashboardUpdated recebido - atualizando gráficos...');
    DashboardCharts.updateAll();
}); 