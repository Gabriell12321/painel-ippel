// Variáveis globais
let conversations = [];
let currentConversation = null;
let isTyping = false;
let messageQueue = [];
let isProcessingQueue = false;
let shouldSkipAnimation = false;

// Configurações de velocidade
const TYPING_SPEED = {
    MIN: 10, // Velocidade mínima entre caracteres (ms)
    MAX: 20,  // Velocidade máxima entre caracteres (ms)
    SKIP: 0 // Velocidade quando pular animação
};

// Função para inicializar o chat
function initChat() {
    // Verificar se estamos na página de chat
    const chatPage = document.getElementById('ia');
    if (!chatPage || !chatPage.classList.contains('active')) {
        console.log('Página de chat não está ativa');
        return;
    }

    console.log('Inicializando chat...');
    
    const chatInput = document.getElementById('chat_message_input');
    const sendButton = document.querySelector('.send-btn');
    const newChatButton = document.getElementById('newChatButton');
    const searchInput = document.getElementById('dash_chat_search');
    const chatMessages = document.getElementById('chat_messages');
    
    // Verificar se os elementos necessários existem
    if (!chatInput || !chatMessages) {
        console.warn('Elementos essenciais do chat não encontrados');
        return;
    }
    
    // Event listener para enviar mensagem
    chatInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    // Event listener para o botão de enviar
    if (sendButton) {
        sendButton.addEventListener('click', sendMessage);
    }
    
    // Event listener para novo chat
    if (newChatButton) {
        newChatButton.addEventListener('click', createNewChat);
    }
    
    // Event listener para pesquisa
    if (searchInput) {
        searchInput.addEventListener('input', searchConversations);
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                searchConversations();
            }
        });
    }
    
    // Criar primeira conversa
    createNewChat();
    
    console.log('Chat inicializado com sucesso!');
}

// Função para criar nova conversa
function createNewChat() {
    const conversation = {
        id: Date.now(),
        title: 'Nova Conversa',
        messages: []
    };
    
    conversations.unshift(conversation);
    currentConversation = conversation;
    
    // Limpar mensagens
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = '';
        
    // Limpar input
    const chatInput = document.getElementById('chat_message_input');
    chatInput.value = '';
    
    // Atualizar lista de conversas
    updateConversationList();
}

// Função para adicionar mensagem ao chat com efeito de digitação
async function addMessage(message, isUser = false) {
    const chatMessages = document.getElementById('chat_messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user' : ''}`;
    
    const time = new Date().toLocaleTimeString('pt-BR', { 
        hour: '2-digit', 
        minute: '2-digit' 
    });
    
    // Se for mensagem do usuário, mostrar imediatamente
    if (isUser) {
        messageDiv.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-user"></i>
            </div>
            <div class="message-container">
                <div class="message-name">Você</div>
                <div class="message-content">
                    ${message}
                    <div class="message-time">${time}</div>
                </div>
            </div>
        `;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        return;
    }
    
    // Se for mensagem da IA, adicionar à fila
    messageQueue.push({
        message,
        time,
        element: messageDiv
    });
    
    // Processar fila se não estiver processando
    if (!isProcessingQueue) {
        processMessageQueue();
    }
}

// Função para processar a fila de mensagens
async function processMessageQueue() {
    if (messageQueue.length === 0) {
        isProcessingQueue = false;
        hideSkipButton();
        isTyping = false;
        return;
    }
    
    isProcessingQueue = true;
    isTyping = true;
    showSkipButton(); // Mostra o botão no início do processamento
    
    const { message, time, element } = messageQueue.shift();
    
    // Criar estrutura base da mensagem
    element.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-container">
            <div class="message-name">IPPEL IA</div>
            <div class="message-content">
                <span class="typing-text"></span>
                <div class="message-time">${time}</div>
            </div>
        </div>
    `;
    
    const chatMessages = document.getElementById('chat_messages');
    chatMessages.appendChild(element);
    
    // Efeito de digitação otimizado
    const typingText = element.querySelector('.typing-text');
    const words = message.split(' ');
    let currentText = '';
    
    for (let i = 0; i < words.length && isTyping; i++) {
        const word = words[i] + (i < words.length - 1 ? ' ' : '');
        for (let char of word) {
            if (!isTyping) break;
            currentText += char;
            typingText.textContent = currentText;
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            if (!shouldSkipAnimation) {
                await new Promise(resolve => setTimeout(resolve, 
                    Math.random() * (TYPING_SPEED.MAX - TYPING_SPEED.MIN) + TYPING_SPEED.MIN
                ));
            }
        }
    }
    
    // Se a animação foi pulada, mostrar todo o texto
    if (shouldSkipAnimation) {
        typingText.textContent = message;
    }
    
    // Processar próxima mensagem na fila
    setTimeout(() => processMessageQueue(), shouldSkipAnimation ? 0 : 200);
}

// Função para mostrar indicador de digitação
function showTypingIndicator() {
    const chatMessages = document.getElementById('chat_messages');
    const typingDiv = document.createElement('div');
    typingDiv.id = 'typingIndicator';
    typingDiv.className = 'message';
    typingDiv.innerHTML = `
        <div class="message-avatar">
            <i class="fas fa-robot"></i>
        </div>
        <div class="message-container">
            <div class="message-name">IPPEL IA</div>
            <div class="message-content">
                <div class="typing-indicator">
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                    <div class="typing-dot"></div>
                </div>
            </div>
        </div>
    `;
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    showSkipButton(); // Mostra o botão durante o indicador de digitação
}

// Função para remover indicador de digitação
function removeTypingIndicator() {
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) {
        typingIndicator.style.opacity = '0';
        typingIndicator.style.transform = 'translateY(10px)';
        setTimeout(() => {
            typingIndicator.remove();
            if (!isProcessingQueue) {
                hideSkipButton(); // Esconde o botão se não houver mais mensagens
            }
        }, 200);
    }
}

// Função para mostrar o botão de pular
function showSkipButton() {
    const skipBtn = document.getElementById('skipAnimationBtn');
    if (skipBtn) {
        skipBtn.style.display = 'flex';
        skipBtn.style.opacity = '1';
        skipBtn.style.cursor = 'pointer';
        skipBtn.disabled = false;
    }
}

// Função para esconder o botão de pular
function hideSkipButton() {
    const skipBtn = document.getElementById('skipAnimationBtn');
    if (skipBtn) {
        skipBtn.style.opacity = '0';
        setTimeout(() => {
            skipBtn.style.display = 'none';
            shouldSkipAnimation = false;
        }, 300);
    }
}

// Função para enviar mensagem
async function sendMessage() {
    const input = document.getElementById('chat_message_input');
    const message = input.value.trim();
    
    if (!message || isTyping) return;
    
    // Limpar input e desabilitar
    input.value = '';
    input.disabled = true;
    
    // Adicionar mensagem do usuário
    addMessage(message, true);
    
    // Mostrar indicador de digitação
    isTyping = true;
    showTypingIndicator();
    
    try {
        // Processar a mensagem para verificar se é um pedido de relatório
        await processMessage(message);
        
        // Habilitar input novamente
        input.disabled = false;
        input.focus();
        
    } catch (error) {
        console.error('Erro:', error);
        removeTypingIndicator();
        isTyping = false;
        input.disabled = false;
        input.focus();
        hideSkipButton();
        
        addMessage('Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente.');
    }
}

// Função para processar a mensagem e verificar se precisa gerar relatório
async function processMessage(message) {
    // Palavras-chave que indicam pedido de relatório
    const reportKeywords = [
        'relatório', 'gráfico', 'análise', 'dados',
        'quem comprou', 'vendas', 'comparação', 'estatísticas',
        'desempenho', 'resultado', 'performance', 'ranking'
    ];

    // Verifica se a mensagem contém palavras-chave de relatório
    const isReportRequest = reportKeywords.some(keyword => 
        message.toLowerCase().includes(keyword.toLowerCase())
    );

    try {
        // Faz a requisição para a API apropriada
        const endpoint = isReportRequest ? '/api/analyze' : '/api/chat';
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query: message, message: message })
        });
        
        if (!response.ok) {
            throw new Error(`Erro na requisição: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Remove o indicador de digitação
        removeTypingIndicator();
        isTyping = false;
        
        // Adiciona a resposta da IA
        addMessage(data.response);
        
        // Se houver dados de relatório, gera o relatório visual
        if (data.reportData) {
            generateReport(data.reportData);
            
            // Rola a página para mostrar o relatório
            const reportsContainer = document.getElementById('ai_reports');
            reportsContainer.scrollIntoView({ behavior: 'smooth' });
        }
    } catch (error) {
        throw error; // Propaga o erro para ser tratado em sendMessage
    }
}

// Função para gerar o relatório visual
function generateReport(data) {
    const reportContent = document.getElementById('report_content');
    const downloadBtn = document.getElementById('downloadBtn');
    const shareBtn = document.getElementById('shareBtn');
    
    // Limpa o conteúdo anterior
    reportContent.innerHTML = '';
    
    // Cria o container do gráfico
    const chartContainer = document.createElement('div');
    chartContainer.className = 'report-chart';
    chartContainer.style.height = '400px'; // Altura fixa para o gráfico
    
    // Adiciona o cabeçalho do gráfico
    const chartHeader = document.createElement('div');
    chartHeader.className = 'report-chart-header';
    chartHeader.innerHTML = `
        <div class="report-chart-title">${data.title}</div>
        <div class="report-chart-period">${data.period}</div>
    `;
    chartContainer.appendChild(chartHeader);
    
    // Cria o canvas para o gráfico
    const canvas = document.createElement('canvas');
    chartContainer.appendChild(canvas);
    reportContent.appendChild(chartContainer);
    
    // Configura o gráfico usando Chart.js
    new Chart(canvas, {
        type: data.chartType || 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: data.datasetLabel,
                data: data.values,
                backgroundColor: generateGradientColors(data.values.length),
                borderColor: 'rgba(220, 38, 38, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: data.title
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'R$ ' + value.toLocaleString('pt-BR');
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
    
    // Mostra os botões de ação
    downloadBtn.style.display = 'flex';
    shareBtn.style.display = 'flex';
    
    // Adiciona animação de entrada
    chartContainer.style.opacity = '0';
    chartContainer.style.transform = 'translateY(20px)';
    setTimeout(() => {
        chartContainer.style.transition = 'all 0.5s ease';
        chartContainer.style.opacity = '1';
        chartContainer.style.transform = 'translateY(0)';
    }, 100);
}

// Função para gerar cores gradiente
function generateGradientColors(count) {
    const colors = [];
    const baseColor = [220, 38, 38]; // RGB para #dc2626
    
    for (let i = 0; i < count; i++) {
        const opacity = 0.7 + (i * 0.3 / count);
        colors.push(`rgba(${baseColor[0]}, ${baseColor[1]}, ${baseColor[2]}, ${opacity})`);
    }
    
    return colors;
}

// Função para baixar o relatório
function downloadReport() {
    const canvas = document.querySelector('.report-chart canvas');
    if (!canvas) return;
    
    // Converte o canvas para imagem
    const image = canvas.toDataURL('image/png');
    
    // Cria um link para download
    const link = document.createElement('a');
    link.download = 'relatorio-ippel.png';
    link.href = image;
    link.click();
}

// Função para compartilhar o relatório
function shareReport() {
    const canvas = document.querySelector('.report-chart canvas');
    if (!canvas) return;
    
    // Converte o canvas para blob
    canvas.toBlob(async (blob) => {
        try {
            // Tenta usar a API de compartilhamento
            if (navigator.share) {
                const file = new File([blob], 'relatorio-ippel.png', { type: 'image/png' });
                await navigator.share({
                    title: 'Relatório IPPEL',
                    text: 'Confira este relatório gerado pela IA da IPPEL Equipamentos',
                    files: [file]
                });
            } else {
                // Fallback: copia o link
                const reader = new FileReader();
                reader.onload = function(e) {
                    const textarea = document.createElement('textarea');
                    textarea.value = e.target.result;
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    alert('Link do relatório copiado para a área de transferência!');
                };
                reader.readAsDataURL(blob);
            }
        } catch (error) {
            console.error('Erro ao compartilhar:', error);
            alert('Não foi possível compartilhar o relatório. Por favor, tente baixá-lo.');
        }
    });
}

// Função para pesquisar conversas
function searchConversations() {
    const searchInput = document.getElementById('dash_chat_search');
    const searchTerm = searchInput.value.toLowerCase().trim();
    
    const conversationList = document.getElementById('conversationList');
    conversationList.innerHTML = '';
    
    conversations.forEach(conversation => {
        if (!searchTerm || 
            conversation.title.toLowerCase().includes(searchTerm) ||
            conversation.messages.some(msg => msg.content.toLowerCase().includes(searchTerm))) {
            
            const conversationItem = document.createElement('div');
            conversationItem.className = 'conversation-item';
            if (conversation === currentConversation) {
                conversationItem.classList.add('active');
            }
            
            conversationItem.innerHTML = `
                <div class="conversation-title">${conversation.title}</div>
                <div class="conversation-date">${new Date(conversation.id).toLocaleDateString()}</div>
                <button class="delete-conversation" onclick="deleteConversation(${conversation.id})">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            
            conversationItem.addEventListener('click', () => loadConversation(conversation));
            
            conversationList.appendChild(conversationItem);
        }
    });
}

// Função para carregar conversa
function loadConversation(conversation) {
    currentConversation = conversation;
    
    // Limpar mensagens
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = '';
    
    // Carregar mensagens da conversa
    conversation.messages.forEach(message => {
        addMessage(message.content, message.type === 'user');
    });
    
    // Atualizar lista de conversas
    updateConversationList();
}

// Função para deletar conversa
function deleteConversation(id) {
    if (confirm('Tem certeza que deseja excluir esta conversa?')) {
        conversations = conversations.filter(conv => conv.id !== id);
        
        if (currentConversation && currentConversation.id === id) {
            if (conversations.length > 0) {
                loadConversation(conversations[0]);
            } else {
                createNewChat();
            }
        } else {
            updateConversationList();
        }
    }
}

// Função para atualizar lista de conversas
function updateConversationList() {
    const conversationList = document.getElementById('conversationList');
    conversationList.innerHTML = '';
    
    conversations.forEach(conversation => {
        const conversationItem = document.createElement('div');
        conversationItem.className = 'conversation-item';
        if (conversation === currentConversation) {
            conversationItem.classList.add('active');
        }
        
        conversationItem.innerHTML = `
            <div class="conversation-title">${conversation.title}</div>
            <div class="conversation-date">${new Date(conversation.id).toLocaleDateString()}</div>
            <button class="delete-conversation" onclick="deleteConversation(${conversation.id})">
                <i class="fas fa-trash"></i>
            </button>
        `;
        
        conversationItem.addEventListener('click', () => loadConversation(conversation));
        
        conversationList.appendChild(conversationItem);
    });
}

// Inicializar eventos quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    const input = document.getElementById('chat_message_input');
    const sendButton = document.querySelector('.send-btn');
    const skipBtn = document.getElementById('skipAnimationBtn');
    
    // Enviar mensagem ao pressionar Enter
    input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
        
    // Evento para o botão de pular animação
    skipBtn.addEventListener('click', function() {
        shouldSkipAnimation = true;
        this.style.opacity = '0.5';
        this.style.cursor = 'default';
        this.disabled = true;
    });
    
    // Efeito de hover no botão de enviar
    sendButton.addEventListener('mouseover', function() {
        this.style.transform = 'translateY(-1px)';
    });
    
    sendButton.addEventListener('mouseout', function() {
        this.style.transform = 'translateY(0)';
    });
    
    // Efeito de clique no botão
    sendButton.addEventListener('mousedown', function() {
        this.style.transform = 'translateY(1px)';
    });
    
    sendButton.addEventListener('mouseup', function() {
        this.style.transform = 'translateY(-1px)';
    });
    
    // Foco inicial no input
    input.focus();
});

// Inicializar chat quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', initChat); 