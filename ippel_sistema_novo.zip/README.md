# Dashboard IPPEL

Sistema de dashboard e atendimento ao cliente da IPPEL Equipamentos.

## Estrutura do Projeto

- `server_new.py`: Servidor principal Flask
- `database.py`: Gerenciamento do banco de dados
- `ippel.db`: Banco de dados SQLite
- `templates/`: Diretório com templates HTML
- `static/`: Diretório com arquivos estáticos (CSS, JS, etc)
- `gpt4free-main/`: Biblioteca para funcionalidade de chat
- `check_data.py`: Utilitário para obtenção de dados

## Requisitos

- Python 3.8+
- Flask
- SQLite3
- Outras dependências listadas em requirements.txt

## Instalação

1. Clone o repositório
2. Instale as dependências:
```bash
pip install -r requirements.txt
```

## Execução

Para iniciar o servidor:
```bash
python server_new.py
```

O servidor estará disponível em `http://localhost:5000`

## Funcionalidades Principais

- Dashboard com métricas de vendas
- Gerenciamento de clientes
- Gerenciamento de produtos
- Histórico de vendas
- Relatórios
- Chat de atendimento com IA 