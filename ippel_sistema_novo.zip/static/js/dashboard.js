// Namespace para o dashboard
window.Dashboard = window.Dashboard || {};

// Função para formatar valores monetários
function formatMoney(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value || 0);
}

// Função para formatar datas
function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Função para atualizar métricas do dashboard
async function updateMetrics() {
    console.log('📊 Iniciando atualização de métricas...');
    try {
        const response = await fetch('/api/dados/dashboard');
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const data = await response.json();
        console.log('✅ Dados recebidos:', data);

        // Atualizar cards
        const totalVendas = document.getElementById('totalVendas');
        const totalProdutos = document.getElementById('totalProdutos');
        const totalClientes = document.getElementById('totalClientes');
        const totalEstoque = document.getElementById('totalEstoque');

        if (totalVendas) totalVendas.textContent = formatMoney(data.vendas_total?.valor_total || 0);
        if (totalProdutos) totalProdutos.textContent = data.vendas_total?.total_vendas || 0;
        if (totalClientes) totalClientes.textContent = data.total_clientes || 0;
        if (totalEstoque) totalEstoque.textContent = data.total_produtos || 0;

        console.log('✅ Métricas atualizadas com sucesso');
    } catch (error) {
        console.error('❌ Erro ao atualizar métricas:', error);
    }
}

// Função para atualizar tabela de vendas recentes
async function updateVendas() {
    console.log('📋 Iniciando atualização de vendas recentes...');
    try {
        const response = await fetch('/api/dados/vendas');
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        const vendas = await response.json();
        console.log('✅ Dados de vendas recebidos:', vendas);

        const recentSalesTable = document.getElementById('recentSalesTable');
        if (!recentSalesTable) {
            console.warn('⚠️ Tabela de vendas recentes não encontrada');
            return;
        }

        if (vendas && vendas.length > 0) {
            const vendasRecentes = vendas
                .sort((a, b) => new Date(b.data_venda) - new Date(a.data_venda))
                .slice(0, 5);

            recentSalesTable.innerHTML = vendasRecentes.map((venda, index) => `
                <tr style="animation-delay: ${index * 0.1}s;" class="fade-in-up">
                    <td>#${venda.id || index + 1}</td>
                    <td>${venda.cliente_nome || 'Cliente ' + (venda.cliente_id || 'N/A')}</td>
                    <td>${venda.produto_modelo || venda.produto_categoria || 'Produto ' + (venda.produto_id || 'N/A')}</td>
                    <td>${formatMoney(venda.valor_total || venda.quantidade * (venda.preco || 0))}</td>
                    <td>${formatDate(venda.data_venda)}</td>
                    <td><span class="badge-modern badge-success">✅ Concluída</span></td>
                </tr>
            `).join('');

            console.log('✅ Tabela de vendas atualizada com sucesso');
        } else {
            recentSalesTable.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; padding: 2rem; color: #6b7280;">
                        <div style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;">🛒</div>
                        <div style="font-size: 1.1rem; font-weight: 600; margin-bottom: 0.5rem;">
                            Nenhuma venda encontrada
                        </div>
                        <div style="font-size: 0.9rem; opacity: 0.7; margin-bottom: 1rem;">
                            Use o formulário "Nova Venda" acima para registrar a primeira venda
                        </div>
                        <div style="font-size: 0.8rem; opacity: 0.5; font-style: italic;">
                            Após criar uma venda, ela aparecerá automaticamente aqui
                        </div>
                    </td>
                </tr>
            `;
            console.log('ℹ️ Nenhuma venda encontrada');
        }
    } catch (error) {
        console.error('❌ Erro ao atualizar vendas:', error);
        const recentSalesTable = document.getElementById('recentSalesTable');
        if (recentSalesTable) {
            recentSalesTable.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; padding: 2rem; color: #ef4444;">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">⚠️</div>
                        <div>Erro ao carregar vendas recentes</div>
                    </td>
                </tr>
            `;
        }
    }
}

// Função para atualizar todos os dados do dashboard
async function updateDashboard() {
    console.log('🔄 Iniciando atualização do dashboard...');
    try {
        await Promise.all([
            updateMetrics(),
            updateVendas()
        ]);
        console.log('✅ Dashboard atualizado com sucesso');
        
        // Disparar evento de atualização
        document.dispatchEvent(new CustomEvent('dashboardUpdated', {
            detail: { timestamp: new Date().getTime() }
        }));
    } catch (error) {
        console.error('❌ Erro ao atualizar dashboard:', error);
    }
}

// Adiciona todas as funções ao namespace
Object.assign(window.Dashboard, {
    updateMetrics,
    updateVendas,
    updateDashboard,
    formatMoney,
    formatDate
});

// Atualiza o dashboard a cada 30 segundos
let updateInterval = setInterval(updateDashboard, 30000);

// Atualiza o dashboard quando a página carrega
document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM carregado - iniciando dashboard...');
    updateDashboard();
    
    // Adiciona listener para atualização manual
    const refreshButton = document.querySelector('.refresh-dashboard');
    if (refreshButton) {
        refreshButton.addEventListener('click', () => {
            console.log('🔄 Atualização manual solicitada...');
            refreshButton.classList.add('rotating');
            updateDashboard().finally(() => {
                setTimeout(() => {
                    refreshButton.classList.remove('rotating');
                }, 1000);
            });
        });
    }
});

// Limpa o intervalo quando a página é fechada
window.addEventListener('beforeunload', () => {
    clearInterval(updateInterval);
});

// Carregar dados do dashboard
async function carregarDados() {
    try {
        // Carregar dados do dashboard
        const dashboardResponse = await fetch('/api/dados/dashboard');
        const dashboardData = await dashboardResponse.json();
        
        // Atualizar estatísticas nos cards
        const cards = document.querySelectorAll('.dashboard-grid .card .metric-value');
        if (cards[0]) cards[0].textContent = formatMoney(dashboardData.vendas_mes?.valor_total || 0);
        if (cards[1]) cards[1].textContent = dashboardData.vendas_mes?.total_vendas || 0;
        if (cards[2]) cards[2].textContent = dashboardData.total_clientes || 0;
        if (cards[3]) cards[3].textContent = dashboardData.produtos_mais_vendidos?.filter(p => p.estoque < 5).length || 0;
        
        // Carregar produtos para o formulário
        const produtosResponse = await fetch('/api/dados/produtos');
        const produtos = await produtosResponse.json();
        const produtoSelect = document.getElementById('venda_produto_id');
        if (produtoSelect) {
            produtoSelect.innerHTML = produtos.map(p => 
                `<option value="${p.id}">${p.categoria} - ${p.modelo}</option>`
            ).join('');
        }
        
        // Carregar clientes para o formulário
        const clientesResponse = await fetch('/api/dados/clientes');
        const clientes = await clientesResponse.json();
        const clienteSelect = document.getElementById('venda_cliente_id');
        if (clienteSelect) {
            clienteSelect.innerHTML = clientes.map(c => 
                `<option value="${c.id}">${c.nome}</option>`
            ).join('');
        }
        
    } catch (error) {
        console.error('Erro ao carregar dados:', error);
        alert('Erro ao carregar dados. Por favor, tente novamente.');
    }
}

// Configurar formulários
document.addEventListener('DOMContentLoaded', () => {
    // Formulário de Vendas
    const vendaForm = document.getElementById('vendaForm');
    if (vendaForm) {
        vendaForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const venda = {
                produto_id: document.getElementById('venda_produto_id').value,
                cliente_id: document.getElementById('venda_cliente_id').value,
                quantidade: document.getElementById('venda_quantidade').value,
                desconto: document.getElementById('venda_desconto').value
            };
            
            try {
                const response = await fetch('/api/dados/vendas', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(venda)
                });
                
                if (response.ok) {
                    alert('Venda registrada com sucesso!');
                    vendaForm.reset();
                    carregarDados();
                } else {
                    const error = await response.json();
                    throw new Error(error.error || 'Erro ao registrar venda');
                }
            } catch (error) {
                console.error('Erro:', error);
                alert(error.message || 'Erro ao registrar venda. Por favor, tente novamente.');
            }
        });
    }
    
    // Formulário de Produtos
    const produtoForm = document.getElementById('produtoForm');
    if (produtoForm) {
        produtoForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const produto = {
                categoria: document.getElementById('produto_categoria').value,
                modelo: document.getElementById('produto_modelo').value,
                preco: document.getElementById('produto_preco').value,
                estoque: document.getElementById('produto_estoque').value
            };
            
            try {
                const response = await fetch('/api/produtos', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(produto)
                });
                
                if (response.ok) {
                    alert('Produto adicionado com sucesso!');
                    produtoForm.reset();
                    carregarDados();
                } else {
                    throw new Error('Erro ao adicionar produto');
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao adicionar produto. Por favor, tente novamente.');
            }
        });
    }
    
    // Formulário de Clientes
    const clienteForm = document.getElementById('clienteForm');
    if (clienteForm) {
        clienteForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const cliente = {
                nome: document.getElementById('cliente_nome').value,
                segmento: document.getElementById('cliente_segmento').value,
                regiao: document.getElementById('cliente_regiao').value,
                email: document.getElementById('cliente_email').value,
                telefone: document.getElementById('cliente_telefone').value,
                endereco: document.getElementById('cliente_endereco').value
            };
            
            try {
                const response = await fetch('/api/dados/clientes', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(cliente)
                });
                
                if (response.ok) {
                    alert('Cliente adicionado com sucesso!');
                    clienteForm.reset();
                    carregarDados();
                } else {
                    const error = await response.json();
                    throw new Error(error.error || 'Erro ao adicionar cliente');
                }
            } catch (error) {
                console.error('Erro:', error);
                alert(error.message || 'Erro ao adicionar cliente. Por favor, tente novamente.');
            }
        });
    }
    
    // Configurações do Usuário
    const configForm = document.getElementById('configForm');
    if (configForm) {
        configForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const config = {
                user_name: document.getElementById('config_user_name').value,
                user_email: document.getElementById('config_user_email').value,
                user_role: document.getElementById('config_user_role').value,
                theme: document.getElementById('config_theme').value,
                language: document.getElementById('config_language').value,
                auto_update: document.getElementById('config_auto_update').value,
                email_notifications: document.getElementById('config_email_notifications').value
            };
            
            try {
                const response = await fetch('/api/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(config)
                });
                
                if (response.ok) {
                    alert('Configurações salvas com sucesso!');
                } else {
                    throw new Error('Erro ao salvar configurações');
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao salvar configurações. Por favor, tente novamente.');
            }
        });
    }
});

// Inicialização do dashboard
document.addEventListener('DOMContentLoaded', async () => {
    try {
        console.log('Inicializando dashboard...');
        
        // Verificar se estamos na página do dashboard
        const dashboardElement = document.getElementById('dashboard');
        if (!dashboardElement || !dashboardElement.classList.contains('active')) {
            console.log('Página do dashboard não está ativa');
            return;
        }

        // Carregar dados do dashboard
        const response = await fetch('/api/dados/dashboard');
        if (!response.ok) {
            throw new Error(`Erro ao carregar dados: ${response.status}`);
        }
        
        const dashboardData = await response.json();
        
        // Atualizar cards com informações principais
        updateDashboardCards(dashboardData);
        
        console.log('Dashboard inicializado com sucesso!');
        
    } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
        // Mostrar mensagem de erro mais amigável
        const errorMessage = document.createElement('div');
        errorMessage.className = 'error-message';
        errorMessage.textContent = 'Erro ao carregar dados do dashboard. Por favor, recarregue a página.';
        document.getElementById('dashboard').prepend(errorMessage);
    }
});

// Função para atualizar os cards do dashboard
function updateDashboardCards(data) {
    try {
        // Verificar se os elementos existem antes de tentar atualizá-los
        const elements = {
            totalVendas: document.getElementById('totalVendas'),
            totalProdutos: document.getElementById('totalProdutos'),
            totalClientes: document.getElementById('totalClientes'),
            totalEstoque: document.getElementById('totalEstoque')
        };

        // Verificar se todos os elementos necessários existem
        const missingElements = Object.entries(elements)
            .filter(([key, element]) => !element)
            .map(([key]) => key);

        if (missingElements.length > 0) {
            console.warn('Elementos não encontrados:', missingElements.join(', '));
        }

        // Atualizar vendas totais
        if (elements.totalVendas) {
            elements.totalVendas.textContent = formatMoney(data.vendas_totais || 0);
        }

        // Atualizar total de produtos
        if (elements.totalProdutos) {
            elements.totalProdutos.textContent = data.total_produtos || 0;
        }

        // Atualizar total de clientes
        if (elements.totalClientes) {
            elements.totalClientes.textContent = data.total_clientes || 0;
        }

        // Atualizar total em estoque
        if (elements.totalEstoque) {
            elements.totalEstoque.textContent = data.total_estoque || 0;
        }
    } catch (error) {
        console.error('Erro ao atualizar cards:', error);
    }
} 