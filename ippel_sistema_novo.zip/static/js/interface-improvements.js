// Interface Improvements - Melhorias de Interface
console.log('🎨 Interface Improvements iniciando...');

document.addEventListener('DOMContentLoaded', function() {
    console.log('🎨 Melhorias de interface carregadas!');
    
    // Aplicar melhorias gradualmente para performance
    setTimeout(() => addAnimationsToCards(), 100);
    setTimeout(() => addButtonEffects(), 200);
    setTimeout(() => enhanceFormInputs(), 300);
    setTimeout(() => addCardHoverEffects(), 400);
    setTimeout(() => setupNotificationSystem(), 500);
    setTimeout(() => addVisualEnhancements(), 600);
    setTimeout(() => enhanceFormSubmissions(), 700);
    setTimeout(() => animateCounters(), 1000);
});

// Função para adicionar animações aos cards
function addAnimationsToCards() {
    const cards = document.querySelectorAll('.card, .metric-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        card.style.transition = 'all 0.6s ease-out';
        
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100 + 200);
    });
}

// Função para melhorar botões
function addButtonEffects() {
    const buttons = document.querySelectorAll('.btn-primary, .btn-success, .btn-info, .btn-secondary');
    buttons.forEach(button => {
        // Efeito hover melhorado
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-3px)';
            this.style.transition = 'all 0.3s ease';
            this.style.boxShadow = '0 8px 25px rgba(0, 0, 0, 0.2)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '';
        });

        // Não interferir com o comportamento dos formulários
        // O loading state será gerenciado pelos próprios formulários
    });
}

// Função para melhorar formulários sem quebrar funcionalidade
function enhanceFormSubmissions() {
    // Interceptar apenas DEPOIS que o formulário for processado
    const forms = document.querySelectorAll('#vendaForm, #produtoForm, #clienteForm');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                const originalText = submitButton.innerHTML;
                
                // Adicionar spinner sem desabilitar
                setTimeout(() => {
                    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
                    submitButton.style.opacity = '0.8';
                }, 100);
                
                // Restaurar após um tempo menor
                setTimeout(() => {
                    submitButton.innerHTML = originalText;
                    submitButton.style.opacity = '1';
                }, 1500);
            }
        });
    });
}

// Função para melhorar inputs
function enhanceFormInputs() {
    const inputs = document.querySelectorAll('.form-input, .form-control, .form-select');
    inputs.forEach(input => {
        // Micro interações no foco
        input.addEventListener('focus', function() {
            this.style.transform = 'translateY(-2px)';
            this.style.transition = 'all 0.3s ease';
            this.style.boxShadow = '0 4px 12px rgba(220, 38, 38, 0.15)';
            
            // Escalar o container pai levemente
            if (this.parentElement) {
                this.parentElement.style.transform = 'scale(1.02)';
                this.parentElement.style.transition = 'transform 0.3s ease';
            }
        });
        
        input.addEventListener('blur', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '';
            
            if (this.parentElement) {
                this.parentElement.style.transform = 'scale(1)';
            }
        });

        // Validação visual em tempo real
        input.addEventListener('input', function() {
            if (this.value.length > 0) {
                this.style.borderColor = '#10b981';
                this.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.1)';
            } else {
                this.style.borderColor = '';
                this.style.boxShadow = '';
            }
        });
    });
}

// Função para efeitos de hover nos cards
function addCardHoverEffects() {
    const cards = document.querySelectorAll('.metric-card, .card');
    cards.forEach(card => {
        card.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
        
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '';
        });
    });
}

// Sistema de notificações moderno
function setupNotificationSystem() {
    window.showNotification = function(message, type = 'success') {
        // Remover notificações existentes
        const existing = document.querySelectorAll('.notification-toast');
        existing.forEach(n => n.remove());
        
        const notification = document.createElement('div');
        notification.className = 'notification-toast';
        
        // Ícone baseado no tipo
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        
        notification.innerHTML = `
            <i class="fas fa-${icons[type] || icons.info}"></i>
            <span>${message}</span>
        `;
        
        // Cores baseadas no tipo
        const colors = {
            success: 'linear-gradient(135deg, #059669, #10b981)',
            error: 'linear-gradient(135deg, #dc2626, #ef4444)',
            warning: 'linear-gradient(135deg, #d97706, #f59e0b)',
            info: 'linear-gradient(135deg, #0284c7, #0ea5e9)'
        };
        
        // Aplicar estilos
        notification.style.cssText = `
            position: fixed;
            top: 2rem;
            right: 2rem;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            color: white;
            font-weight: 600;
            font-family: 'Inter', sans-serif;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
            transform: translateX(400px);
            transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 10000;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            max-width: 350px;
            background: ${colors[type] || colors.info};
            backdrop-filter: blur(10px);
        `;
        
        document.body.appendChild(notification);
        
        // Animação de entrada
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Animação de saída
        setTimeout(() => {
            notification.style.transform = 'translateX(400px)';
            setTimeout(() => notification.remove(), 400);
        }, 3500);
    };
}

// Melhorias visuais gerais
function addVisualEnhancements() {
    // Melhorar tabelas vazias
    const tables = document.querySelectorAll('table tbody');
    tables.forEach(tbody => {
        if (tbody.children.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="100%" style="text-align: center; padding: 3rem; color: #6b7280;">
                        <div style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;">📊</div>
                        <div style="font-size: 1.2rem; font-weight: 600; margin-bottom: 0.5rem; color: #374151;">
                            Nenhum dado encontrado
                        </div>
                        <div style="font-size: 0.9rem; opacity: 0.7;">
                            Os dados aparecerão aqui quando estiverem disponíveis
                        </div>
                    </td>
                </tr>
            `;
        }
    });

    // Adicionar tooltips informativos
    const tooltipElements = [
        { selector: '.metric-icon', text: 'Métrica em tempo real do sistema' },
        { selector: '.nav-link i', text: 'Clique para navegar para esta seção' },
        { selector: '.chart-btn', text: 'Alterar tipo de visualização' }
    ];
    
    tooltipElements.forEach(item => {
        const elements = document.querySelectorAll(item.selector);
        elements.forEach(element => {
            element.title = item.text;
            element.style.cursor = 'pointer';
        });
    });

    // Melhorar navegação com feedback visual
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Remover active de todos
            navLinks.forEach(l => l.classList.remove('active'));
            
            // Adicionar active no clicado
            this.classList.add('active');
            
            // Feedback visual imediato
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = 'scale(1)';
            }, 150);
        });
    });

    // Melhorar formulários com estados visuais
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const button = this.querySelector('button[type="submit"]');
            if (button) {
                // Feedback táctil
                button.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    button.style.transform = 'scale(1)';
                }, 100);
            }
        });
    });
}

// Contador animado para números
function animateCounters() {
    const counters = document.querySelectorAll('.metric-value');
    counters.forEach(counter => {
        const text = counter.textContent;
        const numbers = text.match(/[\d,]+/g);
        
        if (numbers && numbers.length > 0) {
            const finalNumber = parseInt(numbers[0].replace(/,/g, '')) || 0;
            if (finalNumber > 0) {
                animateNumber(counter, 0, finalNumber, 1500, text);
            }
        }
    });
}

function animateNumber(element, start, end, duration, template) {
    let startTime = null;
    
    function animation(currentTime) {
        if (!startTime) startTime = currentTime;
        const progress = Math.min((currentTime - startTime) / duration, 1);
        
        // Função de easing para suavizar a animação
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        const current = Math.floor(easeOutQuart * (end - start) + start);
        
        // Manter formato original (com R$, %, etc.)
        let newText = template;
        const originalNumber = template.match(/[\d,]+/g);
        if (originalNumber) {
            newText = template.replace(originalNumber[0], current.toLocaleString('pt-BR'));
        }
        
        element.textContent = newText;
        
        if (progress < 1) {
            requestAnimationFrame(animation);
        }
    }
    
    requestAnimationFrame(animation);
}

// Melhorar acessibilidade
function enhanceAccessibility() {
    const focusableElements = document.querySelectorAll('button, a, input, select, textarea');
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid #dc2626';
            this.style.outlineOffset = '2px';
            this.style.transition = 'outline 0.2s ease';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = 'none';
        });
    });
}

// Otimizar performance de scroll
function optimizeScrollPerformance() {
    let ticking = false;
    
    function handleScroll() {
        if (!ticking) {
            requestAnimationFrame(() => {
                const scrolled = window.pageYOffset;
                
                // Efeito parallax sutil nos headers
                const headers = document.querySelectorAll('.header');
                headers.forEach(header => {
                    header.style.transform = `translateY(${scrolled * 0.05}px)`;
                });
                
                ticking = false;
            });
            ticking = true;
        }
    }
    
    window.addEventListener('scroll', handleScroll, { passive: true });
}

// Inicializar melhorias quando tudo estiver carregado
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        enhanceAccessibility();
        optimizeScrollPerformance();
    });
} else {
    enhanceAccessibility();
    optimizeScrollPerformance();
}

// Mensagem de boas-vindas após carregamento completo
setTimeout(() => {
    if (window.showNotification) {
        showNotification('🎉 Interface moderna carregada com sucesso!', 'success');
    }
}, 2000);

console.log('✨ Interface Improvements carregado completamente!');
 