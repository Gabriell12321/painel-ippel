// UI Enhancements - Melhorias de Interface e Interações
document.addEventListener('DOMContentLoaded', function() {
    console.log('🎨 UI Enhancements carregado!');
    
    // Aplicar classes de animação aos cards existentes
    addAnimationsToCards();
    
    // Adicionar efeitos aos botões
    addButtonEffects();
    
    // Melhorar inputs com validação visual
    enhanceFormInputs();
    
    // Adicionar tooltips dinâmicos
    addTooltips();
    
    // Aplicar efeitos de hover aos cards
    addCardHoverEffects();
    
    // Adicionar loading states
    addLoadingStates();
    
    // Sistema de notificações
    setupNotificationSystem();
    
    // Contador animado para métricas
    animateCounters();
    
    // Observador para animações de entrada
    setupIntersectionObserver();
});

// Função para adicionar animações aos cards
function addAnimationsToCards() {
    const cards = document.querySelectorAll('.card, .metric-card');
    cards.forEach((card, index) => {
        // Adicionar delay escalonado
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in-up');
        
        // Adicionar classe de hover effect
        card.classList.add('card-hover-effect');
    });
}

// Função para melhorar botões
function addButtonEffects() {
    const buttons = document.querySelectorAll('.btn-primary, .btn-success, .btn-info, .btn-secondary');
    buttons.forEach(button => {
        // Adicionar efeito ripple
        button.classList.add('btn-ripple');
        
        // Adicionar micro bounce
        button.classList.add('micro-bounce');
        
        // Event listener para loading state
        button.addEventListener('click', function() {
            if (this.type === 'submit') {
                this.classList.add('loading');
                
                // Remover loading após 2 segundos (para demo)
                setTimeout(() => {
                    this.classList.remove('loading');
                }, 2000);
            }
        });
    });
}

// Função para melhorar inputs
function enhanceFormInputs() {
    const inputs = document.querySelectorAll('.form-input, .form-control');
    inputs.forEach(input => {
        // Adicionar validação visual
        input.classList.add('form-input-validated');
        
        // Event listeners para validação
        input.addEventListener('input', function() {
            if (this.value.length > 0) {
                if (this.checkValidity()) {
                    this.classList.remove('invalid');
                    this.classList.add('valid');
                } else {
                    this.classList.remove('valid');
                    this.classList.add('invalid');
                }
            } else {
                this.classList.remove('valid', 'invalid');
            }
        });
        
        // Adicionar foco com micro interação
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });
    });
}

// Função para adicionar tooltips
function addTooltips() {
    const elementsWithTooltips = [
        { selector: '.metric-icon', text: 'Clique para mais detalhes' },
        { selector: '.chart-btn', text: 'Alterar tipo de gráfico' },
        { selector: '.nav-link', text: 'Navegar para seção' }
    ];
    
    elementsWithTooltips.forEach(item => {
        const elements = document.querySelectorAll(item.selector);
        elements.forEach(element => {
            element.classList.add('tooltip-custom');
            element.setAttribute('data-tooltip', item.text);
        });
    });
}

// Função para adicionar efeitos de hover aos cards
function addCardHoverEffects() {
    const metricCards = document.querySelectorAll('.metric-card');
    metricCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-12px) scale(1.03)';
            this.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });
}

// Função para adicionar estados de loading
function addLoadingStates() {
    const tables = document.querySelectorAll('table');
    tables.forEach(table => {
        table.classList.add('custom-scrollbar');
        
        // Simular loading para demonstração
        const tbody = table.querySelector('tbody');
        if (tbody && tbody.children.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="100%" style="text-align: center; padding: 2rem;">
                        <div class="loading-shimmer" style="height: 20px; margin-bottom: 10px;"></div>
                        <div class="loading-shimmer" style="height: 20px; width: 80%; margin: 0 auto 10px;"></div>
                        <div class="loading-shimmer" style="height: 20px; width: 60%; margin: 0 auto;"></div>
                    </td>
                </tr>
            `;
        }
    });
}

// Sistema de notificações
function setupNotificationSystem() {
    window.showNotification = function(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification-toast notification-${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Mostrar notificação
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Remover após 3 segundos
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    };
}

// Contador animado para métricas
function animateCounters() {
    const counters = document.querySelectorAll('.metric-value');
    
    const animateValue = (element, start, end, duration) => {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const currentValue = Math.floor(progress * (end - start) + start);
            
            if (element.textContent.includes('R$')) {
                element.textContent = `R$ ${currentValue.toLocaleString('pt-BR')}`;
            } else if (element.textContent.includes('%')) {
                element.textContent = `${currentValue}%`;
            } else {
                element.textContent = currentValue.toLocaleString('pt-BR');
            }
            
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    };
    
    counters.forEach(counter => {
        const text = counter.textContent;
        const number = parseInt(text.replace(/[^\d]/g, '')) || 0;
        if (number > 0) {
            animateValue(counter, 0, number, 2000);
        }
    });
}

// Observador de interseção para animações
function setupIntersectionObserver() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-up');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    // Observar todos os elementos que devem animar
    const elementsToAnimate = document.querySelectorAll('.form-group, .filters-advanced, .insights-section');
    elementsToAnimate.forEach(el => {
        observer.observe(el);
    });
}

// Função para aplicar tema escuro (se necessário)
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
}

// Função para melhorar performance de scroll
function optimizeScrollPerformance() {
    let ticking = false;
    
    function updateScrollPosition() {
        const scrollTop = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('.parallax');
        
        parallaxElements.forEach(element => {
            const speed = element.dataset.speed || 0.5;
            const yPos = -(scrollTop * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
        
        ticking = false;
    }
    
    function requestTick() {
        if (!ticking) {
            requestAnimationFrame(updateScrollPosition);
            ticking = true;
        }
    }
    
    window.addEventListener('scroll', requestTick);
}

// Função para adicionar gestão de estado visual
function addVisualStateManagement() {
    // Estado de loading para formulários
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitButton = this.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.classList.add('loading');
                submitButton.disabled = true;
                
                // Simular processamento
                setTimeout(() => {
                    submitButton.classList.remove('loading');
                    submitButton.disabled = false;
                    showNotification('✅ Operação realizada com sucesso!', 'success');
                }, 2000);
            }
        });
    });
}

// Função para melhorar acessibilidade
function enhanceAccessibility() {
    // Adicionar navegação por teclado
    const interactiveElements = document.querySelectorAll('button, a, input, select, textarea');
    interactiveElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.classList.add('focus-visible');
        });
        
        element.addEventListener('blur', function() {
            this.classList.remove('focus-visible');
        });
    });
    
    // Adicionar skip links
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.className = 'skip-link';
    skipLink.textContent = 'Pular para conteúdo principal';
    document.body.insertBefore(skipLink, document.body.firstChild);
}

// Inicializar melhorias quando o DOM estiver carregado
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        addVisualStateManagement();
        enhanceAccessibility();
        optimizeScrollPerformance();
    });
} else {
    addVisualStateManagement();
    enhanceAccessibility();
    optimizeScrollPerformance();
}

// Exportar funções para uso global
window.UIEnhancements = {
    showNotification,
    toggleDarkMode,
    animateCounters
}; 