// Correção para carregamento de dados do dashboard
console.log('📄 DOM carregado - iniciando correções...');

// Garantir que os namespaces estejam limpos
window.DashboardFix = {
    // Função para atualizar vendas recentes
    updateRecentSales: async function() {
        console.log('📋 Atualizando vendas recentes...');
        
        try {
            // Buscar vendas com informações completas
            const response = await fetch('/api/dados/vendas');
            
            if (!response.ok) {
                console.error(`❌ Erro na API: ${response.status} ${response.statusText}`);
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const vendas = await response.json();
            console.log('✅ Vendas recebidas da API:', {
                total: vendas.length,
                data: vendas
            });
            
            const recentSalesTable = document.getElementById('recentSalesTable');
            if (recentSalesTable) {
                if (vendas && vendas.length > 0) {
                    // Ordenar vendas por data (mais recente primeiro) e pegar as 5 primeiras
                    const vendasRecentes = vendas
                        .sort((a, b) => new Date(b.data_venda) - new Date(a.data_venda))
                        .slice(0, 5);
                    
                    recentSalesTable.innerHTML = vendasRecentes.map((venda, index) => `
                        <tr style="animation-delay: ${index * 0.1}s;" class="fade-in-up">
                            <td>#${venda.id || index + 1}</td>
                            <td>${venda.cliente_nome || 'Cliente ' + (venda.cliente_id || 'N/A')}</td>
                            <td>${venda.produto_modelo || venda.produto_categoria || 'Produto ' + (venda.produto_id || 'N/A')}</td>
                            <td>${window.DashboardFix.formatMoney(venda.valor_total || venda.quantidade * (venda.preco || 0))}</td>
                            <td>${window.DashboardFix.formatDate(venda.data_venda)}</td>
                            <td><span class="badge-modern badge-success">✅ Concluída</span></td>
                        </tr>
                    `).join('');
                    
                    console.log(`📋 ${vendasRecentes.length} vendas recentes atualizadas`);
                } else {
                    recentSalesTable.innerHTML = `
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 2rem; color: #6b7280;">
                                <div style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;">🛒</div>
                                <div style="font-size: 1.1rem; font-weight: 600; margin-bottom: 0.5rem;">
                                    Nenhuma venda encontrada
                                </div>
                                <div style="font-size: 0.9rem; opacity: 0.7; margin-bottom: 1rem;">
                                    Use o formulário "Nova Venda" acima para registrar a primeira venda
                                </div>
                                <div style="font-size: 0.8rem; opacity: 0.5; font-style: italic;">
                                    Após criar uma venda, ela aparecerá automaticamente aqui
                                </div>
                            </td>
                        </tr>
                    `;
                    console.log('📋 Nenhuma venda encontrada - exibindo placeholder');
                }
            } else {
                console.warn('⚠️ Tabela de vendas recentes não encontrada');
            }
            
        } catch (error) {
            console.error('❌ Erro ao atualizar vendas recentes:', error);
            const recentSalesTable = document.getElementById('recentSalesTable');
            if (recentSalesTable) {
                recentSalesTable.innerHTML = `
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 2rem; color: #ef4444;">
                            <div style="font-size: 2rem; margin-bottom: 1rem;">⚠️</div>
                            <div>Erro ao carregar vendas recentes</div>
                        </td>
                    </tr>
                `;
            }
        }
    },

    // Função auxiliar para formatar data
    formatDate: function(dateString) {
        if (!dateString) return 'Data não informada';
        
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('pt-BR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            });
        } catch (error) {
            return dateString;
        }
    },

    // Função auxiliar para formatar dinheiro
    formatMoney: function(value) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value || 0);
    },

    // Função para inicializar
    init: function() {
        console.log('🚀 Inicializando DashboardFix...');
        
        // Verificar se estamos na página do dashboard
        const dashboardPage = document.getElementById('dashboard');
        if (dashboardPage && dashboardPage.classList.contains('active')) {
            this.updateRecentSales();
        }
    }
};

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    window.DashboardFix.init();
});

// Verificar se há conflitos de função
console.log('🔍 Verificando funções disponíveis:', {
    updateChart: typeof updateChart,
    updateMetrics: typeof updateMetrics,
    formatMoney: typeof formatMoney,
    dashboardUpdateChart: typeof window.Dashboard?.updateChart,
    reportsUpdateChart: typeof window.Reports?.updateReportChart
});

// Função para atualizar métricas
async function updateDashboardMetrics() {
    console.log('📊 Atualizando métricas do dashboard...');
    
    try {
        const response = await fetch('/api/dados/dashboard');
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('✅ Dados do dashboard recebidos:', data);

        // Selecionar elementos pelos IDs corretos
        const elements = {
            vendas: document.getElementById('totalVendas'),
            equipamentos: document.getElementById('totalProdutos'),
            clientes: document.getElementById('totalClientes'),
            estoque: document.getElementById('totalEstoque')
        };

        // Atualizar vendas totais
        if (elements.vendas) {
            const valorTotal = data.vendas_total?.valor_total || 0;
            elements.vendas.textContent = window.DashboardFix.formatMoney(valorTotal);
            console.log(`💰 Vendas atualizadas: ${window.DashboardFix.formatMoney(valorTotal)}`);
        } else {
            console.warn('⚠️ Elemento de vendas não encontrado');
        }

        // Atualizar equipamentos vendidos
        if (elements.equipamentos) {
            const totalVendas = data.vendas_total?.total_vendas || 0;
            elements.equipamentos.textContent = totalVendas;
            console.log(`🔧 Equipamentos atualizados: ${totalVendas}`);
        } else {
            console.warn('⚠️ Elemento de equipamentos não encontrado');
        }

        // Atualizar clientes ativos
        if (elements.clientes) {
            const totalClientes = data.total_clientes || 0;
            elements.clientes.textContent = totalClientes;
            console.log(`👥 Clientes atualizados: ${totalClientes}`);
        } else {
            console.warn('⚠️ Elemento de clientes não encontrado');
        }

        // Atualizar produtos em estoque (não estoque baixo)
        if (elements.estoque) {
            const totalProdutos = data.total_produtos || 0;
            elements.estoque.textContent = totalProdutos;
            console.log(`📦 Produtos em estoque atualizados: ${totalProdutos}`);
        } else {
            console.warn('⚠️ Elemento de produtos não encontrado');
        }

        // Atualizar vendas recentes
        await window.DashboardFix.updateRecentSales();

        return data;
        
    } catch (error) {
        console.error('❌ Erro ao atualizar métricas:', error);
        
        // Mostrar valores padrão em caso de erro
        const defaultElements = document.querySelectorAll('#dashboard .metric-value');
        defaultElements.forEach((el, index) => {
            if (el && el.textContent === 'R$ 1.257.830') {
                el.textContent = 'Erro';
            }
        });
    }
}

// Função para forçar atualização do dashboard
function forceDashboardUpdate() {
    console.log('🔄 Forçando atualização do dashboard...');
    
    // Aguardar um pouco para garantir que os elementos estão carregados
    setTimeout(() => {
        updateDashboardMetrics();
        
        // Tentar novamente após 2 segundos se necessário
        setTimeout(() => {
            const vendasElement = document.getElementById('totalVendas');
            if (vendasElement && (vendasElement.textContent === 'R$ 1.257.830' || vendasElement.textContent === 'Erro')) {
                console.log('🔄 Tentando atualização novamente...');
                updateDashboardMetrics();
            }
        }, 2000);
        
    }, 500);
}

// Sobrescrever a função updateDashboard existente usando namespace
if (typeof updateDashboard === 'function') {
    const originalUpdateDashboard = updateDashboard;
    updateDashboard = function() {
        console.log('🔄 updateDashboard chamado - executando versão corrigida');
        updateDashboardMetrics();
        
        // Sempre atualizar vendas recentes quando o dashboard for atualizado
        window.DashboardFix.updateRecentSales();
        
        // Usar namespace do Dashboard para evitar conflitos
        if (window.Dashboard && typeof window.Dashboard.updateVendas === 'function') {
            window.Dashboard.updateVendas();
        } else if (typeof updateVendas === 'function') {
            updateVendas();
        }
        
        // Verificar se estamos na página de dashboard antes de chamar updateChart
        const dashboardPage = document.getElementById('dashboard');
        if (dashboardPage && dashboardPage.classList.contains('active')) {
            // Usar namespace do Dashboard para gráficos
            if (window.Dashboard && typeof window.Dashboard.updateChart === 'function') {
                window.Dashboard.updateChart();
            } else if (typeof updateChart === 'function' && updateChart.length === 0) {
                // Só chama se for a função sem parâmetros (do dashboard)
                updateChart();
            }
        }
    };
    console.log('✅ Função updateDashboard substituída com namespace');
}

// Interceptar mudanças de página para dashboard
const originalShowPage = window.showPage;
if (originalShowPage) {
    window.showPage = function(pageId) {
        originalShowPage(pageId);
        if (pageId === 'dashboard') {
            console.log('📊 Página dashboard detectada - atualizando dados...');
            forceDashboardUpdate();
        }
    };
    console.log('✅ Função showPage interceptada');
}

// Interceptar função refreshData se existir
if (typeof refreshData === 'function') {
    const originalRefreshData = refreshData;
    window.refreshData = async function() {
        console.log('🔄 refreshData chamado - executando versão estendida');
        await originalRefreshData();
        
        // Sempre atualizar vendas recentes após refresh
        setTimeout(() => {
            window.DashboardFix.updateRecentSales();
        }, 500);
    };
    console.log('✅ Função refreshData interceptada');
}

// Atualizar automaticamente quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 DOM carregado - iniciando correções...');
    
    // Aguardar um pouco e então atualizar
    setTimeout(() => {
        if (document.getElementById('dashboard').classList.contains('active')) {
            console.log('📊 Dashboard está ativo - atualizando...');
            forceDashboardUpdate();
        }
    }, 1000);
});

// Interceptar formulários de venda para atualizar dashboard automaticamente
function setupFormInterceptors() {
    console.log('📝 Configurando interceptadores de formulários...');
    
    // Interceptar formulário do dashboard
    const dashboardVendaForm = document.getElementById('vendaForm');
    if (dashboardVendaForm) {
        dashboardVendaForm.addEventListener('submit', function(e) {
            console.log('📝 Formulário de venda submetido');
            
            // Aguardar um pouco após o submit e então atualizar o dashboard
            setTimeout(() => {
                console.log('🔄 Atualizando dashboard após nova venda...');
                forceDashboardUpdate();
                
                // Atualizar vendas recentes especificamente
                setTimeout(() => {
                    window.DashboardFix.updateRecentSales();
                }, 500);
                
                // Mostrar notificação de sucesso
                if (window.showNotification) {
                    showNotification('✅ Venda registrada! Atualizando vendas recentes...', 'success');
                } else {
                    console.log('✅ Venda registrada! Atualizando vendas recentes...');
                }
            }, 1000);
        });
        console.log('✅ Interceptador do formulário de venda configurado');
    } else {
        console.warn('⚠️ Formulário vendaForm não encontrado');
    }
    
    // Interceptar outros formulários de produto e cliente
    const dashboardProdutoForm = document.getElementById('produtoForm');
    if (dashboardProdutoForm) {
        dashboardProdutoForm.addEventListener('submit', function(e) {
            setTimeout(() => {
                forceDashboardUpdate();
                if (window.showNotification) {
                    showNotification('✅ Produto adicionado! Dashboard atualizado.', 'success');
                }
            }, 1000);
        });
    }
    
    const dashboardClienteForm = document.getElementById('clienteForm');
    if (dashboardClienteForm) {
        dashboardClienteForm.addEventListener('submit', function(e) {
            setTimeout(() => {
                forceDashboardUpdate();
                if (window.showNotification) {
                    showNotification('✅ Cliente adicionado! Dashboard atualizado.', 'success');
                }
            }, 1000);
        });
    }
}

// Configurar interceptadores quando o DOM carregar
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(setupFormInterceptors, 1500);
});

// Também executar quando o script carregar
setTimeout(() => {
    console.log('⏰ Timer de segurança - verificando dashboard...');
    const dashboardPage = document.getElementById('dashboard');
    if (dashboardPage && dashboardPage.classList.contains('active')) {
        forceDashboardUpdate();
    }
    
    // Configurar interceptadores se ainda não foram configurados
    setupFormInterceptors();
}, 2000);

// Expor função para uso global
window.forceDashboardUpdate = forceDashboardUpdate;
window.updateRecentSales = window.DashboardFix.updateRecentSales.bind(window.DashboardFix);

console.log('✅ Correções do dashboard carregadas com sucesso!'); 