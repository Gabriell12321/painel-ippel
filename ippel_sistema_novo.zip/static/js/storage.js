// Classe para gerenciar o armazenamento de conversas
class ChatStorage {
    constructor() {
        this.dbName = 'chatDB';
        this.dbVersion = 1;
        this.db = null;
    }

    // Inicializa o banco de dados
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onerror = () => {
                console.error("Erro ao abrir banco de dados");
                reject(request.error);
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                console.log("Banco de dados aberto com sucesso");
                resolve();
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Cria store para conversas
                if (!db.objectStoreNames.contains('conversations')) {
                    const conversationStore = db.createObjectStore('conversations', { keyPath: 'id', autoIncrement: true });
                    conversationStore.createIndex('timestamp', 'timestamp', { unique: false });
                }

                // Cria store para mensagens
                if (!db.objectStoreNames.contains('messages')) {
                    const messageStore = db.createObjectStore('messages', { keyPath: 'id', autoIncrement: true });
                    messageStore.createIndex('conversationId', 'conversationId', { unique: false });
                    messageStore.createIndex('timestamp', 'timestamp', { unique: false });
                }
            };
        });
    }

    // Cria uma nova conversa
    async createConversation() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['conversations'], 'readwrite');
            const store = transaction.objectStore('conversations');

            const conversation = {
                title: 'Nova Conversa',
                timestamp: Date.now()
            };

            const request = store.add(conversation);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Adiciona uma mensagem à conversa
    async addMessage(conversationId, content, isUser) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['messages'], 'readwrite');
            const store = transaction.objectStore('messages');

            const message = {
                conversationId,
                content,
                isUser,
                timestamp: Date.now()
            };

            const request = store.add(message);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Obtém todas as mensagens de uma conversa
    async getConversationMessages(conversationId) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['messages'], 'readonly');
            const store = transaction.objectStore('messages');
            const index = store.index('conversationId');
            const request = index.getAll(conversationId);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Obtém todas as conversas
    async getAllConversations() {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['conversations'], 'readonly');
            const store = transaction.objectStore('conversations');
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    // Atualiza o título de uma conversa
    async updateConversationTitle(conversationId, newTitle) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['conversations'], 'readwrite');
            const store = transaction.objectStore('conversations');
            const request = store.get(conversationId);

            request.onsuccess = () => {
                const conversation = request.result;
                conversation.title = newTitle;
                const updateRequest = store.put(conversation);
                updateRequest.onsuccess = () => resolve();
                updateRequest.onerror = () => reject(updateRequest.error);
            };

            request.onerror = () => reject(request.error);
        });
    }

    // Exclui uma conversa e suas mensagens
    async deleteConversation(conversationId) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['conversations', 'messages'], 'readwrite');
            
            // Deleta a conversa
            const conversationStore = transaction.objectStore('conversations');
            const deleteConversationRequest = conversationStore.delete(conversationId);

            // Deleta todas as mensagens da conversa
            const messageStore = transaction.objectStore('messages');
            const index = messageStore.index('conversationId');
            const getMessagesRequest = index.getAll(conversationId);

            getMessagesRequest.onsuccess = () => {
                const messages = getMessagesRequest.result;
                messages.forEach(message => {
                    messageStore.delete(message.id);
                });
            };

            transaction.oncomplete = () => resolve();
            transaction.onerror = () => reject(transaction.error);
        });
    }
} 