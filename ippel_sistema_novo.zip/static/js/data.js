// Funções auxiliares
function formatMoney(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value || 0);
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Dados do Dashboard
const dashboardData = {
    // Dados de Vendas
    vendas: {
        total_mes: 1257830,
        crescimento_mes: 12.5,
        equipamentos_vendidos: 347,
        crescimento_equipamentos: 8.3,
        historico_mensal: [
            { mes: 'Jan', valor: 980000 },
            { mes: 'Fev', valor: 1050000 },
            { mes: 'Mar', valor: 890000 },
            { mes: 'Abr', valor: 1100000 },
            { mes: 'Mai', valor: 950000 },
            { mes: 'Jun', valor: 1200000 },
            { mes: 'Jul', valor: 1150000 },
            { mes: 'Ago', valor: 1300000 },
            { mes: 'Set', valor: 1180000 },
            { mes: 'Out', valor: 1250000 },
            { mes: 'Nov', valor: 1120000 },
            { mes: 'Dez', valor: 1257830 }
        ],
        vendas_recentes: [
            {
                id: 'V2023120',
                cliente: 'Indústria ABC Ltda',
                equipamento: 'Torno CNC Industrial',
                valor: 185000,
                data: '2023-12-15',
                status: 'Concluída'
            },
            {
                id: 'V2023119',
                cliente: 'Metalúrgica XYZ',
                equipamento: 'Fresadora Universal',
                valor: 145000,
                data: '2023-12-14',
                status: 'Em andamento'
            }
        ]
    },

    // Dados de Clientes
    clientes: {
        total_ativos: 83,
        novos_mes: 5,
        por_segmento: [
            { segmento: 'Metalurgia', quantidade: 30 },
            { segmento: 'Automotivo', quantidade: 25 },
            { segmento: 'Construção', quantidade: 15 },
            { segmento: 'Outros', quantidade: 13 }
        ],
        principais: [
            {
                nome: 'Indústria ABC Ltda',
                segmento: 'Metalurgia',
                compras_total: 850000,
                ultima_compra: '2023-12-15'
            },
            {
                nome: 'Metalúrgica XYZ',
                segmento: 'Automotivo',
                compras_total: 620000,
                ultima_compra: '2023-12-14'
            }
        ]
    },

    // Dados de Equipamentos
    equipamentos: {
        total_catalogados: 156,
        em_estoque: 89,
        estoque_baixo: 12,
        sem_estoque: 3,
        mais_vendidos: [
            {
                nome: 'Torno CNC Industrial',
                vendas_mes: 15,
                valor_total: 2775000
            },
            {
                nome: 'Fresadora Universal',
                vendas_mes: 12,
                valor_total: 1740000
            },
            {
                nome: 'Centro de Usinagem',
                vendas_mes: 8,
                valor_total: 2400000
            }
        ],
        categorias: [
            { categoria: 'Tornos', quantidade: 45 },
            { categoria: 'Fresadoras', quantidade: 35 },
            { categoria: 'Centros de Usinagem', quantidade: 25 },
            { categoria: 'Retíficas', quantidade: 30 },
            { categoria: 'Outros', quantidade: 21 }
        ]
    },

    // Dados de Manutenção
    manutencao: {
        chamados_abertos: 15,
        em_andamento: 8,
        concluidos_mes: 45,
        tempo_medio_atendimento: '2.5 dias',
        tecnicos_disponiveis: 12,
        historico: [
            {
                id: 'M2023089',
                cliente: 'Indústria ABC Ltda',
                equipamento: 'Torno CNC Industrial',
                tipo: 'Preventiva',
                status: 'Concluída',
                data: '2023-12-10'
            },
            {
                id: 'M2023090',
                cliente: 'Metalúrgica XYZ',
                equipamento: 'Fresadora Universal',
                tipo: 'Corretiva',
                status: 'Em andamento',
                data: '2023-12-14'
            }
        ]
    }
};

// Função para buscar dados específicos
function getDashboardData(categoria, subcategoria = null) {
    if (subcategoria) {
        return dashboardData[categoria]?.[subcategoria];
    }
    return dashboardData[categoria];
}

// Função para formatar valores monetários
function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor);
}

// Função para formatar datas
function formatarData(data) {
    return new Date(data).toLocaleDateString('pt-BR');
}

// Função para buscar dados para a IA
function buscarDadosParaIA(consulta) {
    const consulta_lower = consulta.toLowerCase();
    let resposta = '';

    // Vendas
    if (consulta_lower.includes('venda') || consulta_lower.includes('vendas')) {
        const vendas = dashboardData.vendas;
        resposta += `Vendas totais no mês: ${formatMoney(vendas.total_mes)}\n`;
        resposta += `Crescimento em relação ao mês anterior: ${vendas.crescimento_mes}%\n`;
        resposta += `Equipamentos vendidos: ${vendas.equipamentos_vendidos} unidades\n`;
    }

    // Clientes
    if (consulta_lower.includes('cliente') || consulta_lower.includes('clientes')) {
        const clientes = dashboardData.clientes;
        resposta += `Total de clientes ativos: ${clientes.total_ativos}\n`;
        resposta += `Novos clientes no mês: ${clientes.novos_mes}\n`;
        resposta += 'Distribuição por segmento:\n';
        clientes.por_segmento.forEach(seg => {
            resposta += `- ${seg.segmento}: ${seg.quantidade} clientes\n`;
        });
    }

    // Equipamentos
    if (consulta_lower.includes('equipamento') || consulta_lower.includes('estoque')) {
        const equip = dashboardData.equipamentos;
        resposta += `Total de equipamentos catalogados: ${equip.total_catalogados}\n`;
        resposta += `Em estoque: ${equip.em_estoque}\n`;
        resposta += `Com estoque baixo: ${equip.estoque_baixo}\n`;
        resposta += `Sem estoque: ${equip.sem_estoque}\n`;
    }

    // Manutenção
    if (consulta_lower.includes('manuten') || consulta_lower.includes('chamado')) {
        const manut = dashboardData.manutencao;
        resposta += `Chamados abertos: ${manut.chamados_abertos}\n`;
        resposta += `Em andamento: ${manut.em_andamento}\n`;
        resposta += `Concluídos no mês: ${manut.concluidos_mes}\n`;
        resposta += `Tempo médio de atendimento: ${manut.tempo_medio_atendimento}\n`;
    }

    return resposta || 'Não encontrei dados específicos para sua consulta. Por favor, seja mais específico ou pergunte sobre vendas, clientes, equipamentos ou manutenção.';
}

// Funções para geração de relatórios
const relatorios = {
    // Relatório de Vendas
    gerarRelatorioVendas: (periodo = 'mes') => {
        const vendas = dashboardData.vendas;
        let relatorio = '📊 *Relatório de Vendas*\n\n';

        if (periodo === 'mes') {
            relatorio += `Total de Vendas no Mês: ${formatMoney(vendas.total_mes)}\n`;
            relatorio += `Crescimento: ${vendas.crescimento_mes}%\n`;
            relatorio += `Equipamentos Vendidos: ${vendas.equipamentos_vendidos} unidades\n\n`;
        }

        relatorio += 'Vendas Recentes:\n';
        vendas.vendas_recentes.forEach(venda => {
            relatorio += `- ${venda.equipamento} para ${venda.cliente}\n`;
            relatorio += `  Valor: ${formatMoney(venda.valor)} | Data: ${formatDate(venda.data)}\n`;
        });

        return relatorio;
    },

    // Relatório de Estoque
    gerarRelatorioEstoque: () => {
        const equip = dashboardData.equipamentos;
        let relatorio = '📦 *Relatório de Estoque*\n\n';

        relatorio += `Total de Equipamentos: ${equip.total_catalogados}\n`;
        relatorio += `Em Estoque: ${equip.em_estoque}\n`;
        relatorio += `Estoque Baixo: ${equip.estoque_baixo}\n`;
        relatorio += `Sem Estoque: ${equip.sem_estoque}\n\n`;

        relatorio += 'Equipamentos Mais Vendidos:\n';
        equip.mais_vendidos.forEach(item => {
            relatorio += `- ${item.nome}\n`;
            relatorio += `  Vendas no Mês: ${item.vendas_mes} | Total: ${formatMoney(item.valor_total)}\n`;
        });

        return relatorio;
    },

    // Relatório de Clientes
    gerarRelatorioClientes: () => {
        const clientes = dashboardData.clientes;
        let relatorio = '👥 *Relatório de Clientes*\n\n';

        relatorio += `Total de Clientes Ativos: ${clientes.total_ativos}\n`;
        relatorio += `Novos Clientes no Mês: ${clientes.novos_mes}\n\n`;

        relatorio += 'Distribuição por Segmento:\n';
        clientes.por_segmento.forEach(seg => {
            relatorio += `- ${seg.segmento}: ${seg.quantidade} clientes\n`;
        });

        relatorio += '\nPrincipais Clientes:\n';
        clientes.principais.forEach(cliente => {
            relatorio += `- ${cliente.nome} (${cliente.segmento})\n`;
            relatorio += `  Total em Compras: ${formatMoney(cliente.compras_total)}\n`;
            relatorio += `  Última Compra: ${formatDate(cliente.ultima_compra)}\n`;
        });

        return relatorio;
    },

    // Relatório de Manutenção
    gerarRelatorioManutencao: () => {
        const manut = dashboardData.manutencao;
        let relatorio = '🔧 *Relatório de Manutenção*\n\n';

        relatorio += `Chamados Abertos: ${manut.chamados_abertos}\n`;
        relatorio += `Em Andamento: ${manut.em_andamento}\n`;
        relatorio += `Concluídos no Mês: ${manut.concluidos_mes}\n`;
        relatorio += `Tempo Médio de Atendimento: ${manut.tempo_medio_atendimento}\n`;
        relatorio += `Técnicos Disponíveis: ${manut.tecnicos_disponiveis}\n\n`;

        relatorio += 'Últimos Chamados:\n';
        manut.historico.forEach(chamado => {
            relatorio += `- ${chamado.id} - ${chamado.cliente}\n`;
            relatorio += `  Equipamento: ${chamado.equipamento}\n`;
            relatorio += `  Tipo: ${chamado.tipo} | Status: ${chamado.status}\n`;
            relatorio += `  Data: ${formatDate(chamado.data)}\n`;
        });

        return relatorio;
    },

    // Relatório Geral
    gerarRelatorioGeral: () => {
        let relatorio = '📈 *Relatório Geral Ippel Equipamentos*\n\n';

        // Vendas
        relatorio += '=== VENDAS ===\n';
        relatorio += `Total Mensal: ${formatMoney(dashboardData.vendas.total_mes)}\n`;
        relatorio += `Crescimento: ${dashboardData.vendas.crescimento_mes}%\n\n`;

        // Clientes
        relatorio += '=== CLIENTES ===\n';
        relatorio += `Ativos: ${dashboardData.clientes.total_ativos}\n`;
        relatorio += `Novos no Mês: ${dashboardData.clientes.novos_mes}\n\n`;

        // Equipamentos
        relatorio += '=== EQUIPAMENTOS ===\n';
        relatorio += `Em Estoque: ${dashboardData.equipamentos.em_estoque}\n`;
        relatorio += `Estoque Baixo: ${dashboardData.equipamentos.estoque_baixo}\n\n`;

        // Manutenção
        relatorio += '=== MANUTENÇÃO ===\n';
        relatorio += `Chamados Abertos: ${dashboardData.manutencao.chamados_abertos}\n`;
        relatorio += `Em Andamento: ${dashboardData.manutencao.em_andamento}\n`;
        relatorio += `Concluídos: ${dashboardData.manutencao.concluidos_mes}\n`;

        return relatorio;
    }
};

// Relatórios adicionais para o painel
const relatoriosAdicionais = {
    // Relatório de Desempenho Mensal
    gerarRelatorioDesempenhoMensal: () => {
        const vendas = dashboardData.vendas;
        let relatorio = '📊 *Relatório de Desempenho Mensal*\n\n';

        relatorio += '=== MÉTRICAS PRINCIPAIS ===\n';
        relatorio += `Faturamento Total: ${formatMoney(vendas.total_mes)}\n`;
        relatorio += `Meta Atingida: ${(vendas.total_mes / 1500000 * 100).toFixed(1)}%\n`;
        relatorio += `Crescimento: ${vendas.crescimento_mes}%\n\n`;

        relatorio += '=== VENDAS POR MÊS ===\n';
        vendas.historico_mensal.forEach(mes => {
            const percentual = ((mes.valor / 1500000) * 100).toFixed(1);
            relatorio += `${mes.mes}: ${formatMoney(mes.valor)} (${percentual}% da meta)\n`;
        });

        return relatorio;
    },

    // Relatório de Segmentação de Clientes
    gerarRelatorioSegmentacaoClientes: () => {
        const clientes = dashboardData.clientes;
        let relatorio = '👥 *Relatório de Segmentação de Clientes*\n\n';

        relatorio += '=== DISTRIBUIÇÃO POR SEGMENTO ===\n';
        clientes.por_segmento.forEach(seg => {
            const percentual = ((seg.quantidade / clientes.total_ativos) * 100).toFixed(1);
            relatorio += `${seg.segmento}: ${seg.quantidade} clientes (${percentual}%)\n`;
        });

        relatorio += '\n=== CLIENTES VIP ===\n';
        clientes.principais.forEach(cliente => {
            relatorio += `- ${cliente.nome}\n`;
            relatorio += `  Segmento: ${cliente.segmento}\n`;
            relatorio += `  Valor Total: ${formatMoney(cliente.compras_total)}\n`;
            relatorio += `  Última Interação: ${formatDate(cliente.ultima_compra)}\n`;
        });

        return relatorio;
    },

    // Relatório de Eficiência Operacional
    gerarRelatorioEficienciaOperacional: () => {
        const manut = dashboardData.manutencao;
        let relatorio = '⚡ *Relatório de Eficiência Operacional*\n\n';

        relatorio += '=== INDICADORES DE EFICIÊNCIA ===\n';
        const taxaResolucao = ((manut.concluidos_mes / (manut.chamados_abertos + manut.concluidos_mes)) * 100).toFixed(1);
        const chamadosPorTecnico = (manut.chamados_abertos / manut.tecnicos_disponiveis).toFixed(1);

        relatorio += `Taxa de Resolução: ${taxaResolucao}%\n`;
        relatorio += `Tempo Médio de Atendimento: ${manut.tempo_medio_atendimento}\n`;
        relatorio += `Chamados por Técnico: ${chamadosPorTecnico}\n`;
        relatorio += `Eficiência da Equipe: ${((manut.concluidos_mes / manut.tecnicos_disponiveis) / 30).toFixed(1)} chamados/dia/técnico\n\n`;

        relatorio += '=== STATUS DOS CHAMADOS ===\n';
        relatorio += `Em Aberto: ${manut.chamados_abertos}\n`;
        relatorio += `Em Andamento: ${manut.em_andamento}\n`;
        relatorio += `Concluídos: ${manut.concluidos_mes}\n`;

        return relatorio;
    },

    // Relatório de Gestão de Estoque
    gerarRelatorioGestaoEstoque: () => {
        const equip = dashboardData.equipamentos;
        let relatorio = '📦 *Relatório de Gestão de Estoque*\n\n';

        relatorio += '=== STATUS DO ESTOQUE ===\n';
        const utilizacao = ((equip.em_estoque / equip.total_catalogados) * 100).toFixed(1);
        relatorio += `Taxa de Utilização: ${utilizacao}%\n`;
        relatorio += `Itens em Estoque: ${equip.em_estoque}\n`;
        relatorio += `Itens em Estoque Baixo: ${equip.estoque_baixo}\n`;
        relatorio += `Itens sem Estoque: ${equip.sem_estoque}\n\n`;

        relatorio += '=== DISTRIBUIÇÃO POR CATEGORIA ===\n';
        equip.categorias.forEach(cat => {
            const percentual = ((cat.quantidade / equip.total_catalogados) * 100).toFixed(1);
            relatorio += `${cat.categoria}: ${cat.quantidade} itens (${percentual}%)\n`;
        });

        relatorio += '\n=== PRODUTOS MAIS VENDIDOS ===\n';
        equip.mais_vendidos.forEach(item => {
            const ticketMedio = (item.valor_total / item.vendas_mes).toFixed(2);
            relatorio += `- ${item.nome}\n`;
            relatorio += `  Vendas: ${item.vendas_mes} unidades\n`;
            relatorio += `  Ticket Médio: ${formatMoney(ticketMedio)}\n`;
        });

        return relatorio;
    },

    // Relatório de KPIs
    gerarRelatorioKPIs: () => {
        let relatorio = '📈 *Relatório de KPIs*\n\n';

        // KPIs de Vendas
        const vendas = dashboardData.vendas;
        relatorio += '=== KPIs DE VENDAS ===\n';
        relatorio += `Receita Mensal: ${formatMoney(vendas.total_mes)}\n`;
        relatorio += `Crescimento MoM: ${vendas.crescimento_mes}%\n`;
        relatorio += `Ticket Médio: ${formatMoney(vendas.total_mes / vendas.equipamentos_vendidos)}\n\n`;

        // KPIs de Clientes
        const clientes = dashboardData.clientes;
        relatorio += '=== KPIs DE CLIENTES ===\n';
        relatorio += `Taxa de Aquisição: ${((clientes.novos_mes / clientes.total_ativos) * 100).toFixed(1)}%\n`;
        relatorio += `Clientes Ativos: ${clientes.total_ativos}\n`;
        relatorio += `Novos Clientes: ${clientes.novos_mes}\n\n`;

        // KPIs de Operação
        const manut = dashboardData.manutencao;
        relatorio += '=== KPIs DE OPERAÇÃO ===\n';
        relatorio += `Taxa de Resolução: ${((manut.concluidos_mes / (manut.chamados_abertos + manut.concluidos_mes)) * 100).toFixed(1)}%\n`;
        relatorio += `Tempo Médio de Atendimento: ${manut.tempo_medio_atendimento}\n`;
        relatorio += `Eficiência Técnica: ${(manut.concluidos_mes / manut.tecnicos_disponiveis).toFixed(1)} chamados/técnico\n`;

        return relatorio;
    }
};

// Atualiza o objeto relatorios com os novos relatórios
Object.assign(relatorios, relatoriosAdicionais);

// Função para processar solicitações de relatórios via chat
function processarSolicitacaoRelatorio(mensagem) {
    const msg = mensagem.toLowerCase();
    
    // Relatórios existentes
    if (msg.includes('relatório geral') || msg.includes('relatorio geral')) {
        return relatorios.gerarRelatorioGeral();
    }
    
    if (msg.includes('relatório de vendas') || msg.includes('relatorio de vendas') || 
        (msg.includes('relatório') && msg.includes('vendas'))) {
        return relatorios.gerarRelatorioVendas();
    }
    
    if (msg.includes('relatório de estoque') || msg.includes('relatorio de estoque') || 
        (msg.includes('relatório') && msg.includes('estoque'))) {
        return relatorios.gerarRelatorioEstoque();
    }
    
    if (msg.includes('relatório de clientes') || msg.includes('relatorio de clientes') || 
        (msg.includes('relatório') && msg.includes('clientes'))) {
        return relatorios.gerarRelatorioClientes();
    }
    
    if (msg.includes('relatório de manutenção') || msg.includes('relatorio de manutencao') || 
        (msg.includes('relatório') && msg.includes('manuten'))) {
        return relatorios.gerarRelatorioManutencao();
    }

    // Novos relatórios
    if (msg.includes('desempenho mensal') || (msg.includes('relatório') && msg.includes('desempenho'))) {
        return relatorios.gerarRelatorioDesempenhoMensal();
    }

    if (msg.includes('segmentação') || msg.includes('segmentacao') || 
        (msg.includes('relatório') && msg.includes('segment'))) {
        return relatorios.gerarRelatorioSegmentacaoClientes();
    }

    if (msg.includes('eficiência') || msg.includes('eficiencia') || 
        (msg.includes('relatório') && msg.includes('operacional'))) {
        return relatorios.gerarRelatorioEficienciaOperacional();
    }

    if (msg.includes('gestão de estoque') || msg.includes('gestao de estoque') || 
        (msg.includes('relatório') && msg.includes('gestão'))) {
        return relatorios.gerarRelatorioGestaoEstoque();
    }

    if (msg.includes('kpi') || msg.includes('indicadores') || 
        (msg.includes('relatório') && msg.includes('kpi'))) {
        return relatorios.gerarRelatorioKPIs();
    }
    
    return null;
}

// Exporta as funções para uso global
window.getDashboardData = getDashboardData;
window.formatarMoeda = formatarMoeda;
window.formatarData = formatarData;
window.buscarDadosParaIA = buscarDadosParaIA;
window.relatorios = relatorios;
window.processarSolicitacaoRelatorio = processarSolicitacaoRelatorio;

// Funções para carregar dados do dashboard
async function loadDashboardData() {
    try {
        const response = await fetch('/api/dados/dashboard', {
            timeout: 10000
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        console.log('📊 Dashboard: dados carregados');
        return data;
    } catch (error) {
        console.warn('⚠️ Dashboard: usando dados padrão -', error.message);
        // Retornar dados padrão válidos
        return {
            vendas_mes: { valor_total: 0, total_vendas: 0 },
            clientes_regiao: [],
            produtos_mais_vendidos: [],
            manutencoes_status: [],
            produtos_estoque_baixo: 0
        };
    }
}

// Função para carregar dados das tabelas
async function loadTableData() {
    try {
        const [produtosResponse, vendasResponse] = await Promise.all([
            fetch('/api/dados/produtos'),
            fetch('/api/dados/vendas')
        ]);
        
        if (!produtosResponse.ok || !vendasResponse.ok) {
            throw new Error('Falha na comunicação com APIs');
        }
        
        const produtos = await produtosResponse.json();
        const vendas = await vendasResponse.json();
        
        console.log('📋 Tabelas: dados carregados');
        return { produtos, vendas };
    } catch (error) {
        console.warn('⚠️ Tabelas: usando dados vazios -', error.message);
        return { 
            produtos: [], 
            vendas: [] 
        };
    }
}

// Função para atualizar dados
async function refreshData() {
    console.log('🔄 Atualizando dados...');
    
    try {
        // Verificar se estamos na página correta
        const dashboardPage = document.getElementById('dashboard');
        const dadosPage = document.getElementById('dados');
        
        if (!dashboardPage && !dadosPage) {
            console.log('📄 Páginas de dados não encontradas, pulando atualização');
            return;
        }
        
        // Carregar dados com Promise.allSettled para não falhar se uma API falhar
        const results = await Promise.allSettled([
            loadDashboardData(),
            loadTableData()
        ]);
        
        // Verificar resultados
        const [dashboardResult, tableResult] = results;
        let successCount = 0;
        
        if (dashboardResult.status === 'fulfilled') {
            updateDashboard(dashboardResult.value);
            successCount++;
            console.log('✅ Dashboard atualizado');
        } else {
            console.warn('⚠️ Falha ao carregar dados do dashboard:', dashboardResult.reason);
        }
        
        if (tableResult.status === 'fulfilled') {
            updateTables(tableResult.value);
            successCount++;
            console.log('✅ Tabelas atualizadas');
        } else {
            console.warn('⚠️ Falha ao carregar dados das tabelas:', tableResult.reason);
        }
        
        // Só mostrar erro se NENHUMA das APIs funcionou (caso muito raro)
        if (successCount === 0) {
            console.error('❌ Nenhuma fonte de dados disponível');
            // Só mostrar toast após várias tentativas falharem
            if (!window.consecutiveFailures) window.consecutiveFailures = 0;
            window.consecutiveFailures++;
            
            if (window.consecutiveFailures >= 3) {
                showErrorToast('Problema de conectividade detectado.');
                window.consecutiveFailures = 0; // Reset contador
            }
        } else {
            console.log(`✅ Atualização OK (${successCount}/2 fontes)`);
            window.consecutiveFailures = 0; // Reset contador em caso de sucesso
        }
        
    } catch (error) {
        console.error('❌ Erro crítico:', error);
        // Só mostrar para erros realmente inesperados
        if (!error.message.includes('fetch') && !error.message.includes('network')) {
            showErrorToast('Erro técnico inesperado.');
        }
    }
}

// Função para mostrar toast de erro - apenas para erros realmente críticos
function showErrorToast(message) {
    // Só mostrar se não há toast ativo (evitar spam)
    const existingToast = document.getElementById('errorToast');
    if (existingToast) {
        return; // Não criar toast duplicado
    }
    
    console.warn('🟡 Toast:', message);
    
    const toast = document.createElement('div');
    toast.id = 'errorToast';
    toast.style.cssText = `
        position: fixed; bottom: 20px; right: 20px; background: #2563eb; color: white;
        padding: 0.75rem 1rem; border-radius: 8px; z-index: 9999; max-width: 280px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2); font-family: inherit; font-size: 0.875rem;
        transform: translateY(100%); transition: all 0.3s ease-out; cursor: pointer;
    `;
    toast.innerHTML = `
        <div style="display: flex; align-items: center; gap: 0.5rem;">
            <span>ℹ️</span>
            <span>${message}</span>
        </div>
    `;
    
    // Clique para remover
    toast.onclick = () => {
        toast.style.transform = 'translateY(100%)';
        setTimeout(() => toast.remove(), 300);
    };
    
    document.body.appendChild(toast);
    
    // Animar entrada
    setTimeout(() => {
        toast.style.transform = 'translateY(0)';
    }, 100);
    
    // Remover após 4 segundos
    setTimeout(() => {
        if (toast.parentNode) {
            toast.style.transform = 'translateY(100%)';
            setTimeout(() => toast.remove(), 300);
        }
    }, 4000);
}

// Função para atualizar o dashboard
function updateDashboard(data) {
    try {
        // Procurar os cards no dashboard pela estrutura
        const cards = document.querySelectorAll('#dashboard .dashboard-grid .card');
        
        // Atualizar Total de Vendas (primeiro card)
        if (cards[0] && data.vendas_mes) {
            const metricValue = cards[0].querySelector('.metric-value');
            if (metricValue) {
                metricValue.textContent = formatMoney(data.vendas_mes.valor_total || 0);
            }
        }
        
        // Atualizar Vendas do Mês (segundo card)
        if (cards[1] && data.vendas_mes) {
            const metricValue = cards[1].querySelector('.metric-value');
            if (metricValue) {
                metricValue.textContent = data.vendas_mes.total_vendas || 0;
            }
        }
        
        // Atualizar Total de Clientes (terceiro card)
        if (cards[2] && data.clientes_regiao) {
            const metricValue = cards[2].querySelector('.metric-value');
            if (metricValue) {
                const totalClientes = data.clientes_regiao.reduce((sum, item) => sum + item.quantidade, 0);
                metricValue.textContent = totalClientes;
            }
        }
        
        // Atualizar Estoque Baixo (quarto card)
        if (cards[3] && data.produtos_mais_vendidos) {
            const metricValue = cards[3].querySelector('.metric-value');
            if (metricValue) {
                // Por enquanto, usar um valor placeholder já que não temos dados de estoque baixo
                metricValue.textContent = '5';
            }
        }
        
        console.log('Dashboard atualizado com sucesso');
    } catch (error) {
        console.error('Erro ao atualizar dashboard:', error);
    }
}

// Função para atualizar as tabelas
function updateTables(data) {
    try {
        // Atualizar tabela de produtos
        const produtosTable = document.querySelector('#tabela-produtos tbody');
        if (produtosTable && data.produtos) {
            produtosTable.innerHTML = data.produtos.map(produto => `
                <tr>
                    <td>${produto.categoria}</td>
                    <td>${produto.modelo}</td>
                    <td>${formatMoney(produto.preco)}</td>
                    <td>${produto.estoque}</td>
                    <td>
                        <button class="btn-danger btn-sm" onclick="deleteProduto(${produto.id}, '${produto.modelo}')" title="Excluir produto">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }
        
        // Atualizar tabela de vendas recentes na página de dados
        const vendasTable = document.querySelector('#tabela-vendas tbody');
        if (vendasTable && data.vendas) {
            vendasTable.innerHTML = data.vendas.slice(0, 10).map(venda => `
                <tr>
                    <td>${formatDate(venda.data_venda)}</td>
                    <td>${venda.cliente_nome}</td>
                    <td>${venda.produto_modelo}</td>
                    <td>${formatMoney(venda.valor_total)}</td>
                    <td>
                        <button class="btn-danger btn-sm" onclick="deleteVenda(${venda.id}, '${venda.produto_modelo}', '${venda.cliente_nome}')" title="Excluir venda">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }
        
        // Atualizar tabela de vendas recentes no dashboard principal
        const recentSalesTable = document.getElementById('recentSalesTable');
        if (recentSalesTable && data.vendas) {
            recentSalesTable.innerHTML = data.vendas.slice(0, 5).map((venda, index) => `
                <tr>
                    <td>V2024${String(100 + index).padStart(3, '0')}</td>
                    <td>${venda.cliente_nome}</td>
                    <td>${venda.produto_modelo}</td>
                    <td>${formatMoney(venda.valor_total)}</td>
                    <td>${formatDate(venda.data_venda)}</td>
                    <td><span class="status-badge status-active">Concluída</span></td>
                </tr>
            `).join('');
        }
        
        console.log('Tabelas atualizadas com sucesso');
    } catch (error) {
        console.error('Erro ao atualizar tabelas:', error);
    }
}

// Função para carregar selects dos formulários
async function loadFormSelects() {
    try {
        // Carregar produtos
        const produtosResponse = await fetch('/api/dados/produtos');
        const produtos = await produtosResponse.json();
        
        const produtoSelect = document.getElementById('venda_produto_id');
        if (produtoSelect) {
            produtoSelect.innerHTML = `
                <option value="">🛍️ Selecione um produto</option>
                ${produtos.map(p => `<option value="${p.id}">${p.categoria} - ${p.modelo}</option>`).join('')}
            `;
        }

        // Carregar clientes
        const clientesResponse = await fetch('/api/dados/clientes');
        const clientes = await clientesResponse.json();
        
        const clienteSelect = document.getElementById('venda_cliente_id');
        if (clienteSelect) {
            clienteSelect.innerHTML = `
                <option value="">👤 Selecione um cliente</option>
                ${clientes.map(c => `<option value="${c.id}">${c.nome}</option>`).join('')}
            `;
        }
        
        return { produtos, clientes };
    } catch (error) {
        console.error('Erro ao carregar dados para selects:', error);
        showErrorToast('Erro ao carregar dados. Por favor, recarregue a página.');
        return { produtos: [], clientes: [] };
    }
}

// Inicializar dados quando a página carregar
document.addEventListener('DOMContentLoaded', async () => {
    console.log('🚀 Inicializando dashboard...');
    
    // Aguardar elementos estarem prontos
    setTimeout(async () => {
        // Carregar dados iniciais silenciosamente
        const currentPage = document.querySelector('.page.active');
        if (currentPage && (currentPage.id === 'dashboard' || currentPage.id === 'dados')) {
            console.log('📄 Carregando dados da página inicial...');
            await refreshData();
        }
        
        // Configurar botão de atualizar
        const refreshButton = document.querySelector('.btn-refresh');
        if (refreshButton) {
            refreshButton.addEventListener('click', () => {
                console.log('🔄 Atualização manual solicitada');
                refreshData();
            });
        }
        
        // Atualização automática mais espaçada (2 minutos)
        setInterval(async () => {
            const currentPage = document.querySelector('.page.active');
            if (currentPage && (currentPage.id === 'dashboard' || currentPage.id === 'dados')) {
                console.log('⏰ Atualização automática...');
                await refreshData();
            }
        }, 120000); // 2 minutos
        
        console.log('✅ Dashboard inicializado');
    }, 800);
});

// Event Listeners para os formulários
document.addEventListener('DOMContentLoaded', () => {
    // Carregar dados iniciais
    loadFormSelects();
    
    // Carregar dados do dashboard ao iniciar
    if (document.getElementById('dashboard').classList.contains('active')) {
        refreshData();
    }
    
    // Definir data padrão como hoje no campo de data de venda
    const dataVendaInput = document.getElementById('dash_data_venda');
    if (dataVendaInput) {
        const hoje = new Date().toISOString().split('T')[0];
        dataVendaInput.value = hoje;
    }

    // Formulário de Vendas
    const vendaForm = document.getElementById('dashboardVendaForm');
    if (vendaForm) {
        vendaForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const produto_id = parseInt(document.getElementById('dash_produto_id').value);
            const quantidade = parseInt(document.getElementById('dash_quantidade').value);
            
            // Buscar o preço do produto para calcular o valor total
            try {
                const produtosResponse = await fetch('/api/produtos');
                const produtos = await produtosResponse.json();
                const produto = produtos.find(p => p.id === produto_id);
                
                if (!produto) {
                    alert('Produto não encontrado');
                    return;
                }
                
                const valor_total = produto.preco * quantidade;
                
                const formData = {
                    produto_id: produto_id,
                    cliente_id: parseInt(document.getElementById('dash_cliente_id').value),
                    quantidade: quantidade,
                    valor_total: valor_total,
                    data_venda: document.getElementById('dash_data_venda').value
                };

                const response = await fetch('/api/vendas', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    const result = await response.json();
                    console.log('Venda registrada:', result);
                    alert('Venda registrada com sucesso!');
                    vendaForm.reset();
                    
                    // Aguardar um pouco antes de recarregar
                    setTimeout(async () => {
                        await refreshData(); // Atualiza os dados do dashboard
                    }, 500);
                } else {
                    const error = await response.json();
                    throw new Error(error.error || 'Erro ao registrar venda');
                }
            } catch (error) {
                alert(`Erro: ${error.message}`);
            }
        });
    }

    // Formulário de Produtos
    const produtoForm = document.getElementById('dashboardProdutoForm');
    if (produtoForm) {
        produtoForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = {
                categoria: document.getElementById('dash_categoria').value,
                modelo: document.getElementById('dash_modelo').value,
                preco: parseFloat(document.getElementById('dash_preco').value),
                estoque: parseInt(document.getElementById('dash_estoque').value)
            };

            try {
                const response = await fetch('/api/produtos', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    const result = await response.json();
                    console.log('Produto adicionado:', result);
                    alert('Produto adicionado com sucesso!');
                    produtoForm.reset();
                    
                    // Aguardar um pouco antes de recarregar para garantir que o banco foi atualizado
                    setTimeout(async () => {
                        await loadFormSelects(); // Recarrega os selects
                        await refreshData(); // Atualiza os dados do dashboard
                    }, 500);
                } else {
                    const error = await response.json();
                    throw new Error(error.error || 'Erro ao adicionar produto');
                }
            } catch (error) {
                alert(`Erro: ${error.message}`);
            }
        });
    }

    // Formulário de Clientes
    const clienteForm = document.getElementById('dashboardClienteForm');
    if (clienteForm) {
        clienteForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = {
                nome: document.getElementById('dash_nome').value,
                segmento: document.getElementById('dash_segmento').value,
                regiao: document.getElementById('dash_regiao').value,
                email: document.getElementById('dash_email').value,
                telefone: document.getElementById('dash_telefone').value
            };

            try {
                const response = await fetch('/api/clientes', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    const result = await response.json();
                    console.log('Cliente adicionado:', result);
                    alert('Cliente adicionado com sucesso!');
                    clienteForm.reset();
                    
                    // Aguardar um pouco antes de recarregar
                    setTimeout(async () => {
                        await loadFormSelects(); // Recarrega os selects
                        await refreshData(); // Atualiza os dados do dashboard
                    }, 500);
                } else {
                    const error = await response.json();
                    throw new Error(error.error || 'Erro ao adicionar cliente');
                }
            } catch (error) {
                alert(`Erro: ${error.message}`);
            }
        });
    }
}); 

// Função para deletar produto
async function deleteProduto(produtoId, produtoNome) {
    if (!confirm(`Tem certeza que deseja excluir o produto "${produtoNome}"?\n\nATENÇÃO: Esta ação não pode ser desfeita!`)) {
        return;
    }
    
    try {
        console.log(`🗑️ Deletando produto ${produtoId}...`);
        
        const response = await fetch(`/api/produtos/${produtoId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('✅ Produto deletado com sucesso');
            alert(`✅ Produto "${produtoNome}" excluído com sucesso!`);
            
            // Recarregar os dados
            await refreshData();
            await loadFormSelects(); // Atualizar selects também
            
            // Atualizar dashboard principal se estiver ativo
            if (document.getElementById('dashboard').classList.contains('active')) {
                await loadDashboardData();
            }
        } else {
            console.error('❌ Erro ao deletar produto:', result.error);
            alert(`❌ Erro ao excluir produto:\n${result.error}`);
        }
    } catch (error) {
        console.error('❌ Erro na requisição:', error);
        alert(`❌ Erro ao excluir produto:\n${error.message}`);
    }
}

// Função para deletar venda
async function deleteVenda(vendaId, produtoNome, clienteNome) {
    if (!confirm(`Tem certeza que deseja excluir esta venda?\n\nProduto: ${produtoNome}\nCliente: ${clienteNome}\n\nATENÇÃO: O estoque será restaurado e esta ação não pode ser desfeita!`)) {
        return;
    }
    
    try {
        console.log(`🗑️ Deletando venda ${vendaId}...`);
        
        const response = await fetch(`/api/vendas/${vendaId}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        
        if (response.ok) {
            console.log('✅ Venda deletada com sucesso');
            alert(`✅ Venda excluída com sucesso!\n\n${result.detalhes || result.message}`);
            
            // Recarregar os dados
            await refreshData();
            
            // Atualizar dashboard principal se estiver ativo
            if (document.getElementById('dashboard').classList.contains('active')) {
                await loadDashboardData();
            }
        } else {
            console.error('❌ Erro ao deletar venda:', result.error);
            alert(`❌ Erro ao excluir venda:\n${result.error}`);
        }
    } catch (error) {
        console.error('❌ Erro na requisição:', error);
        alert(`❌ Erro ao excluir venda:\n${error.message}`);
    }
}