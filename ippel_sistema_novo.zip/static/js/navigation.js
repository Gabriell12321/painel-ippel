// Função para mostrar uma página e esconder as outras
function showPage(pageId) {
    console.log('Mostrando página:', pageId);
    
    // Esconder todas as páginas
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
        console.log('Removendo active de:', page.id);
    });
    
    // Mostrar a página selecionada
    const selectedPage = document.getElementById(pageId);
    if (selectedPage) {
        selectedPage.classList.add('active');
        console.log('Adicionando active em:', pageId);
        
        // Atualizar classe ativa no menu
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-page') === pageId) {
                link.classList.add('active');
                console.log('Link ativo:', link.getAttribute('data-page'));
            }
        });
        
        // Atualizar título da página
        const pageTitle = selectedPage.querySelector('h2')?.textContent || 'Dashboard';
        document.title = `Ippel Equipamentos - ${pageTitle}`;
        
        // Executar ações específicas da página
        switch(pageId) {
            case 'dashboard':
                if (typeof updateDashboard === 'function') {
                    updateDashboard();
                }
                break;
            case 'dados':
                if (typeof atualizarTabelas === 'function') {
                    atualizarTabelas();
                }
                break;
            case 'ia':
                // Limpar e focar o campo de chat se existir
                const chatInput = document.getElementById('chat_message_input');
                if (chatInput) {
                    chatInput.focus();
                }
                break;
            case 'relatorios':
                if (typeof ReportsManager !== 'undefined' && typeof ReportsManager.updateAllReports === 'function') {
                    ReportsManager.updateAllReports();
                } else if (typeof carregarRelatorios === 'function') {
                    carregarRelatorios();
                }
                break;
        }
    } else {
        console.error('Página não encontrada:', pageId);
    }
}

// Função para filtrar dados na página de dados
function filterData() {
    const dataType = document.getElementById('dataType').value;
    const dateRange = document.getElementById('dateRange').value;
    console.log('Filtrando dados:', { dataType, dateRange });
}

// Função para exportar dados
function exportData() {
    const dataType = document.getElementById('dataType').value;
    const dateRange = document.getElementById('dateRange').value;
    console.log('Exportando dados:', { dataType, dateRange });
}

// Função para gerar relatórios
function generateReport() {
    if (typeof ReportsManager !== 'undefined' && typeof ReportsManager.updateAllReports === 'function') {
        ReportsManager.updateAllReports();
    } else {
        const reportType = document.getElementById('reportType')?.value;
        const reportRange = document.getElementById('reportRange')?.value;
        console.log('Gerando relatório:', { reportType, reportRange });
    }
}

// Função para exportar relatório
function exportReport() {
    const reportType = document.getElementById('reportType')?.value;
    const reportRange = document.getElementById('reportRange')?.value;
    console.log('Exportando relatório:', { reportType, reportRange });
    
    // Exportar para PDF
    if (window.jsPDF) {
        const doc = new jsPDF();
        
        // Adicionar título
        doc.setFontSize(16);
        doc.text('Relatório Ippel Equipamentos', 20, 20);
        
        // Adicionar data
        doc.setFontSize(12);
        doc.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, 20, 30);
        
        // Adicionar tipo de relatório
        doc.text(`Tipo: ${reportType}`, 20, 40);
        doc.text(`Período: ${reportRange}`, 20, 50);
        
        // Capturar gráficos
        const charts = document.querySelectorAll('canvas');
        let yPos = 60;
        
        charts.forEach((chart, index) => {
            if (yPos > 250) {
                doc.addPage();
                yPos = 20;
            }
            
            const imgData = chart.toDataURL('image/png');
            doc.addImage(imgData, 'PNG', 20, yPos, 170, 80);
            yPos += 90;
        });
        
        // Salvar PDF
        doc.save('relatorio-ippel.pdf');
    }
}

// Configurar navegação quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM carregado, configurando navegação');
    
    // Adicionar event listeners para links de navegação
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            console.log('Link clicado:', pageId);
            if (pageId) {
                showPage(pageId);
                // Atualizar URL com hash
                window.location.hash = pageId;
            }
        });
    });
    
    // Mostrar página inicial ou página do hash
    const hash = window.location.hash.slice(1);
    showPage(hash || 'dashboard');
    
    // Configurar navegação por hash na URL
    window.addEventListener('hashchange', function() {
        const pageId = window.location.hash.slice(1) || 'dashboard';
        showPage(pageId);
    });
}); 