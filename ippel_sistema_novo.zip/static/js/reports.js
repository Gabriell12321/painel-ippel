// Sistema de Relatórios Avançados - Ippel Dashboard
// Autor: Sistema IA - Gabriel Garcia

// Namespace para funções de relatórios
window.Reports = window.Reports || {};

let currentChart = null;
let currentReportData = null;
let currentPage = 1;
const itemsPerPage = 10;

// Configuração do Chart.js
Chart.defaults.font.family = 'Inter, system-ui, sans-serif';
Chart.defaults.color = '#6b7280';

// Cores do tema Ippel
const colors = {
    primary: '#dc2626',
    success: '#16a34a',
    info: '#2563eb',
    warning: '#ca8a04',
    secondary: '#64748b'
};

// Função principal para gerar relatórios
async function generateAdvancedReport() {
    console.log('📊 Iniciando geração de relatório avançado...');
    
    const reportType = document.getElementById('dash_report_type').value;
    
    if (!reportType) {
        alert('Por favor, selecione um tipo de relatório');
        return;
    }
    
    showLoading();
    
    try {
        console.log(`🔍 Fazendo requisição para: /api/relatorios/${reportType}`);
        const response = await fetch(`/api/relatorios/${reportType}`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        
        currentReportData = data;
        console.log('✅ Dados do relatório carregados:', data);
        console.log('🔍 Verificando estrutura dos dados:', {
            tipo: data.tipo,
            temDados: data.dados ? true : false,
            quantidadeDados: data.dados ? data.dados.length : 0
        });
        
        // Verificar se há dados
        if (!data.dados || data.dados.length === 0) {
            console.warn('⚠️ Nenhum dado encontrado para o relatório');
            hideLoading();
            
            // Atualizar interface com mensagem de dados vazios
            updateReportTitle(reportType);
            showEmptyDataMessage(reportType);
            return;
        }
        
        // Atualizar interface
        updateReportTitle(reportType);
        updateReportMetrics(data);
        updateReportChart(data, reportType);
        updateTable(data, reportType);
        generateInsights(data, reportType);
        
        hideLoading();
        
        console.log('✅ Relatório gerado com sucesso!');
        
    } catch (error) {
        console.error('❌ Erro ao gerar relatório:', error);
        hideLoading();
        alert(`Erro ao gerar relatório: ${error.message}`);
    }
}

// Adicionar ao namespace
window.Reports.generateAdvancedReport = generateAdvancedReport;

// Atualizar título do relatório
function updateReportTitle(reportType) {
    const titles = {
        'vendas_mensal': '📊 Vendas Mensais',
        'produtos_performance': '🎯 Performance de Produtos',
        'clientes_ranking': '👑 Ranking de Clientes',
        'categoria_analise': '📦 Análise por Categoria',
        'vendas_detalhado': '📋 Vendas Detalhadas'
    };
    
    document.getElementById('reportTitle').textContent = titles[reportType] || '📊 Relatório';
}

// Atualizar métricas resumo dos relatórios
function updateReportMetrics(data) {
    // Verificação de segurança para evitar erros
    if (!data || typeof data !== 'object') {
        console.warn('⚠️ updateReportMetrics: dados inválidos recebidos:', data);
        return;
    }
    
    const dados = data.dados || [];
    
    let receita = 0;
    let produtos = 0;
    let clientes = new Set();
    
    // Calcular métricas baseadas no tipo de relatório
    if (data.tipo === 'vendas_mensal') {
        receita = dados.reduce((sum, item) => sum + (item.total_vendas || 0), 0);
        produtos = dados.reduce((sum, item) => sum + (item.num_vendas || 0), 0);
    } else if (data.tipo === 'produtos_performance') {
        receita = dados.reduce((sum, item) => sum + (item.receita_total || 0), 0);
        produtos = dados.reduce((sum, item) => sum + (item.total_vendido || 0), 0);
    } else if (data.tipo === 'clientes_ranking') {
        receita = dados.reduce((sum, item) => sum + (item.valor_total_compras || 0), 0);
        clientes = new Set(dados.map(item => item.nome));
    }
    
    // Verificar se os elementos existem antes de atualizar
    const metricReceita = document.getElementById('metricReceita');
    const metricProdutos = document.getElementById('metricProdutos');
    const metricClientes = document.getElementById('metricClientes');
    const metricCrescimento = document.getElementById('metricCrescimento');
    
    if (metricReceita) metricReceita.textContent = formatMoney(receita);
    if (metricProdutos) metricProdutos.textContent = produtos.toLocaleString();
    if (metricClientes) metricClientes.textContent = clientes.size || dados.length;
    
    // Calcular crescimento (simulado)
    const crescimento = Math.floor(Math.random() * 20) + 5;
    if (metricCrescimento) metricCrescimento.textContent = `+${crescimento}%`;
}

// Atualizar gráfico de relatórios
function updateReportChart(data, reportType) {
    // Verificação de segurança para evitar erros
    if (!data || typeof data !== 'object') {
        console.warn('⚠️ updateReportChart: dados inválidos recebidos:', data);
        return;
    }
    
    const chartElement = document.getElementById('reportChart');
    if (!chartElement) {
        console.warn('⚠️ updateReportChart: elemento reportChart não encontrado');
        return;
    }
    
    const ctx = chartElement.getContext('2d');
    
    // Destruir gráfico anterior se existir
    if (currentChart) {
        currentChart.destroy();
    }
    
    const chartData = prepareChartData(data, reportType);
    const chartTypeBtn = document.querySelector('.chart-btn.active');
    const chartType = chartTypeBtn ? chartTypeBtn.dataset.chart : 'bar';
    
    currentChart = new Chart(ctx, {
        type: chartType,
        data: chartData,
        options: getChartOptions(chartType, reportType)
    });
}

// Preparar dados para gráfico
function prepareChartData(data, reportType) {
    // Verificação de segurança para evitar erros
    if (!data || typeof data !== 'object') {
        console.warn('⚠️ prepareChartData: dados inválidos recebidos:', data);
        return { labels: [], datasets: [] };
    }
    
    const dados = data.dados || [];
    
    if (reportType === 'vendas_mensal') {
        return {
            labels: dados.map(item => formatMonth(item.mes)),
            datasets: [{
                label: 'Vendas (R$)',
                data: dados.map(item => item.total_vendas || 0),
                backgroundColor: colors.primary + '20',
                borderColor: colors.primary,
                borderWidth: 2,
                fill: true
            }]
        };
    }
    
    if (reportType === 'produtos_performance') {
        return {
            labels: dados.slice(0, 10).map(item => item.modelo),
            datasets: [{
                label: 'Receita (R$)',
                data: dados.slice(0, 10).map(item => item.receita_total || 0),
                backgroundColor: [
                    colors.primary, colors.success, colors.info, colors.warning,
                    colors.secondary, '#8b5cf6', '#f59e0b', '#10b981', '#3b82f6', '#ef4444'
                ]
            }]
        };
    }
    
    if (reportType === 'clientes_ranking') {
        return {
            labels: dados.slice(0, 10).map(item => item.nome),
            datasets: [{
                label: 'Total Compras (R$)',
                data: dados.slice(0, 10).map(item => item.valor_total_compras || 0),
                backgroundColor: colors.success + '80',
                borderColor: colors.success,
                borderWidth: 2
            }]
        };
    }
    
    if (reportType === 'categoria_analise') {
        return {
            labels: dados.map(item => item.categoria),
            datasets: [{
                label: 'Receita por Categoria (R$)',
                data: dados.map(item => item.receita_categoria || 0),
                backgroundColor: [colors.primary, colors.success, colors.info, colors.warning, colors.secondary]
            }]
        };
    }
    
    return { labels: [], datasets: [] };
}

// Opções do gráfico
function getChartOptions(chartType, reportType) {
    const baseOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    usePointStyle: true,
                    padding: 20
                }
            }
        }
    };
    
    if (chartType === 'pie') {
        return {
            ...baseOptions,
            plugins: {
                ...baseOptions.plugins,
                legend: {
                    position: 'right'
                }
            }
        };
    }
    
    return {
        ...baseOptions,
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'R$ ' + value.toLocaleString('pt-BR');
                    }
                }
            }
        }
    };
}

// Atualizar tabela
function updateTable(data, reportType) {
    const tableHead = document.getElementById('reportTableHead');
    const tableBody = document.getElementById('reportTableBody');
    
    if (!tableHead || !tableBody) return;
    
    // Verificação de segurança para evitar erros
    if (!data || typeof data !== 'object') {
        console.warn('⚠️ updateTable: dados inválidos recebidos:', data);
        tableBody.innerHTML = '<tr><td colspan="100%" style="text-align: center; padding: 2rem;">Erro ao carregar dados</td></tr>';
        return;
    }
    
    tableHead.innerHTML = '';
    tableBody.innerHTML = '';
    
    const dados = data.dados || [];
    if (dados.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="100%" style="text-align: center; padding: 2rem;">Nenhum dado encontrado</td></tr>';
        return;
    }
    
    // Gerar cabeçalhos simples baseados nos dados
    const headers = Object.keys(dados[0]);
    const headerRow = document.createElement('tr');
    headers.forEach(header => {
        const th = document.createElement('th');
        th.textContent = header.charAt(0).toUpperCase() + header.slice(1).replace('_', ' ');
        headerRow.appendChild(th);
    });
    tableHead.appendChild(headerRow);
    
    // Gerar dados (limitados)
    dados.slice(0, 10).forEach(item => {
        const row = document.createElement('tr');
        headers.forEach(header => {
            const td = document.createElement('td');
            let value = item[header];
            
            if (header.includes('total') || header.includes('receita') || header.includes('valor')) {
                value = formatMoney(value || 0);
            }
            
            td.textContent = value || '-';
            row.appendChild(td);
        });
        tableBody.appendChild(row);
    });
}

// Gerar insights simples
function generateInsights(data, reportType) {
    const insightsGrid = document.getElementById('insightsGrid');
    if (!insightsGrid) return;
    
    insightsGrid.innerHTML = '';
    
    // Verificação de segurança
    if (!data || typeof data !== 'object') {
        console.warn('⚠️ generateInsights: dados inválidos recebidos:', data);
        return;
    }
    
    const dados = data.dados || [];
    const insights = [
        {
            title: '📊 Relatório Gerado',
            description: `Relatório de ${reportType.replace('_', ' ')} gerado com ${dados.length} registros encontrados.`
        },
        {
            title: '🎯 Análise Concluída',
            description: 'Dados atualizados e processados com sucesso. Use os filtros para explorar diferentes perspectivas.'
        }
    ];
    
    insights.forEach(insight => {
        const card = document.createElement('div');
        card.className = 'insight-card';
        card.innerHTML = `
            <div class="insight-title">${insight.title}</div>
            <div class="insight-description">${insight.description}</div>
        `;
        insightsGrid.appendChild(card);
    });
}

// Funções utilitárias
function formatMoney(value) {
    if (!value && value !== 0) return 'R$ 0,00';
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function formatMonth(monthStr) {
    if (!monthStr) return '';
    const [year, month] = monthStr.split('-');
    const date = new Date(year, month - 1);
    return date.toLocaleDateString('pt-BR', { year: 'numeric', month: 'long' });
}

function showLoading() {
    const overlay = document.createElement('div');
    overlay.id = 'reportLoading';
    overlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.7); display: flex; justify-content: center;
        align-items: center; z-index: 9999; color: white; font-size: 1.2rem;
    `;
    overlay.innerHTML = '<div>📊 Gerando relatório...</div>';
    document.body.appendChild(overlay);
}

function hideLoading() {
    const overlay = document.getElementById('reportLoading');
    if (overlay) overlay.remove();
}

// Função para exportar relatório
function exportReport() {
    if (!currentReportData) {
        alert('Gere um relatório primeiro!');
        return;
    }
    
    console.log('📤 Exportando relatório...');
    alert('📊 Funcionalidade de exportação em desenvolvimento!');
}

// Função para imprimir relatório
function printReport() {
    window.print();
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Elementos do formulário de relatório
    const reportType = document.getElementById('report_type');
    const reportRange = document.getElementById('report_range');
    const reportChart = document.getElementById('reportChart');
    const reportTable = document.getElementById('reportTable');
    const reportTableHead = document.getElementById('reportTableHead');
    const reportTableBody = document.getElementById('reportTableBody');
    const prevPage = document.getElementById('prevPage');
    const nextPage = document.getElementById('nextPage');
    const pageInfo = document.getElementById('pageInfo');
    const tableSearch = document.getElementById('tableSearch');
    const tableSort = document.getElementById('tableSort');

    // Configurar event listeners
    if (reportType) {
        reportType.addEventListener('change', generateReport);
    }

    if (reportRange) {
        reportRange.addEventListener('change', generateReport);
    }

    if (tableSearch) {
        tableSearch.addEventListener('input', filterTable);
    }

    if (tableSort) {
        tableSort.addEventListener('change', sortTable);
    }

    if (prevPage) {
        prevPage.addEventListener('click', () => changePage(-1));
    }

    if (nextPage) {
        nextPage.addEventListener('click', () => changePage(1));
    }

    // Carregar relatório inicial
    generateReport();
});

// Função para gerar relatório
async function generateReport() {
    console.log('📊 Gerando relatório...');
    
    // Verificar se os elementos necessários existem
    const reportType = document.getElementById('reportType');
    const reportRange = document.getElementById('reportRange');
    
    if (!reportType || !reportRange) {
        console.error('Elementos de seleção de relatório não encontrados');
        showError('Elementos de configuração do relatório não encontrados');
        return;
    }
    
    try {
        // Mostrar loading
        showLoading();
        
        // Verificar se os elementos de exibição existem
        const requiredElements = {
            'reportChart': 'gráfico do relatório',
            'reportTableHead': 'cabeçalho da tabela',
            'reportTableBody': 'corpo da tabela',
            'insightsGrid': 'grid de insights',
            'metricReceita': 'métrica de receita',
            'metricProdutos': 'métrica de produtos',
            'metricClientes': 'métrica de clientes',
            'metricCrescimento': 'métrica de crescimento'
        };
        
        const missingElements = [];
        for (const [id, description] of Object.entries(requiredElements)) {
            if (!document.getElementById(id)) {
                missingElements.push(description);
            }
        }
        
        if (missingElements.length > 0) {
            throw new Error(`Elementos não encontrados: ${missingElements.join(', ')}`);
        }
        
        const response = await fetch(`/api/relatorios/${reportType.value}?range=${reportRange.value}`);
        if (!response.ok) {
            throw new Error(`Erro ao buscar dados: ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.message || 'Erro ao processar dados do relatório');
        }
        
        // Atualizar métricas
        updateMetrics(data.metrics);
        
        // Atualizar gráfico
        updateChart(data.chart);
        
        // Atualizar tabela
        updateTable(data.table);
        
        // Atualizar insights
        updateInsights(data.insights);
        
        // Esconder loading
        hideLoading();
        
        console.log('✅ Relatório gerado com sucesso!');
        
    } catch (error) {
        console.error('❌ Erro ao gerar relatório:', error);
        showError(`Erro ao gerar relatório: ${error.message}`);
        hideLoading();
    }
}

// Função para atualizar métricas
function updateMetrics(metrics) {
    try {
        const elements = {
            metricReceita: document.getElementById('metricReceita'),
            metricProdutos: document.getElementById('metricProdutos'),
            metricClientes: document.getElementById('metricClientes'),
            metricCrescimento: document.getElementById('metricCrescimento')
        };
        
        if (elements.metricReceita) {
            elements.metricReceita.textContent = formatMoney(metrics.receita || 0);
        }
        
        if (elements.metricProdutos) {
            elements.metricProdutos.textContent = metrics.produtos || 0;
        }
        
        if (elements.metricClientes) {
            elements.metricClientes.textContent = metrics.clientes || 0;
        }
        
        if (elements.metricCrescimento) {
            elements.metricCrescimento.textContent = `${metrics.crescimento || 0}%`;
        }
    } catch (error) {
        console.error('Erro ao atualizar métricas:', error);
    }
}

// Função para atualizar gráfico
function updateChart(chartData) {
    try {
        const canvas = document.getElementById('reportChart');
        if (!canvas) {
            console.error('Elemento do gráfico não encontrado');
            return;
        }
        
        const ctx = canvas.getContext('2d');
        
        if (window.currentChart) {
            window.currentChart.destroy();
        }
        
        window.currentChart = new Chart(ctx, {
            type: chartData.type || 'bar',
            data: chartData.data || {
                labels: [],
                datasets: [{
                    label: 'Sem dados',
                    data: []
                }]
            },
            options: chartData.options || {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Sem dados disponíveis'
                    }
                }
            }
        });
    } catch (error) {
        console.error('Erro ao atualizar gráfico:', error);
    }
}

// Função para atualizar tabela
function updateTable(tableData) {
    try {
        const thead = document.getElementById('reportTableHead');
        const tbody = document.getElementById('reportTableBody');
        
        if (!thead || !tbody) {
            console.error('Elementos da tabela não encontrados');
            return;
        }
        
        // Limpar tabela
        thead.innerHTML = '';
        tbody.innerHTML = '';
        
        if (!tableData || !tableData.headers || !tableData.rows) {
            console.warn('Dados da tabela ausentes ou inválidos');
            return;
        }
        
        // Adicionar cabeçalho
        const headerRow = document.createElement('tr');
        tableData.headers.forEach(header => {
            const th = document.createElement('th');
            th.textContent = header;
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        
        // Adicionar dados
        tableData.rows.forEach(row => {
            const tr = document.createElement('tr');
            row.forEach(cell => {
                const td = document.createElement('td');
                td.textContent = cell;
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao atualizar tabela:', error);
    }
}

// Função para atualizar insights
function updateInsights(insights) {
    try {
        const container = document.getElementById('insightsGrid');
        if (!container) {
            console.error('Container de insights não encontrado');
            return;
        }
        
        container.innerHTML = '';
        
        if (!insights || !Array.isArray(insights)) {
            console.warn('Dados de insights ausentes ou inválidos');
            return;
        }
        
        insights.forEach(insight => {
            const card = document.createElement('div');
            card.className = 'insight-card';
            card.innerHTML = `
                <div class="insight-title">${insight.title || 'Sem título'}</div>
                <div class="insight-description">${insight.description || 'Sem descrição'}</div>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        console.error('Erro ao atualizar insights:', error);
    }
}

// Função para mostrar erro
function showError(message) {
    const container = document.getElementById('reportStatus');
    container.innerHTML = `
        <div class="error-message">
            <i class="fas fa-exclamation-circle"></i>
            ${message}
        </div>
    `;
}

// Função para formatar dinheiro
function formatMoney(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

// Função para filtrar tabela
function filterTable() {
    const filter = document.getElementById('tableSearch').value.toLowerCase();
    const rows = document.getElementById('reportTableBody').getElementsByTagName('tr');
    
    Array.from(rows).forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
}

// Função para ordenar tabela
function sortTable() {
    const sort = document.getElementById('tableSort').value;
    const tbody = document.getElementById('reportTableBody');
    const rows = Array.from(tbody.getElementsByTagName('tr'));
    
    rows.sort((a, b) => {
        const aText = a.cells[0].textContent;
        const bText = b.cells[0].textContent;
        
        if (sort === 'asc') {
            return aText.localeCompare(bText);
        } else if (sort === 'desc') {
            return bText.localeCompare(aText);
        } else if (sort === 'value_asc') {
            return parseFloat(aText) - parseFloat(bText);
        } else if (sort === 'value_desc') {
            return parseFloat(bText) - parseFloat(aText);
        }
    });
    
    rows.forEach(row => tbody.appendChild(row));
}

// Função para mudar página
function changePage(direction) {
    // Implementar paginação aqui
}

// Adicionar todas as funções ao namespace
window.Reports.updateReportTitle = updateReportTitle;
window.Reports.updateReportMetrics = updateReportMetrics;
window.Reports.updateReportChart = updateReportChart;
window.Reports.prepareChartData = prepareChartData;
window.Reports.getChartOptions = getChartOptions;
window.Reports.updateTable = updateTable;
window.Reports.generateInsights = generateInsights;
window.Reports.showEmptyDataMessage = showEmptyDataMessage;
window.Reports.getReportTypeDescription = getReportTypeDescription;
window.Reports.formatMoney = formatMoney;
window.Reports.formatMonth = formatMonth;
window.Reports.showLoading = showLoading;
window.Reports.hideLoading = hideLoading;
window.Reports.exportReport = exportReport;
window.Reports.printReport = printReport;

// Expor variáveis globais necessárias
window.Reports.currentChart = null;
window.Reports.currentReportData = null;
window.Reports.colors = colors;

// Mostrar mensagem quando não há dados
function showEmptyDataMessage(reportType) {
    console.log('📋 Mostrando mensagem de dados vazios');
    
    // Limpar métricas
    const metricElements = ['metricReceita', 'metricProdutos', 'metricClientes', 'metricCrescimento'];
    metricElements.forEach(id => {
        const element = document.getElementById(id);
        if (element) element.textContent = '0';
    });
    
    // Limpar gráfico
    const chartElement = document.getElementById('reportChart');
    if (chartElement) {
        const ctx = chartElement.getContext('2d');
        if (currentChart) {
            currentChart.destroy();
        }
        
        // Criar gráfico vazio com mensagem
        currentChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Sem dados'],
                datasets: [{
                    label: 'Nenhum dado disponível',
                    data: [0],
                    backgroundColor: '#e5e7eb',
                    borderColor: '#9ca3af',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Nenhum dado disponível para exibir'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 1
                    }
                }
            }
        });
    }
    
    // Atualizar tabela com mensagem
    const tableHead = document.getElementById('reportTableHead');
    const tableBody = document.getElementById('reportTableBody');
    
    if (tableHead && tableBody) {
        tableHead.innerHTML = '<tr><th>Status</th></tr>';
        tableBody.innerHTML = `
            <tr>
                <td style="text-align: center; padding: 3rem;">
                    <div style="color: #6b7280; font-size: 1.1rem;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">🛒</div>
                        <div><strong>Nenhuma venda encontrada</strong></div>
                        <div style="margin-top: 0.5rem; font-size: 0.9rem;">
                            Para gerar relatórios, você precisa ter dados de ${getReportTypeDescription(reportType)} no sistema.
                        </div>
                        <div style="margin-top: 1rem;">
                            <button onclick="if(typeof showPage === 'function') showPage('dados')" 
                                    style="background: #dc2626; color: white; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 1rem;">
                                🚀 Ir para Dados e Criar Venda
                            </button>
                        </div>
                        <div style="margin-top: 1rem; font-size: 0.9rem; color: #dc2626;">
                            💡 Dica: Você já tem ${currentReportData?.total_produtos || 'alguns'} produtos e ${currentReportData?.total_clientes || 'vários'} clientes cadastrados!
                        </div>
                    </div>
                </td>
            </tr>
        `;
    }
    
    // Atualizar insights
    const insightsGrid = document.getElementById('insightsGrid');
    if (insightsGrid) {
        insightsGrid.innerHTML = `
            <div class="insight-card">
                <div class="insight-title">🚨 Sistema Sem Vendas</div>
                <div class="insight-description">Não há <strong>vendas registradas</strong> no sistema. Os relatórios dependem de dados de vendas para funcionar. Você já tem produtos e clientes cadastrados!</div>
            </div>
            <div class="insight-card">
                <div class="insight-title">✅ Como Resolver</div>
                <div class="insight-description">
                    <strong>Passo 1:</strong> Vá para "Dados" → "Nova Venda"<br>
                    <strong>Passo 2:</strong> Selecione um produto e cliente<br>
                    <strong>Passo 3:</strong> Digite quantidade e clique "Registrar Venda"<br>
                    <strong>Passo 4:</strong> Volte aqui e gere o relatório novamente!
                </div>
            </div>
        `;
    }
}

// Função auxiliar para obter descrição do tipo de relatório
function getReportTypeDescription(reportType) {
    const descriptions = {
        'vendas_mensal': 'vendas',
        'produtos_performance': 'produtos e vendas',
        'clientes_ranking': 'clientes e vendas',
        'categoria_analise': 'produtos categorizados',
        'vendas_detalhado': 'vendas detalhadas'
    };
    return descriptions[reportType] || 'dados';
}

// Função para exportar relatório completo
async function exportCompleteReport(formato = 'json') {
    showLoading();
    try {
        const response = await fetch(`/api/relatorio/completo?formato=${formato}`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `relatorio_completo_ippel_${new Date().toISOString().split('T')[0]}.${formato}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
        
        hideLoading();
        showNotification('✅ Relatório exportado com sucesso!', 'success');
    } catch (error) {
        console.error('❌ Erro ao exportar relatório:', error);
        hideLoading();
        showNotification(`❌ Erro ao exportar: ${error.message}`, 'error');
    }
}

// Função para mostrar notificação
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// Adicionar as novas funções ao namespace
window.Reports.exportCompleteReport = exportCompleteReport;
window.Reports.showNotification = showNotification; 
window.Reports.exportCompleteReport = exportCompleteReport; 

// Função para solicitar análise da IA
async function solicitarAnaliseIA(tipo = 'geral', filtros = {}) {
    showLoading();
    try {
        const response = await fetch('/api/ia/analise', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                tipo: tipo,
                filtros: filtros
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const resultado = await response.json();
        hideLoading();
        
        // Atualizar interface com os resultados
        atualizarAnaliseIA(resultado);
        
        return resultado;
    } catch (error) {
        console.error('❌ Erro ao solicitar análise da IA:', error);
        hideLoading();
        showNotification(`❌ Erro na análise: ${error.message}`, 'error');
        throw error;
    }
}

// Função para atualizar a interface com os resultados da análise
function atualizarAnaliseIA(resultado) {
    const container = document.getElementById('ia-analise-container');
    if (!container) return;
    
    // Limpar container
    container.innerHTML = '';
    
    // Adicionar cabeçalho
    const header = document.createElement('div');
    header.className = 'analise-header';
    header.innerHTML = `
        <h3>📊 Análise da IA - ${resultado.tipo_analise.charAt(0).toUpperCase() + resultado.tipo_analise.slice(1)}</h3>
        <p class="timestamp">Gerado em: ${resultado.timestamp}</p>
    `;
    container.appendChild(header);
    
    // Adicionar dados principais
    if (resultado.dados.estatisticas) {
        const estatisticas = document.createElement('div');
        estatisticas.className = 'estatisticas-grid';
        
        // Converter estatísticas em cards
        Object.entries(resultado.dados.estatisticas).forEach(([chave, valor]) => {
            const card = document.createElement('div');
            card.className = 'estatistica-card';
            card.innerHTML = `
                <div class="estatistica-valor">${formatarValor(valor, chave)}</div>
                <div class="estatistica-label">${formatarChave(chave)}</div>
            `;
            estatisticas.appendChild(card);
        });
        
        container.appendChild(estatisticas);
    }
    
    // Adicionar insights
    if (resultado.dados.insights && resultado.dados.insights.length > 0) {
        const insights = document.createElement('div');
        insights.className = 'insights-container';
        insights.innerHTML = '<h4>💡 Insights</h4>';
        
        const lista = document.createElement('ul');
        resultado.dados.insights.forEach(insight => {
            const item = document.createElement('li');
            item.innerHTML = `<span class="insight-tipo">${insight.tipo}:</span> ${insight.mensagem}`;
            lista.appendChild(item);
        });
        
        insights.appendChild(lista);
        container.appendChild(insights);
    }
    
    // Adicionar análises específicas
    if (resultado.dados.analises) {
        const analises = document.createElement('div');
        analises.className = 'analises-container';
        
        // Adicionar cada tipo de análise
        Object.entries(resultado.dados.analises).forEach(([tipo, dados]) => {
            const secao = document.createElement('div');
            secao.className = 'analise-secao';
            secao.innerHTML = `<h4>${formatarChave(tipo)}</h4>`;
            
            // Converter dados em visualização apropriada
            if (Array.isArray(dados)) {
                // Lista de itens
                const lista = document.createElement('ul');
                dados.forEach(item => {
                    const li = document.createElement('li');
                    li.textContent = JSON.stringify(item, null, 2);
                    lista.appendChild(li);
                });
                secao.appendChild(lista);
            } else if (typeof dados === 'object') {
                // Tabela de dados
                const tabela = document.createElement('table');
                Object.entries(dados).forEach(([chave, valor]) => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${formatarChave(chave)}</td>
                        <td>${formatarValor(valor, chave)}</td>
                    `;
                    tabela.appendChild(tr);
                });
                secao.appendChild(tabela);
            }
            
            analises.appendChild(secao);
        });
        
        container.appendChild(analises);
    }
}

// Funções auxiliares de formatação
function formatarValor(valor, chave) {
    if (typeof valor === 'number') {
        if (chave.includes('valor') || chave.includes('total')) {
            return `R$ ${valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
        }
        if (chave.includes('percentual') || chave.includes('taxa')) {
            return `${valor.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%`;
        }
        return valor.toLocaleString('pt-BR');
    }
    return valor;
}

function formatarChave(chave) {
    return chave
        .split('_')
        .map(palavra => palavra.charAt(0).toUpperCase() + palavra.slice(1))
        .join(' ');
}

// Adicionar as novas funções ao namespace
window.Reports.solicitarAnaliseIA = solicitarAnaliseIA;
window.Reports.atualizarAnaliseIA = atualizarAnaliseIA; 