// Funções auxiliares
function formatMoney(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

// Funções de carregamento de dados
async function loadProdutos() {
    try {
        const response = await fetch('/api/produtos');
        const produtos = await response.json();
        const tbody = document.querySelector('#produtosTable tbody');
        tbody.innerHTML = '';

        produtos.forEach(produto => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${produto.categoria}</td>
                <td>${produto.modelo}</td>
                <td>${formatMoney(produto.preco)}</td>
                <td>${produto.estoque}</td>
                <td>
                    <button class="action-btn edit-btn" onclick="editProduto(${produto.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete-btn" onclick="deleteProduto(${produto.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        // Atualizar selects de produtos
        const produtoSelects = document.querySelectorAll('#admin_produto_id, #admin_manutencao_produto_id');
        produtoSelects.forEach(select => {
            select.innerHTML = '<option value="">Selecione um produto</option>';
            produtos.forEach(produto => {
                select.innerHTML += `<option value="${produto.id}">${produto.categoria} ${produto.modelo}</option>`;
            });
        });
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
    }
}

async function loadVendas() {
    try {
        const response = await fetch('/api/vendas');
        const vendas = await response.json();
        const tbody = document.querySelector('#vendasTable tbody');
        tbody.innerHTML = '';

        vendas.forEach(venda => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${formatDate(venda.data_venda)}</td>
                <td>${venda.categoria} ${venda.modelo}</td>
                <td>${venda.cliente_nome}</td>
                <td>${venda.quantidade}</td>
                <td>${formatMoney(venda.valor_total)}</td>
                <td>
                    <button class="action-btn delete-btn" onclick="deleteVenda(${venda.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar vendas:', error);
    }
}

async function loadClientes() {
    console.log('Carregando lista de clientes...');
    try {
        const response = await fetch('/api/clientes');
        const clientes = await response.json();
        console.log('Clientes carregados:', clientes);

        const tbody = document.querySelector('#clientesTable tbody');
        if (!tbody) {
            console.error('Elemento tbody não encontrado');
            return;
        }

        tbody.innerHTML = '';

        clientes.forEach(cliente => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${cliente.nome}</td>
                <td>${cliente.segmento}</td>
                <td>${cliente.regiao}</td>
                <td>${cliente.ultima_compra ? formatDate(cliente.ultima_compra) : 'Nunca'}</td>
                <td>
                    <button class="action-btn edit-btn" onclick="editCliente(${cliente.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete-btn" onclick="deleteCliente(${cliente.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });

        // Atualizar selects de clientes
        const clienteSelects = document.querySelectorAll('#admin_cliente_id, #admin_manutencao_cliente_id');
        clienteSelects.forEach(select => {
            if (select) {
                select.innerHTML = '<option value="">Selecione um cliente</option>';
                clientes.forEach(cliente => {
                    select.innerHTML += `<option value="${cliente.id}">${cliente.nome}</option>`;
                });
            }
        });
    } catch (error) {
        console.error('Erro ao carregar clientes:', error);
    }
}

async function loadManutencoes() {
    try {
        const response = await fetch('/api/manutencoes');
        const manutencoes = await response.json();
        const tbody = document.querySelector('#manutencoesTable tbody');
        tbody.innerHTML = '';

        manutencoes.forEach(manutencao => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${formatDate(manutencao.data_manutencao)}</td>
                <td>${manutencao.produto_nome}</td>
                <td>${manutencao.cliente_nome}</td>
                <td>${manutencao.tipo}</td>
                <td>${formatMoney(manutencao.custo)}</td>
                <td>
                    <button class="action-btn delete-btn" onclick="deleteManutencao(${manutencao.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar manutenções:', error);
    }
}

// Função para atualizar todos os dados
async function updateAllData() {
    try {
        console.log('Atualizando todos os dados...');
        await Promise.all([
            loadProdutos(),
            loadVendas(),
            loadClientes(),
            loadManutencoes()
        ]);
        console.log('Dados atualizados com sucesso');
    } catch (error) {
        console.error('Erro ao atualizar dados:', error);
    }
}

// Inicialização e Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM carregado, inicializando...');

    // Carregar dados iniciais
    loadProdutos();
    loadClientes();
    loadVendas();
    loadManutencoes();

    // Event Listener para formulário de produtos
    const produtoForm = document.getElementById('produtoForm');
    if (produtoForm) {
        produtoForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('Submetendo formulário de produto...');
            
            const formData = {
                categoria: document.getElementById('produto_categoria').value,
                modelo: document.getElementById('produto_modelo').value,
                preco: parseFloat(document.getElementById('produto_preco').value),
                estoque: parseInt(document.getElementById('produto_estoque').value),
                descricao: document.getElementById('produto_descricao')?.value || ''
            };

            console.log('Dados do formulário:', formData);

            try {
                const response = await fetch('/api/produtos', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                console.log('Status da resposta:', response.status);
                const responseData = await response.json();
                console.log('Resposta do servidor:', responseData);

                if (response.ok) {
                    alert('Produto cadastrado com sucesso!');
                    produtoForm.reset();
                    
                    // Atualizar a lista de produtos
                    await loadProdutos();
                    
                    // Se a página de dados estiver visível, atualizar também
                    const dadosPage = document.getElementById('dados');
                    if (dadosPage && dadosPage.style.display !== 'none') {
                        await refreshData();
                    }
                } else {
                    alert(`Erro ao cadastrar produto: ${responseData.error || 'Erro desconhecido'}`);
                }
            } catch (error) {
                console.error('Erro ao cadastrar produto:', error);
                alert('Erro ao cadastrar produto. Verifique o console para mais detalhes.');
            }
        });
    }

    // Event Listener para formulário de vendas
    const vendaForm = document.getElementById('vendaForm');
    if (vendaForm) {
        vendaForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('Submetendo formulário de venda...');
            
            const produto_id = parseInt(document.getElementById('venda_produto_id').value);
            const quantidade = parseInt(document.getElementById('venda_quantidade').value);
            
            // Buscar o preço do produto para calcular o valor total
            try {
                const produtosResponse = await fetch('/api/produtos');
                const produtos = await produtosResponse.json();
                const produto = produtos.find(p => p.id === produto_id);
                
                if (!produto) {
                    throw new Error('Produto não encontrado');
                }
                
                const formData = {
                    produto_id,
                    cliente_id: parseInt(document.getElementById('venda_cliente_id').value),
                    quantidade,
                    valor_total: produto.preco * quantidade,
                    data_venda: document.getElementById('venda_data').value
                };
                
                console.log('Dados da venda:', formData);

                const response = await fetch('/api/vendas', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    alert('Venda registrada com sucesso!');
                    vendaForm.reset();
                    await loadVendas();
                    
                    // Se a página de dados estiver visível, atualizar também
                    const dadosPage = document.getElementById('dados');
                    if (dadosPage && dadosPage.style.display !== 'none') {
                        await refreshData();
                    }
                } else {
                    const responseData = await response.json();
                    alert(`Erro ao registrar venda: ${responseData.error || 'Erro desconhecido'}`);
                }
            } catch (error) {
                console.error('Erro ao registrar venda:', error);
                alert('Erro ao registrar venda. Verifique o console para mais detalhes.');
            }
        });
    }

    // Event Listener para formulário de clientes
    console.log('Inicializando formulário de clientes...');
    
    const clienteForm = document.getElementById('clienteForm');
    if (clienteForm) {
        console.log('Formulário de clientes encontrado');
        
        clienteForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Impede o comportamento padrão do formulário
            console.log('Formulário de cliente submetido');

            const nome = document.getElementById('admin_nome').value.trim();
            const segmento = document.getElementById('admin_segmento').value;
            const regiao = document.getElementById('admin_regiao').value;

            // Validação dos campos
            if (!nome) {
                alert('Por favor, preencha o nome do cliente');
                return;
            }

            if (!segmento) {
                alert('Por favor, selecione um segmento');
                return;
            }

            if (!regiao) {
                alert('Por favor, selecione uma região');
                return;
            }

            const formData = { nome, segmento, regiao };
            console.log('Dados do formulário:', formData);

            try {
                const response = await fetch('/api/clientes', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                const responseData = await response.json();
                console.log('Resposta do servidor:', responseData);

                if (response.ok) {
                    alert('Cliente cadastrado com sucesso!');
                    clienteForm.reset();
                    
                    // Recarregar dados
                    await loadClientes();
                } else {
                    throw new Error(responseData.error || 'Erro ao cadastrar cliente');
                }
            } catch (error) {
                console.error('Erro ao cadastrar cliente:', error);
                alert(`Erro ao cadastrar cliente: ${error.message}`);
            }
        });
    } else {
        console.error('Formulário de clientes não encontrado!');
    }

    // Event Listener para formulário de manutenções
    const manutencaoForm = document.getElementById('manutencaoForm');
    if (manutencaoForm) {
        manutencaoForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('Submetendo formulário de manutenção...');
            
            const formData = {
                produto_id: parseInt(document.getElementById('admin_manutencao_produto_id').value),
                cliente_id: parseInt(document.getElementById('admin_manutencao_cliente_id').value),
                tipo: document.getElementById('admin_tipo_manutencao').value,
                data_manutencao: document.getElementById('admin_data_manutencao').value,
                custo: parseFloat(document.getElementById('admin_custo_manutencao').value)
            };

            try {
                const response = await fetch('/api/manutencoes', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    alert('Manutenção registrada com sucesso!');
                    e.target.reset();
                    loadManutencoes();
                } else {
                    const error = await response.json();
                    alert(`Erro ao registrar manutenção: ${error.error}`);
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao registrar manutenção');
            }
        });
    }

    // Event Listener para formulário do gerador
    const geradorForm = document.getElementById('geradorForm');
    if (geradorForm) {
        geradorForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            console.log('Submetendo formulário do gerador...');
            
            const formData = {
                num_vendas: parseInt(document.getElementById('num_vendas').value),
                num_manutencoes: parseInt(document.getElementById('num_manutencoes').value),
                periodo_dias: parseInt(document.getElementById('periodo_dias').value)
            };

            try {
                const response = await fetch('/api/gerar_dados', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                if (response.ok) {
                    alert('Dados gerados com sucesso!');
                    loadVendas();
                    loadManutencoes();
                } else {
                    const error = await response.json();
                    alert(`Erro ao gerar dados: ${error.error}`);
                }
            } catch (error) {
                console.error('Erro:', error);
                alert('Erro ao gerar dados');
            }
        });
    }
});

// Funções de exclusão
async function deleteProduto(id) {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
        try {
            const response = await fetch(`/api/produtos/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                loadProdutos();
            } else {
                const error = await response.json();
                alert(`Erro ao excluir produto: ${error.error}`);
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao excluir produto');
        }
    }
}

async function deleteCliente(id) {
    if (confirm('Tem certeza que deseja excluir este cliente?')) {
        try {
            const response = await fetch(`/api/clientes/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                loadClientes();
            } else {
                const error = await response.json();
                alert(`Erro ao excluir cliente: ${error.error}`);
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao excluir cliente');
        }
    }
}

async function deleteVenda(id) {
    if (confirm('Tem certeza que deseja excluir esta venda?')) {
        try {
            const response = await fetch(`/api/vendas/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                loadVendas();
            } else {
                const error = await response.json();
                alert(`Erro ao excluir venda: ${error.error}`);
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao excluir venda');
        }
    }
}

async function deleteManutencao(id) {
    if (confirm('Tem certeza que deseja excluir esta manutenção?')) {
        try {
            const response = await fetch(`/api/manutencoes/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                loadManutencoes();
            } else {
                const error = await response.json();
                alert(`Erro ao excluir manutenção: ${error.error}`);
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao excluir manutenção');
        }
    }
} 