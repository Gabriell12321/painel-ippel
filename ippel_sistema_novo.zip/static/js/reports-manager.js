// Namespace para gerenciamento de relatórios
window.ReportsManager = {
    // Cache de dados
    cache: {
        lastUpdate: null,
        data: null,
        updateInterval: 30 * 1000 // 30 segundos
    },

    // Função para buscar dados do servidor
    async fetchData() {
        try {
            const now = Date.now();
            if (this.cache.lastUpdate && (now - this.cache.lastUpdate) < this.cache.updateInterval) {
                return this.cache.data;
            }

            // Buscar dados dos relatórios
            const [vendasResponse, clientesResponse, produtosResponse] = await Promise.all([
                fetch('/api/relatorios/vendas'),
                fetch('/api/relatorios/clientes'),
                fetch('/api/relatorios/produtos')
            ]);

            if (!vendasResponse.ok || !clientesResponse.ok || !produtosResponse.ok) {
                throw new Error('Erro ao buscar dados dos relatórios');
            }

            const vendas = await vendasResponse.json();
            const clientes = await clientesResponse.json();
            const produtos = await produtosResponse.json();

            this.cache.data = {
                vendas: vendas.data,
                clientes: clientes.data,
                produtos: produtos.data
            };
            this.cache.lastUpdate = now;

            return this.cache.data;
        } catch (error) {
            console.error('Erro ao buscar dados:', error);
            throw error;
        }
    },

    // Função para gerar relatório de vendas
    async generateSalesReport() {
        try {
            const data = await this.fetchData();
            const vendas = data.vendas;

            // Agrupa vendas por mês
            const vendasPorMes = vendas.reduce((acc, venda) => {
                const data = new Date(venda.data_venda);
                const mes = data.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });
                acc[mes] = acc[mes] || { total: 0, quantidade: 0 };
                acc[mes].total += venda.valor_total;
                acc[mes].quantidade += 1;
                return acc;
            }, {});

            // Prepara dados para o gráfico
            const labels = Object.keys(vendasPorMes);
            const valores = labels.map(mes => vendasPorMes[mes].total);
            const quantidades = labels.map(mes => vendasPorMes[mes].quantidade);

            return {
                labels,
                datasets: [
                    {
                        label: 'Valor Total de Vendas',
                        data: valores,
                        borderColor: 'rgb(220, 38, 38)',
                        backgroundColor: 'rgba(220, 38, 38, 0.1)',
                        yAxisID: 'y'
                    },
                    {
                        label: 'Quantidade de Vendas',
                        data: quantidades,
                        borderColor: 'rgb(59, 130, 246)',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        yAxisID: 'y1'
                    }
                ]
            };
        } catch (error) {
            console.error('Erro ao gerar relatório de vendas:', error);
            throw error;
        }
    },

    // Função para gerar relatório de produtos
    async generateProductsReport() {
        try {
            const data = await this.fetchData();
            const produtos = data.produtos;

            // Prepara dados para o gráfico
            const produtosData = produtos
                .sort((a, b) => b.total_vendas - a.total_vendas)
                .slice(0, 10);

            return {
                labels: produtosData.map(p => p.modelo),
                datasets: [
                    {
                        label: 'Quantidade Vendida',
                        data: produtosData.map(p => p.total_vendas),
                        backgroundColor: 'rgba(220, 38, 38, 0.8)'
                    }
                ]
            };
        } catch (error) {
            console.error('Erro ao gerar relatório de produtos:', error);
            throw error;
        }
    },

    // Função para gerar relatório de clientes
    async generateClientsReport() {
        try {
            const data = await this.fetchData();
            const clientes = data.clientes;

            // Prepara dados para o gráfico
            const clientesData = clientes
                .sort((a, b) => b.valor_total_compras - a.valor_total_compras)
                .slice(0, 10);

            return {
                labels: clientesData.map(c => c.nome),
                datasets: [
                    {
                        label: 'Total em Vendas',
                        data: clientesData.map(c => c.valor_total_compras),
                        backgroundColor: 'rgba(16, 185, 129, 0.8)'
                    }
                ]
            };
        } catch (error) {
            console.error('Erro ao gerar relatório de clientes:', error);
            throw error;
        }
    },

    // Função para atualizar todos os gráficos
    async updateAllReports() {
        try {
            // Vendas Mensais
            const salesChart = document.getElementById('reportSalesChart');
            if (salesChart) {
                const salesData = await this.generateSalesReport();
                const existingChart = Chart.getChart(salesChart);
                if (existingChart) existingChart.destroy();
                new Chart(salesChart, {
                    type: 'line',
                    data: salesData,
                    options: {
                        responsive: true,
                        interaction: {
                            mode: 'index',
                            intersect: false
                        },
                        scales: {
                            y: {
                                type: 'linear',
                                display: true,
                                position: 'left',
                                title: {
                                    display: true,
                                    text: 'Valor Total (R$)'
                                }
                            },
                            y1: {
                                type: 'linear',
                                display: true,
                                position: 'right',
                                title: {
                                    display: true,
                                    text: 'Quantidade'
                                },
                                grid: {
                                    drawOnChartArea: false
                                }
                            }
                        }
                    }
                });
            }

            // Produtos Mais Vendidos
            const productsChart = document.getElementById('reportProductsChart');
            if (productsChart) {
                const productsData = await this.generateProductsReport();
                const existingChart = Chart.getChart(productsChart);
                if (existingChart) existingChart.destroy();
                new Chart(productsChart, {
                    type: 'bar',
                    data: productsData,
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top'
                            },
                            title: {
                                display: true,
                                text: 'Produtos Mais Vendidos'
                            }
                        }
                    }
                });
            }

            // Principais Clientes
            const clientsChart = document.getElementById('reportClientsChart');
            if (clientsChart) {
                const clientsData = await this.generateClientsReport();
                const existingChart = Chart.getChart(clientsChart);
                if (existingChart) existingChart.destroy();
                new Chart(clientsChart, {
                    type: 'bar',
                    data: clientsData,
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'top'
                            },
                            title: {
                                display: true,
                                text: 'Principais Clientes'
                            }
                        }
                    }
                });
            }

            // Atualiza as métricas
            const data = await this.fetchData();
            const vendas = data.vendas;
            const clientes = data.clientes;

            // Total de vendas
            const totalVendas = vendas.reduce((sum, venda) => sum + venda.valor_total, 0);
            document.getElementById('reportTotalVendas').textContent = window.formatMoney ? window.formatMoney(totalVendas) : totalVendas.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

            // Total de produtos vendidos
            const totalProdutos = vendas.reduce((sum, venda) => sum + venda.quantidade, 0);
            document.getElementById('reportTotalProdutos').textContent = totalProdutos;

            // Total de clientes ativos
            const clientesAtivos = clientes.length;
            document.getElementById('reportTotalClientes').textContent = clientesAtivos;

            // Crescimento (calculado com base nos últimos 2 meses)
            const hoje = new Date();
            const mesAtual = hoje.getMonth();
            const mesAnterior = mesAtual - 1;

            const vendasMesAtual = vendas.filter(v => {
                const dataVenda = new Date(v.data_venda);
                return dataVenda.getMonth() === mesAtual;
            }).reduce((sum, v) => sum + v.valor_total, 0);

            const vendasMesAnterior = vendas.filter(v => {
                const dataVenda = new Date(v.data_venda);
                return dataVenda.getMonth() === mesAnterior;
            }).reduce((sum, v) => sum + v.valor_total, 0);

            const crescimento = vendasMesAnterior > 0 
                ? ((vendasMesAtual - vendasMesAnterior) / vendasMesAnterior * 100).toFixed(1)
                : 0;

            document.getElementById('reportCrescimento').textContent = `${crescimento}%`;

            console.log('Relatórios atualizados com sucesso');
        } catch (error) {
            console.error('Erro ao atualizar relatórios:', error);
        }
    }
};

// Função para exportar relatório em PDF
window.exportReportPDF = async function() {
    try {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Configurações iniciais
        doc.setFont('helvetica');
        doc.setFontSize(20);
        doc.text('Relatório Ippel Equipamentos', 20, 20);
        
        // Data do relatório
        doc.setFontSize(12);
        doc.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, 20, 30);
        
        // Período selecionado
        const periodo = document.getElementById('report_period')?.value || '30';
        doc.text(`Período: Últimos ${periodo} dias`, 20, 40);
        
        // Métricas principais
        doc.setFontSize(14);
        doc.text('Métricas Principais', 20, 55);
        doc.setFontSize(12);
        doc.text(`Total em Vendas: ${document.getElementById('reportTotalVendas')?.textContent || 'N/A'}`, 25, 65);
        doc.text(`Produtos Vendidos: ${document.getElementById('reportTotalProdutos')?.textContent || 'N/A'}`, 25, 75);
        doc.text(`Clientes Ativos: ${document.getElementById('reportTotalClientes')?.textContent || 'N/A'}`, 25, 85);
        doc.text(`Crescimento: ${document.getElementById('reportCrescimento')?.textContent || 'N/A'}`, 25, 95);
        
        // Gráficos
        let yPos = 110;
        const charts = ['reportSalesChart', 'reportProductsChart', 'reportClientsChart'];
        const chartTitles = ['Vendas Mensais', 'Produtos Mais Vendidos', 'Principais Clientes'];
        
        for(let i = 0; i < charts.length; i++) {
            const canvas = document.getElementById(charts[i]);
            if (canvas) {
                // Adicionar título do gráfico
                doc.setFontSize(14);
                doc.text(chartTitles[i], 20, yPos);
                
                // Adicionar gráfico
                const imgData = canvas.toDataURL('image/png');
                doc.addImage(imgData, 'PNG', 20, yPos + 5, 170, 80);
                
                yPos += 100;
                
                // Adicionar nova página se necessário
                if (i < charts.length - 1 && yPos > 250) {
                    doc.addPage();
                    yPos = 20;
                }
            }
        }
        
        // Salvar o PDF
        doc.save('relatorio-ippel.pdf');
        
    } catch (error) {
        console.error('Erro ao exportar PDF:', error);
        alert('Erro ao gerar PDF. Por favor, tente novamente.');
    }
};

// Função para exportar relatório em Excel
window.exportReportExcel = async function() {
    try {
        const data = await ReportsManager.fetchData();
        const vendas = data.vendas;
        const produtos = data.produtos;
        const clientes = data.clientes;
        
        // Criar workbook
        const wb = XLSX.utils.book_new();
        
        // Planilha de Vendas
        const vendasData = vendas.map(v => ({
            'Data': new Date(v.data_venda).toLocaleDateString('pt-BR'),
            'Cliente': v.cliente_nome,
            'Produto': v.produto_nome,
            'Quantidade': v.quantidade,
            'Valor Total': v.valor_total
        }));
        const wsVendas = XLSX.utils.json_to_sheet(vendasData);
        XLSX.utils.book_append_sheet(wb, wsVendas, 'Vendas');
        
        // Planilha de Produtos
        const produtosData = produtos.map(p => ({
            'Modelo': p.modelo,
            'Categoria': p.categoria,
            'Total Vendido': p.total_vendas,
            'Estoque': p.estoque
        }));
        const wsProdutos = XLSX.utils.json_to_sheet(produtosData);
        XLSX.utils.book_append_sheet(wb, wsProdutos, 'Produtos');
        
        // Planilha de Clientes
        const clientesData = clientes.map(c => ({
            'Nome': c.nome,
            'Total em Compras': c.valor_total_compras,
            'Última Compra': c.ultima_compra ? new Date(c.ultima_compra).toLocaleDateString('pt-BR') : 'N/A'
        }));
        const wsClientes = XLSX.utils.json_to_sheet(clientesData);
        XLSX.utils.book_append_sheet(wb, wsClientes, 'Clientes');
        
        // Exportar arquivo
        XLSX.writeFile(wb, 'relatorio-ippel.xlsx');
        
    } catch (error) {
        console.error('Erro ao exportar Excel:', error);
        alert('Erro ao gerar Excel. Por favor, tente novamente.');
    }
};

// Inicializa os relatórios quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    // Atualiza os relatórios quando a página de relatórios for aberta
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            const page = this.getAttribute('data-page');
            if (page === 'relatorios') {
                setTimeout(() => {
                    ReportsManager.updateAllReports();
                }, 500);
            }
        });
    });

    // Atualização automática a cada 30 segundos se a página de relatórios estiver ativa
    setInterval(() => {
        const relatoriosPage = document.getElementById('relatorios');
        if (relatoriosPage && relatoriosPage.classList.contains('active')) {
            ReportsManager.updateAllReports();
        }
    }, 30 * 1000);
}); 