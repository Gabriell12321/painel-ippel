from g4f.Provider import FreeGpt, You, DuckDuckGo, DeepInfraChat, Chatai
from g4f import ChatCompletion
from flask import Flask, request, jsonify, send_from_directory, make_response, render_template
from flask_cors import CORS
import sqlite3
import logging
from datetime import datetime, timedelta
import random
from database import init_db, get_db_connection, generate_sample_data
import json
import os
import sys
import io
import csv
from check_data import get_all_data
import pandas as pd
import calendar

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_url_path='', static_folder='static')
CORS(app)


@app.route('/')
def index():
    return app.send_static_file('index.html')


@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)


# Adicionar o caminho do gpt4free-main ao Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'gpt4free-main'))

# Importar do gpt4free apenas o que precisamos

# Configuração simples - usar providers que funcionam sem configuração
WORKING_PROVIDERS = [
    FreeGpt,
    You,
    DuckDuckGo,
    DeepInfraChat,
    Chatai
]

# Informações da empresa
IPPEL_INFO = """
INFORMAÇÕES OFICIAIS DA IPPEL EQUIPAMENTOS:

Razão Social: Ippel Equipamentos Ltda
CNPJ: 79.902.185/0001-80
Endereço: Av. Nossa Sra. das Brotas, 100, Piraí do Sul - PR, CEP: 84240-000
Website: https://ippel.com.br/

SOBRE A EMPRESA:
A IPPEL EQUIPAMENTOS é uma empresa especializada em equipamentos industriais, localizada em Piraí do Sul, PR.

ESPECIALIDADES:
- Equipamentos Industriais
- Vendas de Máquinas e Equipamentos
- Manutenção Industrial
- Assistência Técnica Especializada

COMPROMISSO:
Fornecemos soluções em equipamentos industriais com qualidade e excelência no atendimento.
"""


def get_ai_response_simple(messages):
    """Obtém resposta usando providers simples do gpt4free"""

    # Forçar contexto em português brasileiro
    if messages and messages[0]["role"] == "system":
        context = f"""Você é o assistente oficial da IPPEL EQUIPAMENTOS.

IMPORTANTE: SEMPRE RESPONDA EM PORTUGUÊS DO BRASIL, NUNCA EM OUTRO IDIOMA.

{IPPEL_INFO}

INSTRUÇÕES ESPECÍFICAS:
1. SEMPRE responda em português brasileiro, NUNCA em outro idioma
2. Use as informações oficiais da empresa fornecidas acima
3. Mantenha um tom profissional e prestativo
4. Se receber uma mensagem em outro idioma, responda em português do Brasil

{messages[0]['content']}"""
        messages[0]["content"] = context

    import time

    for provider in WORKING_PROVIDERS:
        try:
            logger.info(f"[BOT] Tentando provider: {provider.__name__}")
            time.sleep(2)

            response = ChatCompletion.create(
                model="gpt-3.5-turbo",
                provider=provider,
                messages=messages,
                stream=False
            )

            if response:
                # Verificar se a resposta está em português
                if any(chinese_char in response for chinese_char in '你好您好'):
                    logger.warning(f"[AVISO] Resposta em chinês detectada de {provider.__name__}, tentando próximo provider...")
                    continue
                    
                logger.info(f"[SUCESSO] Sucesso com {provider.__name__}")
                return response
            else:
                logger.warning(f"[AVISO] Resposta vazia de {provider.__name__}")
                continue

        except Exception as e:
            error_msg = str(e).lower()
            if "当日额度" in error_msg or "ip" in error_msg:
                logger.warning(f"[ERRO] Limite de IP atingido para {provider.__name__}, tentando próximo provider...")
                time.sleep(3)
            else:
                logger.warning(f"[ERRO] Erro com {provider.__name__}: {error_msg[:100]}...")
                continue

    logger.warning("[AVISO] Todos os providers falharam, usando resposta padrão")
    return """Olá! Sou o assistente oficial da Ippel Equipamentos.

Estou aqui para ajudá-lo com informações sobre nossa empresa em Piraí do Sul - PR.
Posso fornecer detalhes sobre:
- Nossos produtos e equipamentos industriais
- Serviços de manutenção e assistência técnica
- Informações sobre vendas e atendimento

Nosso compromisso é fornecer soluções em equipamentos industriais com qualidade e excelência.
Como posso ajudá-lo hoje?"""


def _format_clientes_data(clientes_data):
    if not clientes_data:
        return "Nenhum cliente cadastrado no banco de dados."

    formatted = ["[LISTA DE TODOS OS CLIENTES CADASTRADOS]"]
    for cliente in clientes_data:
        id_cliente, nome, segmento, regiao, email, telefone, ultima_compra = cliente
        formatted.append(f"""• Cliente ID {id_cliente}:
  - Nome: {nome}
  - Segmento: {segmento}
  - Região: {regiao}
  - Contato: {email or 'Não informado'} / {telefone or 'Não informado'}
  - Última Compra: {ultima_compra or 'Nunca comprou'}""")

    return "\n\n".join(formatted)


def _format_produtos_data(produtos_data):
    if not produtos_data:
        return "Nenhum produto cadastrado no banco de dados."

    formatted = ["[LISTA DE TODOS OS PRODUTOS DISPONÍVEIS]"]
    for produto in produtos_data:
        id_produto, categoria, modelo, preco, estoque, descricao = produto
        formatted.append(f"""• Produto ID {id_produto}:
  - Categoria: {categoria}
  - Modelo: {modelo}
  - Preço: R$ {preco:,.2f}
  - Estoque Atual: {estoque} unidades
  - Descrição: {descricao or 'Não informada'}""")

    return "\n\n".join(formatted)


def _format_vendas_data(vendas_data):
    if not vendas_data:
        return "Nenhuma venda registrada no banco de dados."

    formatted = ["[HISTÓRICO COMPLETO DE VENDAS]"]
    for venda in vendas_data:
        id_venda, data_venda, cliente_nome, produto_modelo, quantidade, valor_total, categoria, segmento, regiao = venda
        formatted.append(f"""• Venda ID {id_venda}:
  - Data: {data_venda}
  - Cliente: {cliente_nome} ({segmento} - {regiao})
  - Produto: {categoria} {produto_modelo}
  - Quantidade: {quantidade} unidades
  - Valor Total: R$ {valor_total:,.2f}""")

    return "\n\n".join(formatted)


def _format_manutencoes_data(manutencoes_data):
    if not manutencoes_data:
        return "Nenhuma manutenção registrada no banco de dados."

    formatted = ["[REGISTRO COMPLETO DE MANUTENÇÕES]"]
    for manutencao in manutencoes_data:
        id_manutencao, data_manutencao, produto_nome, cliente_nome, tipo, status, custo = manutencao
        formatted.append(f"""• Manutenção ID {id_manutencao}:
  - Data: {data_manutencao}
  - Cliente: {cliente_nome}
  - Produto: {produto_nome}
  - Tipo: {tipo}
  - Status: {status}
  - Custo: R$ {custo:,.2f}""")

    return "\n\n".join(formatted)


@app.route('/admin')
def admin():
    return send_from_directory('static', 'admin.html')


@app.route('/test_dashboard.html')
def test_dashboard():
    return send_from_directory('static', 'test_dashboard.html')


@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        mensagem = request.json.get('message', '')

        # Obter dados formatados do banco
        dados_formatados = get_all_data()

        # Criar o contexto com os dados do banco
        context = f"""Você é o assistente oficial da IPPEL EQUIPAMENTOS com acesso aos seguintes dados atualizados do sistema:

{dados_formatados}

IMPORTANTE: SEMPRE RESPONDA EM PORTUGUÊS DO BRASIL, NUNCA EM OUTRO IDIOMA.

INSTRUÇÕES ESPECÍFICAS:
1. SEMPRE responda em português brasileiro, NUNCA em outro idioma
2. Use os dados acima para responder às perguntas de forma precisa e profissional
3. Se a pergunta for sobre dados específicos (vendas, produtos, clientes, etc), use os dados fornecidos acima
4. Se a pergunta for sobre tendências ou análises, use os dados históricos fornecidos
5. Se receber uma mensagem em outro idioma, responda em português do Brasil
6. Mantenha um tom profissional e prestativo

Por favor, use esses dados para responder às perguntas de forma precisa e profissional."""

        # Preparar as mensagens para o modelo
        messages = [
            {"role": "system", "content": context},
            {"role": "user", "content": mensagem}
        ]

        # Obter resposta usando a função existente
        resposta = get_ai_response_simple(messages)

        return jsonify({"response": resposta})

    except Exception as e:
        logger.error(f"Erro no chat: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Rotas para o Dashboard


@app.route('/api/dados/dashboard')
def get_dashboard_data():
    """Retorna dados atualizados para o dashboard"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Buscar dados de vendas dos últimos 30 dias
        data_limite = (
            datetime.now() -
            timedelta(
                days=30)).strftime('%Y-%m-%d')
        cursor.execute('''
            SELECT COUNT(*) as total_vendas, SUM(valor_total) as valor_total
            FROM vendas
            WHERE data_venda >= ?
        ''', (data_limite,))
        vendas_mes = cursor.fetchone()

        # Buscar total de vendas geral
        cursor.execute('''
            SELECT COUNT(*) as total_vendas, SUM(valor_total) as valor_total
            FROM vendas
        ''')
        vendas_total = cursor.fetchone()

        # Buscar total de clientes
        cursor.execute('SELECT COUNT(*) FROM clientes')
        total_clientes = cursor.fetchone()[0]

        # Buscar total de produtos
        cursor.execute('SELECT COUNT(*) FROM produtos')
        total_produtos = cursor.fetchone()[0]

        # Buscar produtos com estoque baixo
        cursor.execute('SELECT COUNT(*) FROM produtos WHERE estoque < 5')
        produtos_estoque_baixo = cursor.fetchone()[0]

        # Buscar status das manutenções
        cursor.execute('''
            SELECT status, COUNT(*) as quantidade
            FROM manutencoes
            GROUP BY status
        ''')
        manutencoes_status = [
            {'status': row[0], 'quantidade': row[1]}
            for row in cursor.fetchall()
        ]

        # Buscar clientes por região
        cursor.execute('''
            SELECT regiao, COUNT(*) as quantidade
            FROM clientes
            GROUP BY regiao
        ''')
        clientes_regiao = [
            {'regiao': row[0], 'quantidade': row[1]}
            for row in cursor.fetchall()
        ]

        # Buscar produtos mais vendidos (últimos 90 dias)
        data_limite_produtos = (
            datetime.now() -
            timedelta(
                days=90)).strftime('%Y-%m-%d')
        cursor.execute('''
            SELECT p.modelo, COUNT(*) as quantidade
            FROM vendas v
            JOIN produtos p ON v.produto_id = p.id
            WHERE v.data_venda >= ?
            GROUP BY p.modelo
            ORDER BY quantidade DESC
            LIMIT 5
        ''', (data_limite_produtos,))
        produtos_mais_vendidos = [
            {'modelo': row[0], 'quantidade': row[1]}
            for row in cursor.fetchall()
        ]

        conn.close()

        return jsonify({
            'vendas_mes': {
                'total_vendas': vendas_mes[0] if vendas_mes else 0,
                'valor_total': vendas_mes[1] if vendas_mes else 0
            },
            'vendas_total': {
                'total_vendas': vendas_total[0] if vendas_total else 0,
                'valor_total': vendas_total[1] if vendas_total else 0
            },
            'total_clientes': total_clientes,
            'total_produtos': total_produtos,
            'produtos_estoque_baixo': produtos_estoque_baixo,
            'manutencoes_status': manutencoes_status,
            'clientes_regiao': clientes_regiao,
            'produtos_mais_vendidos': produtos_mais_vendidos,
            'ultima_atualizacao': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

    except Exception as e:
        logger.error(f"Erro ao buscar dados do dashboard: {str(e)}")
        return jsonify({"error": "Erro ao buscar dados do dashboard"}), 500


@app.route('/api/dados/clientes')
def get_clientes_data():
    """Retorna dados dos clientes"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT nome, segmento, regiao, ultima_compra, email, telefone
            FROM clientes
            ORDER BY nome
        ''')
        clientes = [
            {
                'nome': row[0],
                'segmento': row[1],
                'regiao': row[2],
                'ultima_compra': row[3],
                'email': row[4],
                'telefone': row[5]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return jsonify(clientes)

    except Exception as e:
        logger.error(f"Erro ao buscar dados de clientes: {str(e)}")
        return jsonify({"error": "Erro ao buscar dados de clientes"}), 500


@app.route('/api/dados/produtos')
def get_produtos_data():
    """Retorna dados dos produtos"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, categoria, modelo, preco, estoque, descricao
            FROM produtos
            ORDER BY categoria, modelo
        ''')
        produtos = [
            {
                'id': row[0],
                'categoria': row[1],
                'modelo': row[2],
                'preco': row[3],
                'estoque': row[4],
                'descricao': row[5]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return jsonify(produtos)

    except Exception as e:
        logger.error(f"Erro ao buscar dados de produtos: {str(e)}")
        return jsonify({"error": "Erro ao buscar dados de produtos"}), 500


@app.route('/api/dados/vendas')
def get_vendas_data():
    """Retorna dados das vendas"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute('''
            SELECT v.id, v.data_venda, c.nome as cliente_nome, p.modelo as produto_modelo,
                   v.quantidade, v.valor_total
            FROM vendas v
            JOIN clientes c ON v.cliente_id = c.id
            JOIN produtos p ON v.produto_id = p.id
            ORDER BY v.data_venda DESC
        ''')
        vendas = [
            {
                'id': row[0],
                'data_venda': row[1],
                'cliente_nome': row[2],
                'produto_modelo': row[3],
                'quantidade': row[4],
                'valor_total': row[5]
            }
            for row in cursor.fetchall()
        ]

        conn.close()
        return jsonify(vendas)

    except Exception as e:
        logger.error(f"Erro ao buscar dados de vendas: {str(e)}")
        return jsonify({"error": "Erro ao buscar dados de vendas"}), 500


@app.route('/api/relatorios/<report_type>')
def get_report_data(report_type):
    """Retorna dados para relatórios"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        if report_type == 'vendas_mensal':
            # Buscar vendas mensais dos últimos 12 meses
            cursor.execute('''
                SELECT
                    strftime('%Y-%m', data_venda) as mes,
                    COUNT(*) as num_vendas,
                    SUM(valor_total) as total_vendas
                FROM vendas
                WHERE data_venda >= date('now', '-12 months')
                GROUP BY strftime('%Y-%m', data_venda)
                ORDER BY mes DESC
            ''')

            dados = [
                {
                    'mes': row[0],
                    'num_vendas': row[1],
                    'total_vendas': row[2]
                }
                for row in cursor.fetchall()
            ]

        elif report_type == 'produtos_performance':
            # Buscar performance dos produtos
            cursor.execute('''
                SELECT
                    p.modelo,
                    p.categoria,
                    COUNT(v.id) as total_vendido,
                    SUM(v.valor_total) as receita_total,
                    AVG(v.valor_total) as ticket_medio
                FROM produtos p
                LEFT JOIN vendas v ON v.produto_id = p.id
                GROUP BY p.id, p.modelo
                ORDER BY receita_total DESC
            ''')

            dados = [
                {
                    'modelo': row[0],
                    'categoria': row[1],
                    'total_vendido': row[2],
                    'receita_total': row[3],
                    'ticket_medio': row[4]
                }
                for row in cursor.fetchall()
            ]

        elif report_type == 'clientes_ranking':
            # Buscar ranking de clientes
            cursor.execute('''
                SELECT
                    c.nome,
                    c.segmento,
                    COUNT(v.id) as total_compras,
                    SUM(v.valor_total) as valor_total_compras,
                    MAX(v.data_venda) as ultima_compra
                FROM clientes c
                LEFT JOIN vendas v ON v.cliente_id = c.id
                GROUP BY c.id, c.nome
                ORDER BY valor_total_compras DESC
            ''')

            dados = [
                {
                    'nome': row[0],
                    'segmento': row[1],
                    'total_compras': row[2],
                    'valor_total_compras': row[3],
                    'ultima_compra': row[4]
                }
                for row in cursor.fetchall()
            ]

        elif report_type == 'categoria_analise':
            # Buscar análise por categoria
            cursor.execute('''
                SELECT
                    p.categoria,
                    COUNT(DISTINCT p.id) as total_produtos,
                    COUNT(v.id) as total_vendas,
                    SUM(v.valor_total) as valor_total,
                    AVG(v.valor_total) as ticket_medio
                FROM produtos p
                LEFT JOIN vendas v ON v.produto_id = p.id
                GROUP BY p.categoria
                ORDER BY valor_total DESC
            ''')

            dados = [
                {
                    'categoria': row[0],
                    'total_produtos': row[1],
                    'total_vendas': row[2],
                    'valor_total': row[3],
                    'ticket_medio': row[4]
                }
                for row in cursor.fetchall()
            ]

        elif report_type == 'vendas_detalhado':
            # Buscar vendas detalhadas
            cursor.execute('''
                SELECT
                    v.id,
                    v.data_venda,
                    c.nome as cliente_nome,
                    p.modelo as produto_modelo,
                    v.quantidade,
                    v.valor_total,
                    p.categoria as produto_categoria
                FROM vendas v
                JOIN clientes c ON v.cliente_id = c.id
                JOIN produtos p ON v.produto_id = p.id
                ORDER BY v.data_venda DESC
                LIMIT 100
            ''')

            dados = [
                {
                    'id': row[0],
                    'data_venda': row[1],
                    'cliente_nome': row[2],
                    'produto_modelo': row[3],
                    'quantidade': row[4],
                    'valor_total': row[5],
                    'produto_categoria': row[6]
                }
                for row in cursor.fetchall()
            ]

        else:
            return jsonify({
                'error': 'Tipo de relatório não suportado',
                'tipo': report_type
            }), 400

        conn.close()

        return jsonify({
            'tipo': report_type,
            'dados': dados,
            'ultima_atualizacao': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

    except Exception as e:
        logger.error(f"Erro ao gerar relatório {report_type}: {str(e)}")
        return jsonify({
            'error': f'Erro ao gerar relatório: {str(e)}',
            'tipo': report_type
        }), 500


@app.route('/api/relatorios/graficos_mensais')
def get_graficos_mensais():
    """Retorna dados para os gráficos mensais"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Lista para armazenar os gráficos e títulos
        graficos = []
        titulos = []

        # 1. Vendas Mensais
        cursor.execute('''
            SELECT
                strftime('%Y-%m', data_venda) as mes,
                COUNT(*) as num_vendas,
                SUM(valor_total) as total_vendas
            FROM vendas
            WHERE data_venda >= date('now', '-12 months')
            GROUP BY strftime('%Y-%m', data_venda)
            ORDER BY mes
        ''')

        dados_vendas = cursor.fetchall()
        meses = [row[0] for row in dados_vendas]
        valores = [row[2] for row in dados_vendas]

        grafico_vendas = [{
            'type': 'scatter',
            'x': meses,
            'y': valores,
            'name': 'Vendas',
            'line': {'color': '#dc2626', 'width': 3},
            'fill': 'tozeroy',
            'fillcolor': 'rgba(220, 38, 38, 0.1)'
        }]

        graficos.append(json.dumps(grafico_vendas))
        titulos.append('Vendas Mensais')

        # 2. Performance de Produtos
        cursor.execute('''
            SELECT
                p.modelo,
                SUM(v.valor_total) as receita_total
            FROM produtos p
            LEFT JOIN vendas v ON v.produto_id = p.id
            GROUP BY p.id, p.modelo
            ORDER BY receita_total DESC
            LIMIT 10
        ''')

        dados_produtos = cursor.fetchall()
        produtos = [row[0] for row in dados_produtos]
        receitas = [row[1] for row in dados_produtos]

        grafico_produtos = [{
            'type': 'bar',
            'x': produtos,
            'y': receitas,
            'name': 'Receita',
            'marker': {
                'color': '#16a34a'
            }
        }]

        graficos.append(json.dumps(grafico_produtos))
        titulos.append('Top 10 Produtos por Receita')

        # 3. Clientes por Região
        cursor.execute('''
            SELECT
                regiao,
                COUNT(*) as total_clientes
            FROM clientes
            GROUP BY regiao
            ORDER BY total_clientes DESC
        ''')

        dados_regioes = cursor.fetchall()
        regioes = [row[0] for row in dados_regioes]
        total_clientes = [row[1] for row in dados_regioes]

        grafico_regioes = [{
            'type': 'pie',
            'labels': regioes,
            'values': total_clientes,
            'hole': 0.4,
            'marker': {
                'colors': ['#dc2626', '#16a34a', '#2563eb', '#ca8a04', '#64748b']
            }
        }]

        graficos.append(json.dumps(grafico_regioes))
        titulos.append('Distribuição de Clientes por Região')

        # 4. Vendas por Categoria
        cursor.execute('''
            SELECT
                p.categoria,
                COUNT(v.id) as total_vendas,
                SUM(v.valor_total) as valor_total
            FROM produtos p
            LEFT JOIN vendas v ON v.produto_id = p.id
            GROUP BY p.categoria
            ORDER BY valor_total DESC
        ''')

        dados_categorias = cursor.fetchall()
        categorias = [row[0] for row in dados_categorias]
        vendas_cat = [row[1] for row in dados_categorias]
        valores_cat = [row[2] for row in dados_categorias]

        grafico_categorias = [
            {
                'type': 'bar',
                'x': categorias,
                'y': valores_cat,
                'name': 'Valor Total',
                'marker': {'color': '#2563eb'}
            },
            {
                'type': 'scatter',
                'x': categorias,
                'y': vendas_cat,
                'name': 'Quantidade',
                'yaxis': 'y2',
                'line': {'color': '#dc2626', 'width': 2}
            }
        ]

        graficos.append(json.dumps(grafico_categorias))
        titulos.append('Vendas por Categoria')

        conn.close()

        return jsonify({
            'graficos': graficos,
            'titulos': titulos,
            'ultima_atualizacao': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

    except Exception as e:
        logger.error(f"Erro ao gerar gráficos mensais: {str(e)}")
        return jsonify({
            'error': True,
            'message': f'Erro ao gerar gráficos: {str(e)}'
        }), 500


@app.route('/relatorios')
def relatorios():
    return send_from_directory('static', 'relatorios_graficos.html')


@app.route('/api/dados/vendas', methods=['POST'])
def add_venda():
    """Adiciona uma nova venda"""
    try:
        data = request.json
        
        if not all(key in data for key in ['produto_id', 'cliente_id', 'quantidade']):
            return jsonify({"error": "Dados incompletos"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Buscar preço do produto
        cursor.execute('SELECT preco, estoque FROM produtos WHERE id = ?', (data['produto_id'],))
        produto = cursor.fetchone()
        
        if not produto:
            return jsonify({"error": "Produto não encontrado"}), 404
        
        preco, estoque = produto
        quantidade = int(data['quantidade'])
        
        # Verificar estoque
        if quantidade > estoque:
            return jsonify({"error": "Estoque insuficiente"}), 400
        
        # Calcular valor total com desconto
        valor_total = preco * quantidade
        if 'desconto' in data and data['desconto']:
            desconto = float(data['desconto']) / 100
            valor_total = valor_total * (1 - desconto)
        
        # Inserir venda
        cursor.execute('''
            INSERT INTO vendas (produto_id, cliente_id, quantidade, valor_total, data_venda)
            VALUES (?, ?, ?, ?, datetime('now'))
        ''', (data['produto_id'], data['cliente_id'], quantidade, valor_total))
        
        # Atualizar estoque
        cursor.execute('''
            UPDATE produtos
            SET estoque = estoque - ?
            WHERE id = ?
        ''', (quantidade, data['produto_id']))
        
        # Atualizar última compra do cliente
        cursor.execute('''
            UPDATE clientes
            SET ultima_compra = datetime('now')
            WHERE id = ?
        ''', (data['cliente_id'],))
        
        conn.commit()
        conn.close()
        
        return jsonify({"message": "Venda registrada com sucesso"})
        
    except Exception as e:
        logger.error(f"Erro ao registrar venda: {str(e)}")
        return jsonify({"error": "Erro ao registrar venda"}), 500

@app.route('/api/dados/produtos', methods=['POST'])
def add_produto():
    """Adiciona um novo produto"""
    try:
        data = request.json
        
        if not all(key in data for key in ['categoria', 'modelo', 'preco', 'estoque']):
            return jsonify({"error": "Dados incompletos"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO produtos (categoria, modelo, preco, estoque, descricao)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            data['categoria'],
            data['modelo'],
            float(data['preco']),
            int(data['estoque']),
            data.get('descricao', '')
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({"message": "Produto adicionado com sucesso"})
        
    except Exception as e:
        logger.error(f"Erro ao adicionar produto: {str(e)}")
        return jsonify({"error": "Erro ao adicionar produto"}), 500

@app.route('/api/dados/clientes', methods=['POST'])
def add_cliente():
    """Adiciona um novo cliente"""
    try:
        data = request.json
        
        if not all(key in data for key in ['nome', 'segmento', 'regiao', 'email', 'telefone', 'endereco']):
            return jsonify({"error": "Dados incompletos"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO clientes (nome, segmento, regiao, email, telefone, endereco)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            data['nome'],
            data['segmento'],
            data['regiao'],
            data['email'],
            data['telefone'],
            data['endereco']
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({"message": "Cliente adicionado com sucesso"})
        
    except Exception as e:
        logger.error(f"Erro ao adicionar cliente: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/dados/produtos/<int:id>', methods=['DELETE'])
def delete_produto(id):
    """Deleta um produto"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verificar se existem vendas relacionadas
        cursor.execute('SELECT COUNT(*) FROM vendas WHERE produto_id = ?', (id,))
        if cursor.fetchone()[0] > 0:
            return jsonify({"error": "Não é possível excluir produto com vendas relacionadas"}), 400
        
        cursor.execute('DELETE FROM produtos WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        
        return jsonify({"message": "Produto excluído com sucesso"})
        
    except Exception as e:
        logger.error(f"Erro ao excluir produto: {str(e)}")
        return jsonify({"error": "Erro ao excluir produto"}), 500

@app.route('/api/dados/vendas/<int:id>', methods=['DELETE'])
def delete_venda(id):
    """Deleta uma venda"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Buscar quantidade e produto_id da venda
        cursor.execute('SELECT quantidade, produto_id FROM vendas WHERE id = ?', (id,))
        venda = cursor.fetchone()
        
        if not venda:
            return jsonify({"error": "Venda não encontrada"}), 404
        
        quantidade, produto_id = venda
        
        # Restaurar estoque
        cursor.execute('''
            UPDATE produtos
            SET estoque = estoque + ?
            WHERE id = ?
        ''', (quantidade, produto_id))
        
        # Excluir venda
        cursor.execute('DELETE FROM vendas WHERE id = ?', (id,))
        
        conn.commit()
        conn.close()
        
        return jsonify({"message": "Venda excluída com sucesso"})
        
    except Exception as e:
        logger.error(f"Erro ao excluir venda: {str(e)}")
        return jsonify({"error": "Erro ao excluir venda"}), 500

@app.route('/api/analyze', methods=['POST'])
def analyze_data():
    try:
        data = request.json
        query = data['query'].lower()
        
        # Conecta ao banco de dados
        conn = sqlite3.connect('ippel.db')
        cursor = conn.cursor()
        
        # Análise de vendas por mês
        if 'quem comprou' in query and ('mês' in query or 'mes' in query):
            # Extrai o mês da query
            months = {
                'janeiro': 1, 'fevereiro': 2, 'março': 3, 'abril': 4,
                'maio': 5, 'junho': 6, 'julho': 7, 'agosto': 8,
                'setembro': 9, 'outubro': 10, 'novembro': 11, 'dezembro': 12
            }
            
            month = None
            for month_name, month_num in months.items():
                if month_name in query:
                    month = month_num
                    break
            
            if month is None:
                return jsonify({
                    'error': 'Mês não especificado ou inválido'
                })
            
            # Consulta SQL para buscar as vendas do mês
            sql = """
                SELECT 
                    c.nome as cliente,
                    SUM(v.valor_total) as total_compras,
                    COUNT(v.id) as num_compras
                FROM vendas v
                JOIN clientes c ON v.cliente_id = c.id
                WHERE strftime('%m', v.data) = ?
                GROUP BY c.id
                ORDER BY total_compras DESC
                LIMIT 10
            """
            
            cursor.execute(sql, (f"{month:02d}",))
            results = cursor.fetchall()
            
            if not results:
                return jsonify({
                    'response': f'Não encontrei vendas registradas para o mês especificado.',
                    'reportData': None
                })
            
            # Prepara os dados para o gráfico
            labels = [row[0] for row in results]  # nomes dos clientes
            values = [float(row[1]) for row in results]  # valores totais
            
            # Formata a resposta em texto
            response = f"Aqui está a análise das vendas de {list(months.keys())[month-1]}:\n\n"
            for i, row in enumerate(results, 1):
                response += f"{i}. {row[0]}: R$ {row[1]:,.2f} ({row[2]} compras)\n"
            
            # Prepara os dados do relatório
            report_data = {
                'title': f'Top 10 Clientes em {list(months.keys())[month-1].title()}',
                'period': f'{list(months.keys())[month-1].title()} de {datetime.now().year}',
                'chartType': 'bar',
                'datasetLabel': 'Valor Total de Compras (R$)',
                'labels': labels,
                'values': values
            }
            
            return jsonify({
                'response': response,
                'reportData': report_data
            })
        
        # Outros tipos de análise podem ser adicionados aqui
        
        return jsonify({
            'response': 'Desculpe, não entendi qual análise você gostaria. Por favor, seja mais específico.',
            'reportData': None
        })
        
    except Exception as e:
        print(f"Erro na análise: {str(e)}")
        return jsonify({
            'error': 'Ocorreu um erro ao processar sua solicitação'
        }), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/api/relatorios/vendas')
def get_vendas_report():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Buscar vendas com informações relacionadas
        cursor.execute("""
            SELECT 
                v.id,
                v.data_venda,
                c.nome as cliente_nome,
                p.modelo as produto_modelo,
                v.quantidade,
                v.valor_total,
                p.categoria,
                c.segmento,
                c.regiao
            FROM vendas v
            JOIN clientes c ON v.cliente_id = c.id
            JOIN produtos p ON v.produto_id = p.id
            ORDER BY v.data_venda DESC
        """)
        vendas = cursor.fetchall()

        # Formatar dados para o relatório
        dados_formatados = []
        for venda in vendas:
            dados_formatados.append({
                'id': venda[0],
                'data_venda': venda[1],
                'cliente': venda[2],
                'produto': venda[3],
                'quantidade': venda[4],
                'valor_total': venda[5],
                'categoria': venda[6],
                'segmento': venda[7],
                'regiao': venda[8]
            })

        conn.close()
        return jsonify({'status': 'success', 'data': dados_formatados})

    except Exception as e:
        logger.error(f"Erro ao buscar relatório de vendas: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/relatorios/produtos')
def get_produtos_report():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Buscar produtos com informações de vendas
        cursor.execute("""
            SELECT 
                p.id,
                p.categoria,
                p.modelo,
                p.preco,
                p.estoque,
                COUNT(v.id) as total_vendas,
                COALESCE(SUM(v.valor_total), 0) as valor_total_vendas
            FROM produtos p
            LEFT JOIN vendas v ON p.id = v.produto_id
            GROUP BY p.id
            ORDER BY valor_total_vendas DESC
        """)
        produtos = cursor.fetchall()

        # Formatar dados para o relatório
        dados_formatados = []
        for produto in produtos:
            dados_formatados.append({
                'id': produto[0],
                'categoria': produto[1],
                'modelo': produto[2],
                'preco': produto[3],
                'estoque': produto[4],
                'total_vendas': produto[5],
                'valor_total_vendas': produto[6]
            })

        conn.close()
        return jsonify({'status': 'success', 'data': dados_formatados})

    except Exception as e:
        logger.error(f"Erro ao buscar relatório de produtos: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/relatorios/clientes')
def get_clientes_report():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Buscar clientes com informações de vendas
        cursor.execute("""
            SELECT 
                c.id,
                c.nome,
                c.segmento,
                c.regiao,
                COUNT(v.id) as total_compras,
                COALESCE(SUM(v.valor_total), 0) as valor_total_compras,
                MAX(v.data_venda) as ultima_compra
            FROM clientes c
            LEFT JOIN vendas v ON c.id = v.cliente_id
            GROUP BY c.id
            ORDER BY valor_total_compras DESC
        """)
        clientes = cursor.fetchall()

        # Formatar dados para o relatório
        dados_formatados = []
        for cliente in clientes:
            dados_formatados.append({
                'id': cliente[0],
                'nome': cliente[1],
                'segmento': cliente[2],
                'regiao': cliente[3],
                'total_compras': cliente[4],
                'valor_total_compras': cliente[5],
                'ultima_compra': cliente[6]
            })

        conn.close()
        return jsonify({'status': 'success', 'data': dados_formatados})

    except Exception as e:
        logger.error(f"Erro ao buscar relatório de clientes: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
