// Namespace para gráficos avançados
window.AdvancedCharts = window.AdvancedCharts || {};

// Cache de dados para evitar requisições desnecessárias
AdvancedCharts.cache = {
    lastUpdate: null,
    dashboardData: null,
    vendasData: null,
    updateInterval: 30 * 1000 // 30 segundos
};

// Função para criar gradientes
AdvancedCharts.createGradient = function(ctx, colorStart, colorEnd) {
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, colorStart);
    gradient.addColorStop(1, colorEnd);
    return gradient;
};

// Função para buscar e atualizar dados
AdvancedCharts.updateData = async function(forceUpdate = false) {
    try {
        const now = Date.now();
        if (!forceUpdate && AdvancedCharts.cache.lastUpdate && 
            (now - AdvancedCharts.cache.lastUpdate) < AdvancedCharts.cache.updateInterval) {
            return {
                dashboardData: AdvancedCharts.cache.dashboardData,
                vendasData: AdvancedCharts.cache.vendasData
            };
        }

        // Integração com updateDashboard se disponível
        if (typeof window.updateDashboard === 'function') {
            await window.updateDashboard();
        }

        // Atualizar vendas recentes
        if (typeof window.DashboardFix?.updateRecentSales === 'function') {
            await window.DashboardFix.updateRecentSales();
        }

        const [dashboardResponse, vendasResponse] = await Promise.all([
            fetch('/api/dados/dashboard'),
            fetch('/api/dados/vendas')
        ]);

        if (!dashboardResponse.ok || !vendasResponse.ok) {
            throw new Error('Erro ao buscar dados');
        }

        const dashboardData = await dashboardResponse.json();
        const vendasData = await vendasResponse.json();

        // Atualiza o cache
        AdvancedCharts.cache.lastUpdate = now;
        AdvancedCharts.cache.dashboardData = dashboardData;
        AdvancedCharts.cache.vendasData = vendasData;

        return { dashboardData, vendasData };
    } catch (error) {
        console.error('Erro ao atualizar dados:', error);
        throw error;
    }
};

// Função para criar gráfico de vendas por categoria
AdvancedCharts.createSalesByCategoryChart = async function(forceUpdate = false) {
    try {
        const { dashboardData, vendasData } = await AdvancedCharts.updateData(forceUpdate);

        const canvas = document.getElementById('salesByCategoryChart');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        // Agrupa vendas por categoria
        const vendasPorCategoria = vendasData.reduce((acc, venda) => {
            const categoria = venda.produto_categoria || 'Outros';
            acc[categoria] = (acc[categoria] || 0) + (venda.valor_total || 0);
            return acc;
        }, {});

        // Cria gradientes para as cores
        const gradients = [
            AdvancedCharts.createGradient(ctx, 'rgba(220, 38, 38, 0.8)', 'rgba(220, 38, 38, 0.4)'),
            AdvancedCharts.createGradient(ctx, 'rgba(59, 130, 246, 0.8)', 'rgba(59, 130, 246, 0.4)'),
            AdvancedCharts.createGradient(ctx, 'rgba(16, 185, 129, 0.8)', 'rgba(16, 185, 129, 0.4)'),
            AdvancedCharts.createGradient(ctx, 'rgba(245, 158, 11, 0.8)', 'rgba(245, 158, 11, 0.4)')
        ];

        // Prepara dados para o gráfico
        const data = {
            labels: Object.keys(vendasPorCategoria),
            datasets: [{
                data: Object.values(vendasPorCategoria),
                backgroundColor: gradients,
                borderWidth: 2,
                borderColor: 'white',
                borderRadius: 8,
                hoverOffset: 15
            }]
        };

        // Plugin para texto central
        const centerText = {
            id: 'centerText',
            afterDraw(chart) {
                const { ctx, chartArea: { left, right, top, bottom } } = chart;
                const centerX = (left + right) / 2;
                const centerY = (top + bottom) / 2;

                ctx.save();
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';

                // Total
                ctx.font = '600 24px Inter';
                ctx.fillStyle = '#1f2937';
                const totalValue = dashboardData.vendas_total?.valor_total || 0;
                ctx.fillText(formatMoney(totalValue), centerX, centerY - 15);

                // Label
                ctx.font = '500 14px Inter';
                ctx.fillStyle = '#6b7280';
                ctx.fillText('Total de Vendas', centerX, centerY + 15);

                ctx.restore();
            }
        };

        // Configurações do gráfico
        const config = {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '75%',
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            font: {
                                family: 'Inter',
                                size: 12,
                                weight: '600'
                            },
                            padding: 20,
                            usePointStyle: true,
                            pointStyle: 'circle',
                            generateLabels: function(chart) {
                                const data = chart.data;
                                if (data.labels.length && data.datasets.length) {
                                    return data.labels.map((label, i) => {
                                        const value = data.datasets[0].data[i];
                                        const total = data.datasets[0].data.reduce((a, b) => a + b, 0);
                                        const percentage = ((value / total) * 100).toFixed(1);
                                        return {
                                            text: `${label} (${percentage}%)`,
                                            fillStyle: data.datasets[0].backgroundColor[i],
                                            strokeStyle: data.datasets[0].borderColor,
                                            lineWidth: 2,
                                            hidden: false,
                                            index: i
                                        };
                                    });
                                }
                                return [];
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                        titleColor: '#1f2937',
                        bodyColor: '#1f2937',
                        bodyFont: {
                            family: 'Inter'
                        },
                        borderColor: 'rgba(220, 38, 38, 0.2)',
                        borderWidth: 1,
                        padding: 12,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return [
                                    `Valor: ${formatMoney(value)}`,
                                    `Percentual: ${percentage}%`
                                ];
                            }
                        }
                    }
                },
                animation: {
                    animateScale: true,
                    animateRotate: true,
                    duration: 1000,
                    easing: 'easeOutQuart'
                },
                hover: {
                    mode: 'nearest',
                    intersect: true,
                    animationDuration: 200
                }
            },
            plugins: [centerText] // Adiciona o plugin aqui
        };

        // Cria o gráfico
        const chartInstance = Chart.getChart(canvas);
        if (chartInstance) chartInstance.destroy();
        return new Chart(canvas, config);

    } catch (error) {
        console.error('Erro ao criar gráfico de categorias:', error);
        throw error;
    }
};

// Função para criar gráfico de tendência de vendas
AdvancedCharts.createSalesTrendChart = async function(forceUpdate = false) {
    try {
        const { dashboardData, vendasData } = await AdvancedCharts.updateData(forceUpdate);

        const canvas = document.getElementById('salesTrendChart');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        // Agrupa vendas por dia
        const vendasPorDia = vendasData.reduce((acc, venda) => {
            const data = new Date(venda.data_venda).toLocaleDateString('pt-BR');
            acc[data] = (acc[data] || 0) + (venda.valor_total || 0);
            return acc;
        }, {});

        // Prepara dados para o gráfico
        const labels = Object.keys(vendasPorDia).sort((a, b) => new Date(a) - new Date(b));
        const valores = labels.map(data => vendasPorDia[data]);

        // Cria gradientes
        const gradientVendas = AdvancedCharts.createGradient(ctx, 'rgba(220, 38, 38, 0.2)', 'rgba(220, 38, 38, 0.05)');

        const data = {
            labels: labels,
            datasets: [{
                label: 'Vendas Diárias',
                data: valores,
                borderColor: 'rgb(220, 38, 38)',
                backgroundColor: gradientVendas,
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: 'rgb(220, 38, 38)',
                pointBorderColor: 'white',
                pointBorderWidth: 2,
                pointHoverRadius: 6,
                pointHoverBackgroundColor: 'rgb(220, 38, 38)',
                pointHoverBorderColor: 'white',
                pointHoverBorderWidth: 2
            }]
        };

        const config = {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                        titleColor: '#1f2937',
                        bodyColor: '#1f2937',
                        bodyFont: {
                            family: 'Inter'
                        },
                        borderColor: 'rgba(220, 38, 38, 0.2)',
                        borderWidth: 1,
                        padding: 12,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return `Valor: ${formatMoney(context.raw)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                family: 'Inter',
                                size: 12
                            },
                            maxRotation: 45,
                            minRotation: 45
                        }
                    },
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            font: {
                                family: 'Inter',
                                size: 12
                            },
                            callback: function(value) {
                                return formatMoney(value);
                            }
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeOutQuart'
                },
                hover: {
                    mode: 'nearest',
                    intersect: true,
                    animationDuration: 200
                }
            }
        };

        // Cria o gráfico
        const chartInstance = Chart.getChart(canvas);
        if (chartInstance) chartInstance.destroy();
        return new Chart(canvas, config);

    } catch (error) {
        console.error('Erro ao criar gráfico de tendência:', error);
        throw error;
    }
};

// Função para atualizar todos os gráficos
AdvancedCharts.updateAllCharts = async function(forceUpdate = false) {
    try {
        await AdvancedCharts.createSalesByCategoryChart(forceUpdate);
        await AdvancedCharts.createSalesTrendChart(forceUpdate);
        console.log('Todos os gráficos atualizados com sucesso');
    } catch (error) {
        console.error('Erro ao atualizar gráficos:', error);
    }
};

// Inicializa a atualização automática dos gráficos
document.addEventListener('DOMContentLoaded', function() {
    // Primeira atualização
    AdvancedCharts.updateAllCharts(true);

    // Atualização automática a cada 30 segundos
    setInterval(() => {
        const dashboardPage = document.getElementById('dashboard');
        if (dashboardPage && dashboardPage.classList.contains('active')) {
            AdvancedCharts.updateAllCharts(true);
        }
    }, 30 * 1000);

    // Adiciona listener para eventos de atualização do dashboard
    document.addEventListener('dashboardUpdated', function() {
        console.log('Evento de atualização do dashboard detectado');
        AdvancedCharts.updateAllCharts(true);
    });

    // Adiciona listener para mudança de página
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (this.getAttribute('data-page') === 'dashboard') {
                setTimeout(() => {
                    AdvancedCharts.updateAllCharts(true);
                }, 500);
            }
        });
    });
}); 