import sqlite3
import logging
from datetime import datetime, timedelta
import random

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def init_db():
    """Inicializa o banco de dados com as tabelas necessárias"""
    try:
        conn = sqlite3.connect('ippel.db')
        cursor = conn.cursor()
        logger.info("Conectado ao banco de dados")

        # Criar tabela de clientes
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            segmento TEXT NOT NULL,
            regiao TEXT NOT NULL,
            ultima_compra DATE,
            email TEXT,
            telefone TEXT,
            endereco TEXT
        )
        ''')
        logger.info("Tabela de clientes criada/verificada")

        # Criar tabela de produtos
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            categoria TEXT NOT NULL,
            modelo TEXT NOT NULL,
            preco REAL NOT NULL,
            estoque INTEGER NOT NULL DEFAULT 0,
            descricao TEXT,
            imagem_url TEXT
        )
        ''')
        logger.info("Tabela de produtos criada/verificada")

        # Criar tabela de vendas
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS vendas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            produto_id INTEGER,
            quantidade INTEGER NOT NULL,
            valor_total REAL NOT NULL,
            data_venda DATE NOT NULL,
            status TEXT DEFAULT 'Concluída',
            forma_pagamento TEXT,
            FOREIGN KEY (cliente_id) REFERENCES clientes (id),
            FOREIGN KEY (produto_id) REFERENCES produtos (id)
        )
        ''')
        logger.info("Tabela de vendas criada/verificada")

        # Criar tabela de manutenções
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS manutencoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            produto_id INTEGER,
            tipo TEXT NOT NULL,
            data_manutencao DATE NOT NULL,
            custo REAL NOT NULL,
            status TEXT DEFAULT 'Agendada',
            descricao TEXT,
            FOREIGN KEY (cliente_id) REFERENCES clientes (id),
            FOREIGN KEY (produto_id) REFERENCES produtos (id)
        )
        ''')
        logger.info("Tabela de manutenções criada/verificada")

        conn.commit()
        logger.info("Banco de dados inicializado com sucesso")
        conn.close()
        
    except sqlite3.Error as e:
        logger.error(f"Erro ao inicializar banco de dados: {str(e)}")
        raise

def get_db_connection():
    """Retorna uma conexão com o banco de dados"""
    try:
        conn = sqlite3.connect('ippel.db')
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        logger.error(f"Erro ao conectar ao banco de dados: {str(e)}")
        raise

def generate_sample_data(conn):
    """Gera dados de exemplo para o banco de dados"""
    try:
        cursor = conn.cursor()
        
        # Dados de exemplo para clientes
        clientes = [
            ('Metalúrgica Silva', 'Metalurgia', 'Sul', 'contato@metalurgicasilva.com.br', '(51) 3333-4444', 'Rua Industrial, 123'),
            ('Indústria Santos', 'Indústria', 'Sudeste', 'vendas@industriasantos.com.br', '(11) 4444-5555', 'Av. das Indústrias, 456'),
            ('Fábrica Oliveira', 'Fabricação', 'Nordeste', 'contato@oliveira.ind.br', '(81) 5555-6666', 'Rua dos Fabricantes, 789')
        ]
        cursor.executemany('INSERT INTO clientes (nome, segmento, regiao, email, telefone, endereco) VALUES (?, ?, ?, ?, ?, ?)', clientes)
        
        # Dados de exemplo para produtos
        produtos = [
            ('Máquinas', 'Torno CNC 500', 150000.00, 5, 'Torno CNC de alta precisão'),
            ('Máquinas', 'Fresadora Universal', 85000.00, 3, 'Fresadora versátil para diversos trabalhos'),
            ('Equipamentos', 'Prensa Hidráulica 100T', 45000.00, 8, 'Prensa hidráulica de 100 toneladas'),
            ('Ferramentas', 'Kit Ferramentas Usinagem', 12000.00, 15, 'Kit completo de ferramentas para usinagem'),
            ('Máquinas', 'Centro de Usinagem', 280000.00, 2, 'Centro de usinagem 5 eixos')
        ]
        cursor.executemany('INSERT INTO produtos (categoria, modelo, preco, estoque, descricao) VALUES (?, ?, ?, ?, ?)', produtos)
        
        # Gerar algumas vendas de exemplo
        hoje = datetime.now()
        formas_pagamento = ['Boleto', 'Cartão', 'Transferência']
        
        for _ in range(10):
            data_venda = hoje - timedelta(days=random.randint(1, 90))
            produto_id = random.randint(1, 5)
            quantidade = random.randint(1, 3)
            
            # Buscar preço do produto
            cursor.execute('SELECT preco FROM produtos WHERE id = ?', (produto_id,))
            preco = cursor.fetchone()[0]
            valor_total = preco * quantidade
            
            venda = (
                random.randint(1, 3),  # cliente_id
                produto_id,
                quantidade,
                valor_total,
                data_venda.strftime('%Y-%m-%d'),
                random.choice(formas_pagamento)
            )
            cursor.execute('''
                INSERT INTO vendas (cliente_id, produto_id, quantidade, valor_total, data_venda, forma_pagamento)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', venda)
            
            # Atualizar última compra do cliente
            cursor.execute('UPDATE clientes SET ultima_compra = ? WHERE id = ?', 
                         (data_venda.strftime('%Y-%m-%d'), venda[0]))
        
        # Gerar algumas manutenções de exemplo
        tipos_manutencao = ['Preventiva', 'Corretiva', 'Revisão']
        for _ in range(8):
            data_manutencao = hoje - timedelta(days=random.randint(1, 60))
            manutencao = (
                random.randint(1, 3),  # cliente_id
                random.randint(1, 5),  # produto_id
                random.choice(tipos_manutencao),
                data_manutencao.strftime('%Y-%m-%d'),
                random.uniform(2000, 8000),  # custo
                'Manutenção ' + random.choice(['realizada', 'agendada', 'em andamento'])
            )
            cursor.execute('''
                INSERT INTO manutencoes (cliente_id, produto_id, tipo, data_manutencao, custo, status)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', manutencao)
        
        conn.commit()
        logger.info("Dados de exemplo gerados com sucesso")
        
    except sqlite3.Error as e:
        logger.error(f"Erro ao gerar dados de exemplo: {str(e)}")
        conn.rollback()
        raise

if __name__ == '__main__':
    init_db() 